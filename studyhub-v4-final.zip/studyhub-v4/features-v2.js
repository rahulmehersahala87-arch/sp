// ═══════════════════════════════════════════════════════════════════════════════
// StudyHub Features v2 — New Features & Fixes
// Adds: AI Notes Generator, Weakness Analyzer, AI Study Coach, PYQ section,
//        Student Progress Analytics Dashboard, Trust Pages
// ═══════════════════════════════════════════════════════════════════════════════

// ──────────────────────────────────────────────────────────────────────────────
// 1. STUDENT PROGRESS ANALYTICS
// ──────────────────────────────────────────────────────────────────────────────
function renderProgressAnalytics() {
  const el = document.getElementById('progressAnalytics');
  if (!el) return;

  const history = (typeof testHistory !== 'undefined') ? testHistory : [];
  const streak = (typeof calcStreak === 'function') ? calcStreak() : 0;

  // Calculate total study hours (approx 1 test ≈ 20 mins)
  const totalMins = history.length * 20;
  const totalHours = (totalMins / 60).toFixed(1);

  // Average score
  const avgScore = history.length
    ? Math.round(history.reduce((s, t) => s + (t.pct || 0), 0) / history.length)
    : 0;

  // Best score
  const bestScore = history.length
    ? Math.max(...history.map(t => t.pct || 0))
    : 0;

  // Subject breakdown
  const subjectMap = {};
  history.forEach(t => {
    if (!t.subject) return;
    if (!subjectMap[t.subject]) subjectMap[t.subject] = { total: 0, count: 0 };
    subjectMap[t.subject].total += (t.pct || 0);
    subjectMap[t.subject].count++;
  });
  const subjectAvgs = Object.entries(subjectMap).map(([s, d]) => ({
    subject: s,
    avg: Math.round(d.total / d.count)
  })).sort((a, b) => b.avg - a.avg);

  const bestSubject = subjectAvgs[0]?.subject || '—';
  const weakSubject = subjectAvgs[subjectAvgs.length - 1]?.subject || '—';

  // Weekly activity (last 7 days)
  const now = Date.now();
  const days7 = 7 * 86400000;
  const recentTests = history.filter(t => now - new Date(t.date).getTime() < days7).length;

  // Rank (local demo)
  const rank = history.length === 0 ? '—' : (avgScore >= 90 ? '🥇 Top 10%' : avgScore >= 75 ? '🥈 Top 30%' : '🥉 Top 50%');

  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:4px">📊 My Progress Analytics</h2>
      <p style="color:var(--muted);font-size:.85rem">Your personal study performance overview</p>
    </div>

    <!-- Stats Grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:20px">
      ${[
        { icon: '⏱️', val: totalHours + 'h', lbl: 'Study Hours', color: '#6366f1' },
        { icon: '📝', val: history.length, lbl: 'Tests Taken', color: '#06b6d4' },
        { icon: '📈', val: avgScore + '%', lbl: 'Avg Score', color: '#f59e0b' },
        { icon: '🏆', val: bestScore + '%', lbl: 'Best Score', color: '#10b981' },
        { icon: '🔥', val: streak, lbl: 'Day Streak', color: '#f97316' },
        { icon: '🌟', val: rank, lbl: 'Your Rank', color: '#a78bfa' },
      ].map(s => `
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:16px;text-align:center;transition:.2s" onmouseenter="this.style.borderColor='${s.color}60'" onmouseleave="this.style.borderColor='var(--border)'">
          <div style="font-size:1.5rem;margin-bottom:6px">${s.icon}</div>
          <div style="font-size:1.25rem;font-weight:800;color:${s.color}">${s.val}</div>
          <div style="font-size:.72rem;color:var(--muted);margin-top:3px">${s.lbl}</div>
        </div>`).join('')}
    </div>

    <!-- Subject Performance Bars -->
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:18px;margin-bottom:16px">
      <div style="font-weight:700;margin-bottom:14px;display:flex;align-items:center;gap:8px">📚 Subject Performance</div>
      ${subjectAvgs.length === 0
        ? `<div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0">Take tests to see subject breakdown</div>`
        : subjectAvgs.map(s => {
            const color = s.avg >= 80 ? '#10b981' : s.avg >= 60 ? '#f59e0b' : '#f87171';
            return `<div style="margin-bottom:12px">
              <div style="display:flex;justify-content:space-between;font-size:.84rem;margin-bottom:5px">
                <span>${s.subject}</span><span style="font-weight:700;color:${color}">${s.avg}%</span>
              </div>
              <div style="height:8px;background:var(--border);border-radius:20px;overflow:hidden">
                <div style="height:100%;width:${s.avg}%;background:${color};border-radius:20px;transition:width .8s ease"></div>
              </div>
            </div>`;
          }).join('')}
      ${subjectAvgs.length > 0 ? `
        <div style="display:flex;gap:16px;margin-top:14px;font-size:.8rem">
          <span>🟢 Best: <strong>${bestSubject}</strong></span>
          <span>🔴 Focus: <strong>${weakSubject}</strong></span>
          <span>📅 Tests this week: <strong>${recentTests}</strong></span>
        </div>` : ''}
    </div>

    <!-- Recent Activity -->
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:18px">
      <div style="font-weight:700;margin-bottom:12px">🗓️ Recent Test History</div>
      ${history.length === 0
        ? `<div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0">No tests taken yet. Start a quiz!</div>`
        : history.slice(0, 6).map(t => {
            const color = (t.pct || 0) >= 80 ? '#10b981' : (t.pct || 0) >= 60 ? '#f59e0b' : '#f87171';
            const date = t.date ? new Date(t.date).toLocaleDateString('en-IN', { day:'numeric', month:'short' }) : '';
            return `<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:.85rem;font-weight:600">${t.subject || 'Mixed'} · ${t.chapter || 'General'}</div>
                <div style="font-size:.74rem;color:var(--muted)">${date} · ${t.total || 0} Qs</div>
              </div>
              <span style="font-weight:800;color:${color};font-size:1rem">${t.pct || 0}%</span>
            </div>`;
          }).join('')}
    </div>
  `;
}

// ──────────────────────────────────────────────────────────────────────────────
// 2. AI NOTES GENERATOR PAGE
// ──────────────────────────────────────────────────────────────────────────────
function renderAINotesGenerator() {
  const el = document.getElementById('aiNotesGen');
  if (!el) return;

  const subjects = typeof SUBJECTS_CHAPTERS !== 'undefined' ? Object.keys(SUBJECTS_CHAPTERS) : ['Mathematics','Science','English','Social Studies','Hindi'];

  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:4px">🤖 AI Notes Generator</h2>
      <p style="color:var(--muted);font-size:.85rem">Enter any chapter — AI creates complete notes, summary, formulas & important questions</p>
    </div>

    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:16px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div>
          <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Subject</label>
          <select id="aiNotesSubject" onchange="updateAINotesChapters()" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem">
            ${subjects.map(s => `<option>${s}</option>`).join('')}
          </select>
        </div>
        <div>
          <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Chapter</label>
          <select id="aiNotesChapter" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem">
            ${(typeof SUBJECTS_CHAPTERS !== 'undefined' ? (SUBJECTS_CHAPTERS[subjects[0]] || []) : []).map(c => `<option>${c}</option>`).join('')}
          </select>
        </div>
      </div>
      <div style="margin-bottom:12px">
        <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Or type any topic / chapter name</label>
        <input id="aiNotesCustom" type="text" placeholder="e.g. Science Chapter 5: Life Processes" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;box-sizing:border-box">
      </div>
      <button onclick="doGenerateAINotes()" style="width:100%;padding:12px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:.95rem;cursor:pointer;transition:.2s" onmouseenter="this.style.opacity='.85'" onmouseleave="this.style.opacity='1'">
        ✨ Generate AI Notes
      </button>
    </div>

    <div id="aiNotesOutput" style="display:none;background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:20px">
      <div id="aiNotesContent" style="white-space:pre-wrap;line-height:1.75;font-size:.9rem"></div>
      <button onclick="copyAINotes()" style="margin-top:14px;padding:9px 18px;background:var(--surface);border:1px solid var(--border);border-radius:8px;color:inherit;cursor:pointer;font-size:.82rem">📋 Copy Notes</button>
    </div>
  `;
}

window.updateAINotesChapters = function() {
  const sub = document.getElementById('aiNotesSubject')?.value;
  const chSel = document.getElementById('aiNotesChapter');
  if (!chSel || !sub || typeof SUBJECTS_CHAPTERS === 'undefined') return;
  const chapters = SUBJECTS_CHAPTERS[sub] || [];
  chSel.innerHTML = chapters.map(c => `<option>${c}</option>`).join('');
};

window.doGenerateAINotes = async function() {
  const sub = document.getElementById('aiNotesSubject')?.value || 'Science';
  const ch = document.getElementById('aiNotesCustom')?.value.trim() || document.getElementById('aiNotesChapter')?.value || 'Chapter';
  const outEl = document.getElementById('aiNotesOutput');
  const contentEl = document.getElementById('aiNotesContent');
  if (!outEl || !contentEl) return;

  outEl.style.display = 'block';
  contentEl.innerHTML = `<div style="text-align:center;padding:30px;color:var(--muted)">
    <div style="font-size:2rem;margin-bottom:8px">⚙️</div>
    <div>Generating notes for <strong>${ch}</strong>...</div>
  </div>`;

  const result = await generateAINotes(sub, ch);
  // Render markdown-lite (bold **text**, headers ##)
  contentEl.innerHTML = result
    .replace(/## (.+)/g, '<h3 style="color:var(--accent);margin:16px 0 8px;font-size:1rem">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
};

window.copyAINotes = function() {
  const text = document.getElementById('aiNotesContent')?.innerText || '';
  navigator.clipboard.writeText(text).then(() => {
    if (typeof showToast === 'function') showToast('Notes copied!', 'success');
  });
};

// ──────────────────────────────────────────────────────────────────────────────
// 3. WEAKNESS ANALYZER
// ──────────────────────────────────────────────────────────────────────────────
function renderWeaknessAnalyzer() {
  const el = document.getElementById('weaknessAnalyzer');
  if (!el) return;

  const history = typeof testHistory !== 'undefined' ? testHistory : [];

  // Compute subject averages
  const subMap = {};
  history.forEach(t => {
    const s = t.subject || 'General';
    if (!subMap[s]) subMap[s] = { total: 0, count: 0 };
    subMap[s].total += (t.pct || 0);
    subMap[s].count++;
  });
  const subjectScores = {};
  Object.entries(subMap).forEach(([s, d]) => { subjectScores[s] = Math.round(d.total / d.count); });

  // Weak chapters from dashWeakChapters-like logic
  const weakChapters = typeof testHistory !== 'undefined'
    ? (() => {
        const cm = {};
        testHistory.forEach(t => {
          if (!t.chapter || !t.subject) return;
          const k = t.subject + '|' + t.chapter;
          if (!cm[k]) cm[k] = { subject: t.subject, chapter: t.chapter, total: 0, count: 0 };
          cm[k].total += (t.pct || 0); cm[k].count++;
        });
        return Object.values(cm)
          .map(x => ({ ...x, avg: Math.round(x.total / x.count) }))
          .filter(x => x.avg < 70)
          .sort((a, b) => a.avg - b.avg)
          .slice(0, 8);
      })()
    : [];

  const bars = Object.entries(subjectScores);

  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:4px">🔍 Weakness Analyzer</h2>
      <p style="color:var(--muted);font-size:.85rem">AI identifies your weak spots and tells you exactly what to focus on</p>
    </div>

    ${bars.length === 0 ? `
      <div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:30px;text-align:center;color:var(--muted)">
        <div style="font-size:2.5rem;margin-bottom:10px">📝</div>
        <div>Take at least 3 tests to unlock your weakness analysis!</div>
        <button onclick="showPage('quiz')" style="margin-top:16px;padding:10px 20px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:600">Start a Test →</button>
      </div>` : `

      <!-- Subject Score Cards -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:16px">
        ${bars.map(([s, p]) => {
          const color = p >= 80 ? '#10b981' : p >= 60 ? '#f59e0b' : '#f87171';
          const emoji = p >= 80 ? '✅' : p >= 60 ? '⚠️' : '❗';
          return `<div style="background:var(--surface2);border:2px solid ${color}30;border-radius:14px;padding:16px;text-align:center">
            <div style="font-size:1.4rem;margin-bottom:4px">${emoji}</div>
            <div style="font-size:1.4rem;font-weight:800;color:${color}">${p}%</div>
            <div style="font-size:.78rem;color:var(--muted)">${s}</div>
          </div>`;
        }).join('')}
      </div>

      <!-- Weak Chapters -->
      ${weakChapters.length > 0 ? `
        <div style="background:rgba(244,63,94,.06);border:1px solid rgba(244,63,94,.25);border-radius:14px;padding:16px;margin-bottom:16px">
          <div style="font-weight:700;margin-bottom:10px;color:#f87171">⚠️ Chapters Needing Attention</div>
          ${weakChapters.map(w => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:.86rem;font-weight:600">${w.chapter}</div>
                <div style="font-size:.74rem;color:var(--muted)">${w.subject}</div>
              </div>
              <span style="font-weight:700;color:#f87171">${w.avg}%</span>
            </div>`).join('')}
        </div>` : ''}

      <!-- AI Recommendation Button -->
      <button onclick="doWeaknessAI(${JSON.stringify(weakChapters).replace(/"/g,'&quot;')}, ${JSON.stringify(subjectScores).replace(/"/g,'&quot;')})"
        style="width:100%;padding:13px;background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;border:none;border-radius:12px;font-weight:700;font-size:.95rem;cursor:pointer;margin-bottom:16px">
        🧠 Get AI Study Recommendations
      </button>
    `}

    <div id="weaknessAIOutput" style="display:none;background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:18px">
      <div id="weaknessAIContent" style="white-space:pre-wrap;line-height:1.75;font-size:.88rem"></div>
    </div>
  `;
}

window.doWeaknessAI = async function(weakChapters, subjectScores) {
  const outEl = document.getElementById('weaknessAIOutput');
  const contentEl = document.getElementById('weaknessAIContent');
  if (!outEl || !contentEl) return;
  outEl.style.display = 'block';
  contentEl.innerHTML = '<div style="text-align:center;padding:20px;color:var(--muted)">🤖 Analysing your performance...</div>';
  const result = await analyzeWeaknesses(weakChapters, subjectScores);
  contentEl.innerHTML = result
    .replace(/## (.+)/g, '<h3 style="color:var(--accent);margin:14px 0 6px;font-size:.95rem">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
};

// ──────────────────────────────────────────────────────────────────────────────
// 4. AI STUDY COACH
// ──────────────────────────────────────────────────────────────────────────────
function renderStudyCoach() {
  const el = document.getElementById('studyCoach');
  if (!el) return;

  const subjects = typeof SUBJECTS_CHAPTERS !== 'undefined' ? Object.keys(SUBJECTS_CHAPTERS) : ['Mathematics','Science','English','Social Studies','Hindi'];
  const weakChapters = typeof testHistory !== 'undefined'
    ? (() => {
        const cm = {};
        testHistory.forEach(t => {
          if (!t.chapter || !t.subject) return;
          const k = t.subject + '|' + t.chapter;
          if (!cm[k]) cm[k] = { subject: t.subject, chapter: t.chapter, total: 0, count: 0 };
          cm[k].total += (t.pct || 0); cm[k].count++;
        });
        return Object.values(cm).map(x => ({ ...x, avg: Math.round(x.total / x.count) })).filter(x => x.avg < 70);
      })()
    : [];

  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:4px">🚀 AI Study Coach</h2>
      <p style="color:var(--muted);font-size:.85rem">Enter your exam date — AI builds a personalised daily study plan</p>
    </div>

    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:16px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
        <div>
          <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">📅 Days Until Exam</label>
          <input id="coachDays" type="number" min="1" max="365" placeholder="e.g. 30" value="30"
            style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;box-sizing:border-box">
        </div>
        <div>
          <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">📚 Subjects to Cover</label>
          <select id="coachSubjects" multiple style="width:100%;padding:8px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.85rem;height:80px">
            ${subjects.map(s => `<option value="${s}" selected>${s}</option>`).join('')}
          </select>
        </div>
      </div>
      ${weakChapters.length > 0 ? `<div style="font-size:.8rem;color:#f59e0b;margin-bottom:12px">⚠️ ${weakChapters.length} weak chapter(s) detected — will be prioritised in your plan</div>` : ''}
      <button onclick="doGenerateStudyPlan()" style="width:100%;padding:13px;background:linear-gradient(135deg,#6366f1,#06b6d4);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:.95rem;cursor:pointer">
        📅 Generate My Study Plan
      </button>
    </div>

    <div id="studyPlanOutput" style="display:none;background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:20px">
      <div id="studyPlanContent" style="white-space:pre-wrap;line-height:1.8;font-size:.88rem"></div>
      <button onclick="copyStudyPlan()" style="margin-top:14px;padding:9px 18px;background:var(--surface);border:1px solid var(--border);border-radius:8px;color:inherit;cursor:pointer;font-size:.82rem">📋 Copy Plan</button>
    </div>
  `;
}

window.doGenerateStudyPlan = async function() {
  const days = parseInt(document.getElementById('coachDays')?.value) || 30;
  const selEl = document.getElementById('coachSubjects');
  const subjects = selEl ? Array.from(selEl.selectedOptions).map(o => o.value) : ['Mathematics','Science'];
  const weakChapters = typeof testHistory !== 'undefined'
    ? (() => {
        const cm = {};
        testHistory.forEach(t => {
          if (!t.chapter || !t.subject) return;
          const k = t.subject + '|' + t.chapter;
          if (!cm[k]) cm[k] = { subject: t.subject, chapter: t.chapter, total: 0, count: 0 };
          cm[k].total += (t.pct || 0); cm[k].count++;
        });
        return Object.values(cm).map(x => ({ ...x, avg: Math.round(x.total / x.count) })).filter(x => x.avg < 70);
      })()
    : [];

  const outEl = document.getElementById('studyPlanOutput');
  const contentEl = document.getElementById('studyPlanContent');
  if (!outEl || !contentEl) return;
  outEl.style.display = 'block';
  contentEl.innerHTML = '<div style="text-align:center;padding:30px;color:var(--muted)">📅 Building your personalised plan...</div>';

  const result = await generateStudyPlan(days, subjects, weakChapters);
  contentEl.innerHTML = result
    .replace(/## (.+)/g, '<h3 style="color:var(--accent);margin:16px 0 8px;font-size:1rem">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
};

window.copyStudyPlan = function() {
  const text = document.getElementById('studyPlanContent')?.innerText || '';
  navigator.clipboard.writeText(text).then(() => {
    if (typeof showToast === 'function') showToast('Study plan copied!', 'success');
  });
};

// ──────────────────────────────────────────────────────────────────────────────
// 5. PREVIOUS YEAR PAPERS (PYQ)
// ──────────────────────────────────────────────────────────────────────────────
const PYQ_DATA = {
  Mathematics: [
    { year: 2024, board: 'CBSE', link: '#', questions: 30, duration: '3 hrs', marks: 80 },
    { year: 2023, board: 'CBSE', link: '#', questions: 30, duration: '3 hrs', marks: 80 },
    { year: 2022, board: 'CBSE', link: '#', questions: 30, duration: '3 hrs', marks: 80 },
    { year: 2021, board: 'CBSE', link: '#', questions: 30, duration: '3 hrs', marks: 80 },
    { year: 2020, board: 'CBSE', link: '#', questions: 30, duration: '3 hrs', marks: 80 },
  ],
  Science: [
    { year: 2024, board: 'CBSE', link: '#', questions: 36, duration: '3 hrs', marks: 80 },
    { year: 2023, board: 'CBSE', link: '#', questions: 36, duration: '3 hrs', marks: 80 },
    { year: 2022, board: 'CBSE', link: '#', questions: 36, duration: '3 hrs', marks: 80 },
    { year: 2021, board: 'CBSE', link: '#', questions: 36, duration: '3 hrs', marks: 80 },
    { year: 2020, board: 'CBSE', link: '#', questions: 36, duration: '3 hrs', marks: 80 },
  ],
  English: [
    { year: 2024, board: 'CBSE', link: '#', questions: 11, duration: '3 hrs', marks: 80 },
    { year: 2023, board: 'CBSE', link: '#', questions: 11, duration: '3 hrs', marks: 80 },
    { year: 2022, board: 'CBSE', link: '#', questions: 11, duration: '3 hrs', marks: 80 },
    { year: 2021, board: 'CBSE', link: '#', questions: 11, duration: '3 hrs', marks: 80 },
    { year: 2020, board: 'CBSE', link: '#', questions: 11, duration: '3 hrs', marks: 80 },
  ],
  'Social Studies': [
    { year: 2024, board: 'CBSE', link: '#', questions: 35, duration: '3 hrs', marks: 80 },
    { year: 2023, board: 'CBSE', link: '#', questions: 35, duration: '3 hrs', marks: 80 },
    { year: 2022, board: 'CBSE', link: '#', questions: 35, duration: '3 hrs', marks: 80 },
    { year: 2021, board: 'CBSE', link: '#', questions: 35, duration: '3 hrs', marks: 80 },
    { year: 2020, board: 'CBSE', link: '#', questions: 35, duration: '3 hrs', marks: 80 },
  ],
};

function renderPYQ() {
  const el = document.getElementById('pyqPage');
  if (!el) return;

  const subjects = Object.keys(PYQ_DATA);
  const activeSub = el.dataset.activeSub || subjects[0];

  const papers = PYQ_DATA[activeSub] || [];

  el.innerHTML = `
    <div style="margin-bottom:20px">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:4px">📄 Previous Year Papers</h2>
      <p style="color:var(--muted);font-size:.85rem">CBSE Class 10 Board Papers 2020–2024 • Students search these most!</p>
    </div>

    <!-- Subject Tabs -->
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
      ${subjects.map(s => `
        <button onclick="selectPYQSubject('${s}')" id="pyqTab_${s.replace(/\s/g,'_')}"
          style="padding:8px 16px;border-radius:20px;border:1px solid var(--border);background:${s===activeSub?'var(--accent)':'var(--surface2)'};color:${s===activeSub?'#fff':'inherit'};cursor:pointer;font-size:.82rem;font-weight:600;transition:.2s">
          ${s}
        </button>`).join('')}
    </div>

    <!-- Papers Grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px" id="pyqGrid">
      ${papers.map(p => `
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:18px;transition:.2s;cursor:pointer"
          onmouseenter="this.style.borderColor='#6366f1'" onmouseleave="this.style.borderColor='var(--border)'"
          onclick="openPYQ('${activeSub}',${p.year})">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <span style="font-size:1.5rem;font-weight:900;color:var(--accent)">${p.year}</span>
            <span style="font-size:.72rem;background:rgba(99,102,241,.15);color:#818cf8;padding:3px 8px;border-radius:10px">${p.board}</span>
          </div>
          <div style="font-weight:700;margin-bottom:6px">${activeSub}</div>
          <div style="font-size:.78rem;color:var(--muted);display:flex;flex-direction:column;gap:3px">
            <span>📝 ${p.questions} Questions</span>
            <span>⏱️ ${p.duration}</span>
            <span>🎯 ${p.marks} Marks</span>
          </div>
          <div style="margin-top:12px;display:flex;gap:8px">
            <button style="flex:1;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-size:.78rem;font-weight:600;cursor:pointer">View Paper</button>
            <button onclick="event.stopPropagation();practisePYQ('${activeSub}',${p.year})" style="padding:8px 10px;background:var(--surface);border:1px solid var(--border);border-radius:8px;font-size:.78rem;cursor:pointer">Practice</button>
          </div>
        </div>`).join('')}
    </div>

    <div style="margin-top:16px;padding:14px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);border-radius:12px;font-size:.82rem;color:#fbbf24">
      ⚠️ <strong>Note:</strong> These are sample paper structures. Connect real PDF links via Admin → Uploads to serve actual board papers.
    </div>
  `;
}

window.selectPYQSubject = function(sub) {
  const el = document.getElementById('pyqPage');
  if (!el) return;
  el.dataset.activeSub = sub;
  renderPYQ();
};

window.openPYQ = function(subject, year) {
  if (typeof showToast === 'function') showToast(`Opening ${subject} ${year} paper...`, 'info');
  // Link to actual PDF when connected
};

window.practisePYQ = function(subject, year) {
  // Start a quiz for that subject
  if (typeof showPage === 'function') showPage('quiz');
  if (typeof showToast === 'function') showToast(`Starting ${subject} practice test!`, 'success');
};

// ──────────────────────────────────────────────────────────────────────────────
// 6. TRUST PAGES (Contact, Privacy, Terms, Feedback)
// ──────────────────────────────────────────────────────────────────────────────
function renderContactPage() {
  const el = document.getElementById('contactPage');
  if (!el) return;
  el.innerHTML = `
    <div style="max-width:600px;margin:0 auto">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:6px">📬 Contact Us</h2>
      <p style="color:var(--muted);font-size:.85rem;margin-bottom:24px">We'd love to hear from you. Reach out for support, feedback, or partnership.</p>
      <div style="background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:24px;margin-bottom:16px">
        <div style="display:grid;gap:14px">
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Your Name</label>
            <input type="text" placeholder="Rahul Sharma" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;box-sizing:border-box"></div>
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Email</label>
            <input type="email" placeholder="rahul@example.com" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;box-sizing:border-box"></div>
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Category</label>
            <select style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem">
              <option>General Question</option><option>Bug Report</option><option>Feature Request</option><option>Partnership</option>
            </select></div>
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Message</label>
            <textarea placeholder="Your message..." rows="5" style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;resize:vertical;box-sizing:border-box"></textarea></div>
          <button onclick="if(typeof showToast==='function')showToast('Message sent! We\\'ll reply within 24 hours ✉️','success')"
            style="padding:12px;background:var(--accent);color:#fff;border:none;border-radius:10px;font-weight:700;cursor:pointer">Send Message</button>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center">
          <div style="font-size:1.5rem;margin-bottom:6px">📧</div><div style="font-size:.82rem;font-weight:600">Email</div>
          <div style="font-size:.76rem;color:var(--muted)">support@studyhub.in</div>
        </div>
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center">
          <div style="font-size:1.5rem;margin-bottom:6px">⏰</div><div style="font-size:.82rem;font-weight:600">Response Time</div>
          <div style="font-size:.76rem;color:var(--muted)">Within 24 hours</div>
        </div>
      </div>
    </div>`;
}

function renderPrivacyPage() {
  const el = document.getElementById('privacyPage');
  if (!el) return;
  el.innerHTML = `
    <div style="max-width:680px;margin:0 auto">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:6px">🔒 Privacy Policy</h2>
      <p style="color:var(--muted);font-size:.8rem;margin-bottom:20px">Last updated: June 2026</p>
      ${[
        ['What we collect', 'We collect your name, email, class section, and test performance data to personalise your study experience.'],
        ['How we use it', 'Data is used to show your progress, generate AI recommendations, and improve the platform. We never sell your data.'],
        ['Data storage', 'All data is securely stored using Firebase (Google Cloud). Data is encrypted in transit and at rest.'],
        ['AI usage', 'Your questions to the AI tutor are processed by Google Gemini API. They are not stored permanently or used to train models.'],
        ['Cookies', 'We use localStorage for session management and preferences. No third-party tracking cookies are used.'],
        ['Your rights', 'You can delete your account and all associated data at any time from Profile → Settings → Delete Account.'],
        ['Contact', 'For privacy concerns, email: privacy@studyhub.in'],
      ].map(([h, t]) => `
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:10px">
          <div style="font-weight:700;margin-bottom:6px">📌 ${h}</div>
          <div style="font-size:.85rem;color:var(--muted);line-height:1.65">${t}</div>
        </div>`).join('')}
    </div>`;
}

function renderTermsPage() {
  const el = document.getElementById('termsPage');
  if (!el) return;
  el.innerHTML = `
    <div style="max-width:680px;margin:0 auto">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:6px">📋 Terms & Conditions</h2>
      <p style="color:var(--muted);font-size:.8rem;margin-bottom:20px">Last updated: June 2026</p>
      ${[
        ['Eligibility', 'StudyHub is designed for Class 10 CBSE students. By using this platform you confirm you are a student, teacher, or parent.'],
        ['Account usage', 'One account per person. You are responsible for keeping your login credentials secure.'],
        ['Acceptable use', 'Do not share copyrighted content without permission. Do not attempt to hack, scrape, or misuse the platform.'],
        ['AI content', 'AI-generated content is for study assistance only. Always verify important facts with your textbooks.'],
        ['Premium features', 'Premium subscriptions are billed monthly. Refunds are available within 7 days of purchase.'],
        ['Termination', 'We reserve the right to suspend accounts that violate these terms.'],
        ['Changes', 'We may update these terms. Continued use after changes constitutes acceptance.'],
      ].map(([h, t]) => `
        <div style="background:var(--surface2);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:10px">
          <div style="font-weight:700;margin-bottom:6px">📌 ${h}</div>
          <div style="font-size:.85rem;color:var(--muted);line-height:1.65">${t}</div>
        </div>`).join('')}
    </div>`;
}

function renderFeedbackPage() {
  const el = document.getElementById('feedbackPage');
  if (!el) return;
  el.innerHTML = `
    <div style="max-width:580px;margin:0 auto">
      <h2 style="font-size:1.35rem;font-weight:800;margin-bottom:6px">💬 Feedback & Bug Report</h2>
      <p style="color:var(--muted);font-size:.85rem;margin-bottom:20px">Help us make StudyHub better for every student!</p>
      <div style="background:var(--surface2);border:1px solid var(--border);border-radius:16px;padding:22px">
        <div style="display:grid;gap:14px">
          <div>
            <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Type</label>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              ${['💡 Feature Request','🐛 Bug Report','⭐ General Feedback','📚 Content Issue'].map(t =>
                `<label style="cursor:pointer;display:flex;align-items:center;gap:5px;font-size:.82rem;padding:7px 12px;background:var(--surface);border:1px solid var(--border);border-radius:20px">
                  <input type="radio" name="fbType" style="accent-color:var(--accent)"> ${t}</label>`).join('')}
            </div>
          </div>
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Rating</label>
            <div id="fbStars" style="display:flex;gap:6px;font-size:1.5rem;cursor:pointer">
              ${[1,2,3,4,5].map(i=>`<span onclick="rateFeedback(${i})" id="fbStar${i}" style="transition:.15s">⭐</span>`).join('')}
            </div></div>
          <div><label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:5px">Details</label>
            <textarea id="fbText" rows="5" placeholder="Describe the feature, bug, or feedback in detail..." style="width:100%;padding:10px 12px;background:var(--surface);border:1px solid var(--border);border-radius:10px;color:inherit;font-size:.9rem;resize:vertical;box-sizing:border-box"></textarea></div>
          <button onclick="submitFeedback()" style="padding:12px;background:var(--accent);color:#fff;border:none;border-radius:10px;font-weight:700;cursor:pointer">Submit Feedback 🚀</button>
        </div>
      </div>
    </div>`;
}

window.rateFeedback = function(n) {
  [1,2,3,4,5].forEach(i => {
    const s = document.getElementById('fbStar'+i);
    if (s) s.style.filter = i <= n ? 'none' : 'grayscale(1) opacity(.4)';
  });
};

window.submitFeedback = function() {
  const text = document.getElementById('fbText')?.value.trim();
  if (!text) { if (typeof showToast==='function') showToast('Please write your feedback first.','error'); return; }
  if (typeof showToast==='function') showToast('Thank you! Your feedback has been submitted 🙏','success');
  if (document.getElementById('fbText')) document.getElementById('fbText').value = '';
};

// ──────────────────────────────────────────────────────────────────────────────
// 7. INJECT ALL NEW PAGES + NAV ITEMS INTO THE APP
// ──────────────────────────────────────────────────────────────────────────────
(function injectNewPages() {
  const PAGES = [
    { id: 'progressAnalytics', render: renderProgressAnalytics },
    { id: 'aiNotesGen',        render: renderAINotesGenerator },
    { id: 'weaknessAnalyzer',  render: renderWeaknessAnalyzer },
    { id: 'studyCoach',        render: renderStudyCoach },
    { id: 'pyqPage',           render: renderPYQ },
    { id: 'contactPage',       render: renderContactPage },
    { id: 'privacyPage',       render: renderPrivacyPage },
    { id: 'termsPage',         render: renderTermsPage },
    { id: 'feedbackPage',      render: renderFeedbackPage },
  ];

  const NAV_ITEMS = [
    { id: '__nav_progress',   dataNav: 'progressAnalytics', icon: '📊', label: 'My Progress',     render: renderProgressAnalytics },
    { id: '__nav_aiNotes',    dataNav: 'aiNotesGen',        icon: '📝', label: 'AI Notes',         render: renderAINotesGenerator },
    { id: '__nav_weakness',   dataNav: 'weaknessAnalyzer',  icon: '🔍', label: 'Weakness Analyzer',render: renderWeaknessAnalyzer },
    { id: '__nav_coach',      dataNav: 'studyCoach',        icon: '🚀', label: 'Study Coach',       render: renderStudyCoach },
    { id: '__nav_pyq',        dataNav: 'pyqPage',           icon: '📄', label: 'Past Papers (PYQ)', render: renderPYQ },
    { id: '__nav_contact',    dataNav: 'contactPage',       icon: '📬', label: 'Contact Us',        render: renderContactPage },
    { id: '__nav_feedback',   dataNav: 'feedbackPage',      icon: '💬', label: 'Feedback',          render: renderFeedbackPage },
  ];

  function inject() {
    const content = document.querySelector('.content') || document.getElementById('mainContent');
    if (!content) return;

    // Create page divs
    PAGES.forEach(({ id }) => {
      if (!document.getElementById(id)) {
        const pg = document.createElement('div');
        pg.id = id; pg.className = 'page';
        content.appendChild(pg);
      }
    });

    // Inject nav buttons
    const navList = document.getElementById('sidebarNav') || document.querySelector('.nav-list');
    if (!navList) return;

    // Add separator before new section
    if (!document.getElementById('__nav_sep_v2')) {
      const sep = document.createElement('div');
      sep.id = '__nav_sep_v2';
      sep.style.cssText = 'height:1px;background:var(--border);margin:8px 12px;opacity:.5';
      navList.appendChild(sep);
    }

    NAV_ITEMS.forEach(item => {
      if (document.getElementById(item.id)) return; // already added
      const btn = document.createElement('button');
      btn.id = item.id;
      btn.className = 'nav-item';
      btn.setAttribute('data-nav', item.dataNav);
      btn.innerHTML = `${item.icon} ${item.label}`;
      btn.onclick = () => {
        if (typeof showPage === 'function') showPage(item.dataNav);
        item.render();
      };
      navList.appendChild(btn);
    });
  }

  // Hook into enterApp
  const origEnter = window.enterApp;
  if (typeof origEnter === 'function') {
    window.enterApp = function() {
      origEnter.apply(this, arguments);
      setTimeout(inject, 300);
    };
  } else {
    // Fallback: retry until enterApp fires
    document.addEventListener('DOMContentLoaded', () => setTimeout(inject, 1000));
  }

  // Also patch showPage to auto-render new pages
  const origShow = window.showPage;
  if (typeof origShow === 'function') {
    window.showPage = function(id) {
      origShow.apply(this, arguments);
      const page = PAGES.find(p => p.id === id);
      if (page) setTimeout(page.render, 50);
    };
  }
})();

// ──────────────────────────────────────────────────────────────────────────────
// 8. SEARCH PAGINATION (performance fix for large question banks)
// ──────────────────────────────────────────────────────────────────────────────
(function patchSearchPerformance() {
  const SEARCH_PAGE_SIZE = 50;
  const _origSearch = window.runSearch;
  if (typeof _origSearch !== 'function') return;

  window.runSearch = function(query) {
    const results = _origSearch.call(this, query);
    if (!Array.isArray(results) || results.length <= SEARCH_PAGE_SIZE) return results;
    // Return first page only; future: add "Load more" button
    console.info(`[StudyHub] Search returned ${results.length} results, showing first ${SEARCH_PAGE_SIZE}`);
    return results.slice(0, SEARCH_PAGE_SIZE);
  };
})();
