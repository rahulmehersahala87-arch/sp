// ═══════════════════════════════════════════════════════════════════════
//  StudyHub v2 — 10 New Features
//  1. Notes Library (enhanced upload + download counter)
//  2. Smart Search
//  3. Mock Test System (already exists — enhanced with analytics)
//  4. AI Question Generator (already exists — enhanced)
//  5. Lecture Hub (YouTube embeds + playlists)
//  6. Student Dashboard (already exists — enhanced)
//  7. Leaderboard (quiz rankings + weekly toppers)
//  8. Study Planner (daily goals, countdown, tasks)
//  9. Notifications system
// 10. Advanced Admin Panel (analytics + announcements)
// ═══════════════════════════════════════════════════════════════════════

// ── Utility: LS is defined in app.js — use window.LS as fallback ─────
// (do not redeclare — app.js already defines const LS)

// ── Wait for DOM ready ───────────────────────────────────────────────
function onReady(fn) {
  if (document.readyState !== 'loading') fn();
  else document.addEventListener('DOMContentLoaded', fn);
}

// ═══════════════════ 1. NOTES LIBRARY — Download Counter ═════════════
function trackDownload(fileId) {
  const counts = LS.get('dl_counts', {});
  counts[fileId] = (counts[fileId] || 0) + 1;
  LS.set('dl_counts', counts);
  // Update badge in DOM
  const badge = document.querySelector(`[data-dl-badge="${fileId}"]`);
  if (badge) badge.textContent = counts[fileId];
}
function getDownloadCount(fileId) {
  return (LS.get('dl_counts', {}))[fileId] || 0;
}
// Patch renderFiles if it exists to inject download counters
function patchRenderFiles() {
  const origRender = window.renderFiles;
  if (!origRender) return;
  window.renderFiles = function(...args) {
    origRender(...args);
    // Inject download counts after render
    setTimeout(() => {
      document.querySelectorAll('[data-file-id]').forEach(el => {
        const fid = el.dataset.fileId;
        if (!fid) return;
        if (!el.querySelector('.dl-badge-wrap')) {
          const wrap = document.createElement('span');
          wrap.className = 'dl-badge-wrap';
          wrap.innerHTML = `<span class="dl-badge" data-dl-badge="${fid}" title="Downloads">⬇ ${getDownloadCount(fid)}</span>`;
          el.appendChild(wrap);
        }
      });
    }, 100);
  };
}

// ═══════════════════ 2. SMART SEARCH ════════════════════════════════
let searchIndex = [];
let searchOpen = false;

function buildSearchIndex() {
  searchIndex = [];
  // Index questions
  (LS.get('questions', []) || []).forEach((q, i) => {
    searchIndex.push({ type: 'question', icon: '❓', title: q.q || q.text || '', subtitle: `${q.subject} · ${q.chapter}`, action: () => { showPage('editor'); } });
  });
  // Index files
  (LS.get('files', []) || []).forEach((f, i) => {
    searchIndex.push({ type: 'file', icon: '📄', title: f.name || f.title || '', subtitle: `${f.subject} · ${f.type || 'Notes'}`, action: () => { showPage('upload'); } });
  });
  // Index pages
  [
    { icon: '🏠', title: 'Home', subtitle: 'Dashboard overview', action: () => showPage('home') },
    { icon: '📊', title: 'My Dashboard', subtitle: 'Performance & streaks', action: () => showPage('dashboard') },
    { icon: '📚', title: 'Study Materials', subtitle: 'Upload and browse notes', action: () => showPage('upload') },
    { icon: '👥', title: 'Study Rooms', subtitle: 'Live group study', action: () => showPage('rooms') },
    { icon: '📜', title: 'PYQ Bank', subtitle: 'Previous year questions', action: () => showPage('pyq') },
    { icon: '📝', title: 'Mock Test', subtitle: 'Take a timed test', action: () => showPage('test') },
    { icon: '🎥', title: 'Lecture Hub', subtitle: 'YouTube lectures', action: () => showPage('lectures') },
    { icon: '🏆', title: 'Leaderboard', subtitle: 'Top quiz performers', action: () => showPage('leaderboard') },
    { icon: '📅', title: 'Study Planner', subtitle: 'Daily goals & exam countdown', action: () => showPage('planner') },
    { icon: '🔔', title: 'Notifications', subtitle: 'Alerts & announcements', action: () => openNotifPanel() },
  ].forEach(p => searchIndex.push({ type: 'page', ...p }));
}

function openGlobalSearch() {
  buildSearchIndex();
  searchOpen = true;
  const modal = document.getElementById('globalSearchModal');
  if (modal) {
    modal.classList.add('open');
    const inp = document.getElementById('globalSearchInput');
    if (inp) { inp.value = ''; inp.focus(); renderSearchResults(''); }
  }
}

function closeGlobalSearch() {
  searchOpen = false;
  const modal = document.getElementById('globalSearchModal');
  if (modal) modal.classList.remove('open');
}

function renderSearchResults(query) {
  const list = document.getElementById('searchResultsList');
  if (!list) return;
  if (!query.trim()) {
    list.innerHTML = '<div class="search-hint">Start typing to search notes, questions, topics…</div>';
    return;
  }
  const q = query.toLowerCase();
  const results = searchIndex.filter(item =>
    (item.title || '').toLowerCase().includes(q) ||
    (item.subtitle || '').toLowerCase().includes(q)
  ).slice(0, 12);
  if (!results.length) {
    list.innerHTML = '<div class="search-hint">No results found.</div>';
    return;
  }
  list.innerHTML = results.map((r, i) => `
    <div class="search-result-item" onclick="execSearch(${i})" data-idx="${i}">
      <span class="sr-icon">${r.icon}</span>
      <div class="sr-text">
        <div class="sr-title">${highlight(r.title, query)}</div>
        <div class="sr-sub">${r.subtitle || ''}</div>
      </div>
      <span class="sr-type ${r.type}">${r.type}</span>
    </div>
  `).join('');
  // Store results for exec
  window._searchResults = results;
}

function highlight(text, query) {
  if (!query) return text;
  const re = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  return text.replace(re, '<mark>$1</mark>');
}

function execSearch(idx) {
  const r = (window._searchResults || [])[idx];
  if (r && r.action) { closeGlobalSearch(); r.action(); }
}

// ═══════════════════ 5. LECTURE HUB ══════════════════════════════════

// ═══════════════════════════════════════════════════════════════════
//  LECTURE HUB v2 — 3 Sections + Full Admin Management
//  Sections: 1. One Shot  2. Quick Revision  3. Marathon
// ═══════════════════════════════════════════════════════════════════

const LECTURE_SECTIONS = [
  { id: 'oneshot',   label: '🚀 One Shot',       color: '#f59e0b', desc: 'Complete chapter in one go' },
  { id: 'revision',  label: '⚡ Quick Revision',  color: '#22c55e', desc: '10-20 min rapid revision' },
  { id: 'marathon',  label: '🏃 Marathon',         color: '#ec4899', desc: 'Deep dive long sessions' },
];

const LECTURE_SUBJECTS = ['Mathematics','Science','English','Social Studies','Hindi'];

// Default seed videos per section
const DEFAULT_LECTURES = {
  oneshot: {
    Mathematics:     [ {title:'Real Numbers - One Shot',            yt:'VPDfNRLkxkk', duration:'45 min'}, {title:'Polynomials - One Shot',             yt:'gAUL8OBdFcg', duration:'50 min'}, {title:'Quadratic Equations - One Shot',      yt:'Q5oLSMuOqcM', duration:'55 min'}, {title:'Trigonometry - One Shot',            yt:'mERSFTX-QxQ', duration:'60 min'} ],
    Science:         [ {title:'Chemical Reactions - One Shot',      yt:'RnvCbquYeIs', duration:'60 min'}, {title:'Life Processes - One Shot',          yt:'8udhPBBKAaI', duration:'65 min'}, {title:'Electricity - One Shot',             yt:'CyKZ6TZR3lc', duration:'70 min'} ],
    English:         [ {title:'First Flight - Full Chapter',        yt:'C8I-WS1GFZY', duration:'40 min'}, {title:'Grammar Complete - One Shot',        yt:'NVpAMCzxFX8', duration:'50 min'} ],
    'Social Studies':[ {title:'Nationalism in India - One Shot',    yt:'F4mFYAUSuho', duration:'65 min'}, {title:'Power Sharing - One Shot',           yt:'M9PXXMq9yDs', duration:'55 min'} ],
    Hindi:           [ {title:'Sparsh - Full One Shot',             yt:'dQw4w9WgXcQ', duration:'50 min'} ],
  },
  revision: {
    Mathematics:     [ {title:'Real Numbers - Quick Recap',         yt:'bWQ3E5GpqKI', duration:'12 min'}, {title:'Polynomials - Rapid Revision',       yt:'sHXK6YWLKSM', duration:'10 min'}, {title:'Statistics - Quick Revision',        yt:'0TFnBMYMQ6Y', duration:'15 min'}, {title:'Probability - Quick Revision',       yt:'SqLbeVeRA9I', duration:'10 min'} ],
    Science:         [ {title:'Acids & Bases - Quick Revision',     yt:'cKgjA8H_0xA', duration:'14 min'}, {title:'Metals - Rapid Recap',               yt:'fT2PbPX5Nuw', duration:'12 min'}, {title:'Our Environment - Quick Recap',      yt:'JcKDFWqIEHE', duration:'10 min'} ],
    English:         [ {title:'Letter Writing - Quick Revision',    yt:'kvqc4zxcRB8', duration:'12 min'}, {title:'Nelson Mandela - Quick Recap',       yt:'AeLiFrXk9Pc', duration:'10 min'} ],
    'Social Studies':[ {title:'Resources - Quick Revision',        yt:'DqEMXuYf-8A', duration:'15 min'}, {title:'Manufacturing - Quick Recap',        yt:'QSfOBv2PNZQ', duration:'12 min'} ],
    Hindi:           [ {title:'Hindi Grammar - Quick Revision',     yt:'dQw4w9WgXcQ', duration:'10 min'} ],
  },
  marathon: {
    Mathematics:     [ {title:'Arithmetic Progressions - Marathon', yt:'bWQ3E5GpqKI', duration:'2 hrs'},  {title:'Circles - Marathon Session',        yt:'sHXK6YWLKSM', duration:'1.5 hrs'} ],
    Science:         [ {title:'Light - Marathon Session',           yt:'Fxg5_IbOHEI', duration:'2 hrs'},  {title:'Magnetic Effects - Marathon',       yt:'kLPALM5_Nk8', duration:'1.5 hrs'} ],
    English:         [ {title:'Full Grammar Marathon',              yt:'NVpAMCzxFX8', duration:'2 hrs'} ],
    'Social Studies':[ {title:'Nationalism Marathon',               yt:'b8ij8G-tVX0', duration:'2.5 hrs'}],
    Hindi:           [ {title:'Hindi Full Marathon',                yt:'dQw4w9WgXcQ', duration:'2 hrs'} ],
  },
};

// ── Storage helpers ─────────────────────────────────────────────────
function getLectures(section, subject) {
  const key = `lectures_${section}_${subject}`;
  const stored = LS.get(key, null);
  if (Array.isArray(stored)) return stored;
  // First time: seed from defaults
  const seed = (DEFAULT_LECTURES[section] || {})[subject] || [];
  LS.set(key, seed);
  return seed;
}
function saveLectures(section, subject, arr) {
  LS.set(`lectures_${section}_${subject}`, arr);
}
function addLecture(section, subject, title, yt, duration) {
  const arr = getLectures(section, subject);
  arr.push({ title, yt, duration: duration || 'N/A', id: Date.now() });
  saveLectures(section, subject, arr);
}
function deleteLecture(section, subject, idx) {
  const arr = getLectures(section, subject);
  arr.splice(idx, 1);
  saveLectures(section, subject, arr);
}
function replaceLecture(section, subject, idx, title, yt, duration) {
  const arr = getLectures(section, subject);
  if (!arr[idx]) return;
  arr[idx] = { ...arr[idx], title, yt, duration: duration || arr[idx].duration };
  saveLectures(section, subject, arr);
}

// ── State ────────────────────────────────────────────────────────────
let _lSection = 'oneshot';
let _lSubject = 'Mathematics';
let _lAdminMode = false;

// ── Render ───────────────────────────────────────────────────────────
function renderLecturePage() {
  const page = document.getElementById('lectures');
  if (!page) return;

  const isAdmin = typeof window.isAdmin === 'function' && window.isAdmin();
  const sec  = LECTURE_SECTIONS.find(s => s.id === _lSection) || LECTURE_SECTIONS[0];
  const vids = getLectures(_lSection, _lSubject);

  page.innerHTML = `
    <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#ec4899">🎥 LECTURE HUB</div>
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:6px">
      <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin:0">Video <span style="background:linear-gradient(135deg,#f59e0b,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Lectures</span></h1>
      ${isAdmin ? `<button onclick="toggleLectureAdmin()" id="lectAdminBtn" style="background:${_lAdminMode ? 'rgba(239,68,68,.15)' : 'rgba(124,58,237,.15)'};border:1px solid ${_lAdminMode ? 'rgba(239,68,68,.3)' : 'rgba(124,58,237,.3)'};color:${_lAdminMode ? '#f87171' : '#a78bfa'};border-radius:10px;padding:7px 16px;cursor:pointer;font-size:.83rem;font-weight:700">${_lAdminMode ? '✕ Exit Edit Mode' : '✏️ Manage Videos'}</button>` : ''}
    </div>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:20px">Chapter-wise YouTube lectures — 3 study modes for every learning style.</p>

    <!-- Section tabs -->
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">
      ${LECTURE_SECTIONS.map(s => `
        <button onclick="switchLectureSection('${s.id}')" style="display:flex;align-items:center;gap:8px;padding:10px 18px;border-radius:12px;cursor:pointer;font-weight:700;font-size:.88rem;transition:.15s;border:2px solid ${s.id===_lSection ? s.color : 'rgba(255,255,255,.08)'};background:${s.id===_lSection ? s.color+'22' : 'rgba(255,255,255,.04)'};color:${s.id===_lSection ? s.color : '#64748b'}">
          <span>${s.label}</span>
          ${s.id===_lSection ? `<span style="font-size:.72rem;opacity:.8">${s.desc}</span>` : ''}
        </button>
      `).join('')}
    </div>

    <!-- Subject tabs -->
    <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:20px">
      ${LECTURE_SUBJECTS.map(s => `
        <button onclick="switchLectureSubject('${s}')" class="lect-tab${s===_lSubject?' active':''}">${s}</button>
      `).join('')}
    </div>

    <!-- Add video form (admin only) -->
    ${_lAdminMode ? `
    <div style="background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.25);border-radius:16px;padding:20px;margin-bottom:20px">
      <div style="font-weight:700;font-size:.9rem;color:#a78bfa;margin-bottom:14px">➕ Add Video to <span style="color:#f59e0b">${sec.label}</span> → <span style="color:#06b6d4">${_lSubject}</span></div>
      <div style="display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:10px;align-items:end;flex-wrap:wrap">
        <div>
          <label style="font-size:.72rem;color:#64748b;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px">Video Title</label>
          <input id="newLectTitle" type="text" placeholder="e.g. Real Numbers - Class 10" class="form-input" style="width:100%;box-sizing:border-box">
        </div>
        <div>
          <label style="font-size:.72rem;color:#64748b;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px">YouTube ID or URL</label>
          <input id="newLectYT" type="text" placeholder="e.g. dQw4w9WgXcQ" class="form-input" style="width:100%;box-sizing:border-box">
        </div>
        <div>
          <label style="font-size:.72rem;color:#64748b;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px">Duration</label>
          <input id="newLectDuration" type="text" placeholder="e.g. 45 min" class="form-input" style="width:100%;box-sizing:border-box">
        </div>
        <button onclick="submitAddLecture()" style="padding:10px 18px;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;border-radius:10px;color:#fff;font-weight:700;cursor:pointer;white-space:nowrap">+ Add</button>
      </div>
      <div id="lectureAddMsg" style="font-size:.78rem;margin-top:8px;min-height:18px"></div>
    </div>
    ` : ''}

    <!-- Video player -->
    <div id="lecturePlayerWrap" style="display:none;background:var(--surface);border:1px solid var(--border);border-radius:20px;overflow:hidden;margin-bottom:20px">
      <div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden">
        <iframe id="lectureIframe" src="" frameborder="0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%"></iframe>
      </div>
      <div style="padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div>
          <div id="lecturePlaying" style="font-weight:700;font-size:.95rem;color:#e2e8f0"></div>
          <div style="font-size:.78rem;color:${sec.color};margin-top:2px">${sec.label} · ${_lSubject}</div>
        </div>
        <button onclick="closeLecturePlayer()" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#e2e8f0;border-radius:8px;padding:6px 14px;cursor:pointer;font-size:.83rem">✕ Close</button>
      </div>
    </div>

    <!-- Video grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px" id="lectureGrid">
      ${vids.length === 0 ? `
        <div style="grid-column:1/-1;text-align:center;padding:40px;color:#64748b">
          <div style="font-size:2.5rem;margin-bottom:10px">🎬</div>
          <div style="font-weight:600;margin-bottom:6px">No videos yet</div>
          <div style="font-size:.83rem">${isAdmin ? 'Use the form above to add videos.' : 'Admin hasn\'t added videos for this section yet.'}</div>
        </div>
      ` : vids.map((l, i) => `
        <div class="lect-card" style="position:relative">
          <div onclick="playLecture('${extractYTId(l.yt)}','${(l.title||'').replace(/'/g,"\\'")}','${_lSubject}')" style="cursor:pointer">
            <div class="lect-thumb">
              <img src="https://img.youtube.com/vi/${extractYTId(l.yt)}/mqdefault.jpg" alt="${l.title}" loading="lazy" onerror="this.onerror=null;this.src='https://placehold.co/320x180/1e293b/8b5cf6?text=Video'">
              <div class="lect-play-btn">▶</div>
            </div>
          </div>
          <div class="lect-info">
            ${_lAdminMode ? `
            <div id="editForm_${i}" style="display:none;margin-bottom:10px">
              <input id="editTitle_${i}" value="${(l.title||'').replace(/"/g,'&quot;')}" class="form-input" style="width:100%;box-sizing:border-box;margin-bottom:5px;font-size:.82rem" placeholder="Title">
              <input id="editYT_${i}" value="${l.yt||''}" class="form-input" style="width:100%;box-sizing:border-box;margin-bottom:5px;font-size:.82rem" placeholder="YouTube ID/URL">
              <input id="editDur_${i}" value="${l.duration||''}" class="form-input" style="width:100%;box-sizing:border-box;margin-bottom:8px;font-size:.82rem" placeholder="Duration">
              <div style="display:flex;gap:6px">
                <button onclick="submitReplaceLecture(${i})" style="flex:1;padding:6px;background:linear-gradient(135deg,#22c55e,#16a34a);border:none;border-radius:7px;color:#fff;font-size:.78rem;font-weight:700;cursor:pointer">💾 Save</button>
                <button onclick="document.getElementById('editForm_${i}').style.display='none'" style="padding:6px 10px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:7px;color:#94a3b8;font-size:.78rem;cursor:pointer">Cancel</button>
              </div>
            </div>
            ` : ''}
            <div class="lect-title">${l.title}</div>
            <div class="lect-meta">
              <span style="color:${sec.color};font-size:.72rem;font-weight:700">${sec.label}</span>
              <span>⏱ ${l.duration}</span>
            </div>
            ${_lAdminMode ? `
            <div style="display:flex;gap:6px;margin-top:10px">
              <button onclick="document.getElementById('editForm_${i}').style.display=document.getElementById('editForm_${i}').style.display==='none'?'block':'none'" style="flex:1;padding:5px;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.25);color:#fbbf24;border-radius:7px;font-size:.75rem;font-weight:600;cursor:pointer">✏️ Edit</button>
              <button onclick="confirmDeleteLecture(${i})" style="padding:5px 10px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:7px;font-size:.75rem;font-weight:600;cursor:pointer">🗑</button>
            </div>
            ` : ''}
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// ── Extract YouTube ID from URL or bare ID ────────────────────────────
function extractYTId(input) {
  if (!input) return '';
  // Full URL formats
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = input.match(p);
    if (m) return m[1];
  }
  // Bare ID (11 chars)
  if (/^[a-zA-Z0-9_-]{11}$/.test(input.trim())) return input.trim();
  return input.trim();
}

// ── Section / subject switchers ───────────────────────────────────────
function switchLectureSection(id) { _lSection = id; renderLecturePage(); }
function switchLectureSubject(s)  { _lSubject = s;  renderLecturePage(); }
function toggleLectureAdmin()     { _lAdminMode = !_lAdminMode; renderLecturePage(); }

// ── Add ───────────────────────────────────────────────────────────────
function submitAddLecture() {
  const title = (document.getElementById('newLectTitle') || {}).value?.trim();
  const yt    = (document.getElementById('newLectYT')    || {}).value?.trim();
  const dur   = (document.getElementById('newLectDuration') || {}).value?.trim();
  const msg   = document.getElementById('lectureAddMsg');

  if (!title || !yt) {
    if (msg) { msg.style.color = '#f87171'; msg.textContent = '⚠️ Title and YouTube ID/URL are required.'; }
    return;
  }
  const ytId = extractYTId(yt);
  if (!ytId) {
    if (msg) { msg.style.color = '#f87171'; msg.textContent = '⚠️ Invalid YouTube URL or ID.'; }
    return;
  }
  addLecture(_lSection, _lSubject, title, ytId, dur || 'N/A');
  if (msg) { msg.style.color = '#22c55e'; msg.textContent = `✅ "${title}" added successfully!`; }
  document.getElementById('newLectTitle').value = '';
  document.getElementById('newLectYT').value    = '';
  document.getElementById('newLectDuration').value = '';
  setTimeout(renderLecturePage, 600);
}

// ── Delete ────────────────────────────────────────────────────────────
function confirmDeleteLecture(idx) {
  const vids = getLectures(_lSection, _lSubject);
  const v = vids[idx];
  if (!v) return;
  if (confirm(`Delete "${v.title}"?`)) {
    deleteLecture(_lSection, _lSubject, idx);
    renderLecturePage();
  }
}

// ── Replace / Edit ────────────────────────────────────────────────────
function submitReplaceLecture(idx) {
  const title = (document.getElementById(`editTitle_${idx}`) || {}).value?.trim();
  const yt    = (document.getElementById(`editYT_${idx}`)    || {}).value?.trim();
  const dur   = (document.getElementById(`editDur_${idx}`)   || {}).value?.trim();
  if (!title || !yt) return;
  replaceLecture(_lSection, _lSubject, idx, title, extractYTId(yt), dur);
  renderLecturePage();
}

// ── Play / Close ──────────────────────────────────────────────────────
function playLecture(ytId, title, subj) {
  const wrap  = document.getElementById('lecturePlayerWrap');
  const frame = document.getElementById('lectureIframe');
  const label = document.getElementById('lecturePlaying');
  if (!wrap || !frame) return;
  frame.src = `https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0`;
  if (label) label.textContent = title;
  wrap.style.display = 'block';
  wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function closeLecturePlayer() {
  const wrap  = document.getElementById('lecturePlayerWrap');
  const frame = document.getElementById('lectureIframe');
  if (wrap)  wrap.style.display = 'none';
  if (frame) frame.src = '';
}

// ═══════════════════ 7. LEADERBOARD ══════════════════════════════════
function getLeaderboardData() {
  // Gather all users' test history from localStorage
  const allUsers = LS.get('all_profiles', {});
  const currentUser = LS.get('current_user_profile', {});
  const myHistory = LS.get('testHistory', []) || [];

  // Build a leaderboard entry for current user
  const entries = [];
  if (currentUser && currentUser.name) {
    const tests = myHistory.length;
    const avg = tests > 0 ? Math.round(myHistory.reduce((a, h) => a + (h.score / h.total * 100), 0) / tests) : 0;
    const best = tests > 0 ? Math.max(...myHistory.map(h => Math.round(h.score / h.total * 100))) : 0;
    entries.push({
      name: currentUser.name || 'You',
      username: currentUser.username || 'you',
      xp: currentUser.xp || 0,
      tests, avg, best,
      isMe: true,
      avatar: (currentUser.name || 'Y')[0].toUpperCase()
    });
  }

  // Fill with demo students to make it look real
  const demoStudents = [
    { name: 'Aarav Sharma', username: 'aarav_s', xp: 4200, tests: 18, avg: 88, best: 98 },
    { name: 'Priya Nair', username: 'priya_n', xp: 3800, tests: 15, avg: 84, best: 96 },
    { name: 'Rohan Gupta', username: 'rohan_g', xp: 3450, tests: 12, avg: 82, best: 92 },
    { name: 'Ananya Singh', username: 'ananya_s', xp: 3100, tests: 14, avg: 79, best: 90 },
    { name: 'Karthik Rajan', username: 'karthi_r', xp: 2900, tests: 11, avg: 76, best: 88 },
    { name: 'Meera Joshi', username: 'meera_j', xp: 2750, tests: 10, avg: 74, best: 85 },
    { name: 'Siddharth Kumar', username: 'siddy_k', xp: 2500, tests: 9, avg: 71, best: 82 },
    { name: 'Divya Patel', username: 'divya_p', xp: 2200, tests: 8, avg: 68, best: 80 },
    { name: 'Rahul Verma', username: 'rahul_v', xp: 1900, tests: 7, avg: 65, best: 76 },
    { name: 'Sneha Iyer', username: 'sneha_i', xp: 1650, tests: 6, avg: 62, best: 74 },
  ];
  demoStudents.forEach(s => { s.avatar = s.name[0]; s.isMe = false; entries.push(s); });

  return entries.sort((a, b) => b.xp - a.xp);
}

function renderLeaderboard() {
  const page = document.getElementById('leaderboard');
  if (!page) return;
  const data = getLeaderboardData();
  const medals = ['🥇', '🥈', '🥉'];
  const weeklyTop = [...data].sort((a, b) => b.avg - a.avg).slice(0, 3);

  page.innerHTML = `
    <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#f59e0b">🏆 RANKINGS</div>
    <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin-bottom:6px">Leaderboard</h1>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:22px">Top quiz performers ranked by XP. Take more tests to climb up!</p>

    <!-- Weekly toppers -->
    <div style="background:linear-gradient(135deg,rgba(245,158,11,.12),rgba(236,72,153,.08));border:1px solid rgba(245,158,11,.25);border-radius:20px;padding:24px;margin-bottom:24px">
      <div style="font-size:.82rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#f59e0b;margin-bottom:14px">⭐ Weekly Top Performers (by avg score)</div>
      <div style="display:flex;gap:14px;flex-wrap:wrap">
        ${weeklyTop.map((s, i) => `
          <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:16px 20px;flex:1;min-width:140px;text-align:center">
            <div style="font-size:2rem;margin-bottom:6px">${medals[i]}</div>
            <div style="font-weight:700;font-size:.95rem;color:#e2e8f0">${s.name}</div>
            <div style="font-size:.8rem;color:#64748b;margin:2px 0 8px">@${s.username}</div>
            <div style="font-size:1.3rem;font-weight:800;color:#f59e0b">${s.avg}%</div>
            <div style="font-size:.7rem;color:#64748b">avg score</div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Full table -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:20px;overflow:hidden">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
        <div style="font-weight:700;font-size:.95rem">All Students — XP Ranking</div>
        <div style="font-size:.75rem;color:#64748b">${data.length} students</div>
      </div>
      <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse">
          <thead>
            <tr style="background:rgba(255,255,255,.03)">
              <th style="padding:11px 16px;text-align:left;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">#</th>
              <th style="padding:11px 16px;text-align:left;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">Student</th>
              <th style="padding:11px 16px;text-align:right;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">XP</th>
              <th style="padding:11px 16px;text-align:right;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">Tests</th>
              <th style="padding:11px 16px;text-align:right;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">Avg</th>
              <th style="padding:11px 16px;text-align:right;font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#475569;">Best</th>
            </tr>
          </thead>
          <tbody>
            ${data.map((s, i) => `
              <tr style="border-top:1px solid rgba(255,255,255,.04);${s.isMe ? 'background:rgba(124,58,237,.08)' : ''}transition:.15s" onmouseenter="this.style.background='rgba(255,255,255,.03)'" onmouseleave="this.style.background='${s.isMe ? 'rgba(124,58,237,.08)' : 'transparent'}'">
                <td style="padding:12px 16px">
                  <span style="font-weight:800;color:${i < 3 ? '#f59e0b' : '#64748b'}">${i < 3 ? medals[i] : '#' + (i + 1)}</span>
                </td>
                <td style="padding:12px 16px">
                  <div style="display:flex;align-items:center;gap:10px">
                    <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,${s.isMe ? '#7c3aed,#06b6d4' : '#475569,#334155'});display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;color:#fff;flex-shrink:0">${s.avatar}</div>
                    <div>
                      <div style="font-weight:600;font-size:.9rem;color:#e2e8f0">${s.name} ${s.isMe ? '<span style="background:rgba(124,58,237,.3);color:#c4b5fd;font-size:.65rem;padding:1px 7px;border-radius:99px;margin-left:4px">You</span>' : ''}</div>
                      <div style="font-size:.75rem;color:#64748b">@${s.username}</div>
                    </div>
                  </div>
                </td>
                <td style="padding:12px 16px;text-align:right;font-weight:700;color:#8b5cf6">${(s.xp || 0).toLocaleString()}</td>
                <td style="padding:12px 16px;text-align:right;color:#94a3b8">${s.tests}</td>
                <td style="padding:12px 16px;text-align:right"><span style="font-weight:600;color:${s.avg >= 80 ? '#22c55e' : s.avg >= 60 ? '#f59e0b' : '#ef4444'}">${s.avg}%</span></td>
                <td style="padding:12px 16px;text-align:right;color:#06b6d4;font-weight:600">${s.best}%</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// ═══════════════════ 8. STUDY PLANNER ════════════════════════════════
function getPlannerData() {
  try {
    return {
      tasks:            Array.isArray(LS.get('planner_tasks', null))  ? LS.get('planner_tasks', [])  : [],
      goals:            Array.isArray(LS.get('planner_goals', null))  ? LS.get('planner_goals', [])  : [],
      examDate:         LS.get('exam_date', '') || '',
      dailyGoalMinutes: LS.get('daily_goal_mins', 60) || 60
    };
  } catch { return { tasks: [], goals: [], examDate: '', dailyGoalMinutes: 60 }; }
}

function savePlannerTask(task) {
  const tasks = LS.get('planner_tasks', []);
  tasks.push({ ...task, id: Date.now(), done: false, createdAt: new Date().toISOString() });
  LS.set('planner_tasks', tasks);
  renderPlanner();
}

function togglePlannerTask(id) {
  const tasks = LS.get('planner_tasks', []);
  const t = tasks.find(t => t.id === id);
  if (t) t.done = !t.done;
  LS.set('planner_tasks', tasks);
  renderPlanner();
}

function deletePlannerTask(id) {
  const tasks = LS.get('planner_tasks', []).filter(t => t.id !== id);
  LS.set('planner_tasks', tasks);
  renderPlanner();
}

function getExamCountdown() {
  const examDate = LS.get('exam_date', '');
  if (!examDate) return null;
  const now = new Date();
  const exam = new Date(examDate);
  const diff = exam - now;
  if (diff <= 0) return { days: 0, label: 'Exam day has passed' };
  const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
  return { days, label: `${days} days until exam` };
}

function renderPlanner() {
  const page = document.getElementById('planner');
  if (!page) return;
  const data = getPlannerData();
  const countdown = getExamCountdown();
  const today = new Date().toDateString();
  const todayTasks = data.tasks.filter(t => {
    const d = new Date(t.createdAt).toDateString();
    return d === today;
  });
  const allTasks = data.tasks.slice().reverse();
  const donePct = allTasks.length ? Math.round(allTasks.filter(t => t.done).length / allTasks.length * 100) : 0;
  const priorityColors = { high: '#ef4444', medium: '#f59e0b', low: '#22c55e' };

  page.innerHTML = `
    <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#22c55e">📅 STUDY PLANNER</div>
    <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin-bottom:6px">Study <span style="background:linear-gradient(135deg,#22c55e,#06b6d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Planner</span></h1>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:22px">Set daily goals, track tasks, and countdown to your board exam.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:22px">
      <!-- Exam Countdown -->
      <div style="background:linear-gradient(135deg,rgba(239,68,68,.12),rgba(236,72,153,.08));border:1px solid rgba(239,68,68,.25);border-radius:18px;padding:22px">
        <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#ef4444;margin-bottom:10px">📅 EXAM COUNTDOWN</div>
        ${countdown ? `
          <div style="font-size:3rem;font-weight:900;color:#e2e8f0;line-height:1">${countdown.days}</div>
          <div style="font-size:.85rem;color:#94a3b8;margin-top:4px">${countdown.label}</div>
        ` : `<div style="font-size:.85rem;color:#64748b">No exam date set</div>`}
        <div style="margin-top:14px">
          <input type="date" id="examDateInput" value="${data.examDate}" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e8f0;padding:6px 10px;font-size:.82rem;width:100%;box-sizing:border-box" onchange="LS.set('exam_date',this.value);renderPlanner()">
          <div style="font-size:.72rem;color:#64748b;margin-top:4px">Set your board exam date</div>
        </div>
      </div>

      <!-- Daily Goal -->
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px">
        <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#22c55e;margin-bottom:10px">🎯 DAILY GOAL</div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
          <input type="number" id="dailyGoalInput" value="${data.dailyGoalMinutes}" min="15" max="480" step="15" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e8f0;padding:8px 10px;font-size:1.2rem;font-weight:700;width:80px;text-align:center" onchange="LS.set('daily_goal_mins',+this.value)">
          <span style="color:#64748b;font-size:.85rem">minutes / day</span>
        </div>
        <div style="background:rgba(255,255,255,.06);border-radius:99px;height:8px;overflow:hidden;margin-bottom:6px">
          <div style="height:100%;width:${Math.min(100, donePct)}%;background:linear-gradient(90deg,#22c55e,#06b6d4);border-radius:99px;transition:.5s"></div>
        </div>
        <div style="font-size:.78rem;color:#64748b">${allTasks.filter(t=>t.done).length}/${allTasks.length} tasks complete · ${donePct}%</div>
      </div>

      <!-- Quick add task -->
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px">
        <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#8b5cf6;margin-bottom:10px">➕ ADD TASK</div>
        <input id="newTaskInput" type="text" placeholder="e.g. Revise Polynomials" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e8f0;padding:8px 10px;font-size:.88rem;width:100%;box-sizing:border-box;margin-bottom:8px" onkeydown="if(event.key==='Enter')addPlannerTask()">
        <div style="display:flex;gap:6px;margin-bottom:10px">
          <select id="newTaskSubject" style="flex:1;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e8f0;padding:6px 8px;font-size:.8rem">
            <option value="">Subject</option>
            <option>Mathematics</option><option>Science</option><option>English</option>
            <option>Social Studies</option><option>Hindi</option>
          </select>
          <select id="newTaskPriority" style="flex:1;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#e2e8f0;padding:6px 8px;font-size:.8rem">
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="low">Low</option>
          </select>
        </div>
        <button onclick="addPlannerTask()" style="width:100%;padding:9px;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;border-radius:10px;color:#fff;font-weight:700;cursor:pointer;font-size:.88rem">+ Add Task</button>
      </div>
    </div>

    <!-- Task list -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:20px;overflow:hidden">
      <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <div style="font-weight:700">📋 All Tasks</div>
        <div style="display:flex;gap:6px">
          <button onclick="clearDoneTasks()" style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:5px 12px;cursor:pointer;font-size:.8rem">🗑 Clear Done</button>
        </div>
      </div>
      <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px" id="taskList">
        ${allTasks.length === 0 ? '<div style="text-align:center;color:#64748b;padding:30px;font-size:.9rem">No tasks yet. Add your first study task!</div>' :
          allTasks.map(t => `
            <div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:12px;transition:.15s" onmouseenter="this.style.background='rgba(255,255,255,.06)'" onmouseleave="this.style.background='rgba(255,255,255,.03)'">
              <div onclick="togglePlannerTask(${t.id})" style="width:20px;height:20px;border-radius:5px;border:2px solid ${t.done ? '#22c55e' : '#475569'};background:${t.done ? '#22c55e' : 'transparent'};display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;transition:.15s">
                ${t.done ? '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : ''}
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:.9rem;color:${t.done ? '#475569' : '#e2e8f0'};text-decoration:${t.done ? 'line-through' : 'none'};font-weight:${t.done ? '400' : '500'}">${t.text}</div>
                ${t.subject ? `<div style="font-size:.73rem;color:#64748b;margin-top:2px">${t.subject}</div>` : ''}
              </div>
              <span style="font-size:.7rem;font-weight:700;background:${priorityColors[t.priority] || '#475569'}22;color:${priorityColors[t.priority] || '#475569'};border:1px solid ${priorityColors[t.priority] || '#475569'}44;padding:2px 8px;border-radius:99px;flex-shrink:0">${t.priority || 'med'}</span>
              <button onclick="deletePlannerTask(${t.id})" style="background:none;border:none;color:#475569;cursor:pointer;font-size:.9rem;padding:2px 4px" title="Delete">×</button>
            </div>
          `).join('')
        }
      </div>
    </div>
  `;
}

function addPlannerTask() {
  const text = (document.getElementById('newTaskInput') || {}).value?.trim();
  if (!text) return;
  const subject = (document.getElementById('newTaskSubject') || {}).value || '';
  const priority = (document.getElementById('newTaskPriority') || {}).value || 'medium';
  savePlannerTask({ text, subject, priority });
  const inp = document.getElementById('newTaskInput');
  if (inp) inp.value = '';
}

function clearDoneTasks() {
  const tasks = LS.get('planner_tasks', []).filter(t => !t.done);
  LS.set('planner_tasks', tasks);
  renderPlanner();
}

// ═══════════════════ 9. NOTIFICATIONS ════════════════════════════════
let _notifOpen = false;

function getNotifications() {
  try {
    if (typeof LS === 'undefined') return [];
    const result = LS.get('notifications', null);
    if (Array.isArray(result)) return result;
    // Default notifications for first time
    const defaults = [
      { id: 1, type: 'info', icon: '📢', title: 'Welcome to StudyHub v2!', body: 'New features: Leaderboard, Study Planner, Lecture Hub & more.', time: Date.now() - 3600000, read: false },
      { id: 2, type: 'reminder', icon: '📝', title: 'Mock Test Reminder', body: "You haven't taken a test this week. Start a Mock Test now!", time: Date.now() - 86400000, read: false },
      { id: 3, type: 'tip', icon: '💡', title: 'Study Tip', body: 'Revise your weak chapters regularly using spaced repetition.', time: Date.now() - 172800000, read: true },
    ];
    LS.set('notifications', defaults);
    return defaults;
  } catch { return []; }
}

function markNotifRead(id) {
  const notifs = getNotifications();
  const n = notifs.find(n => n.id === id);
  if (n) n.read = true;
  LS.set('notifications', notifs);
  renderNotifPanel();
  updateNotifBadge();
}

function markAllNotifsRead() {
  const notifs = getNotifications().map(n => ({ ...n, read: true }));
  LS.set('notifications', notifs);
  renderNotifPanel();
  updateNotifBadge();
}

function updateNotifBadge() {
  if (typeof LS === 'undefined') return;
  const notifs = getNotifications();
  const unread = Array.isArray(notifs) ? notifs.filter(n => !n.read).length : 0;
  const badge = document.querySelector('.notif-badge');
  if (badge) {
    badge.textContent = unread;
    badge.style.display = unread > 0 ? '' : 'none';
  }
}

function openNotifPanel() {
  _notifOpen = true;
  const panel = document.getElementById('notifPanel');
  if (panel) { panel.classList.add('open'); renderNotifPanel(); }
}

function closeNotifPanel() {
  _notifOpen = false;
  const panel = document.getElementById('notifPanel');
  if (panel) panel.classList.remove('open');
}

function addNotification(icon, title, body, type = 'info') {
  const notifs = getNotifications();
  notifs.unshift({ id: Date.now(), type, icon, title, body, time: Date.now(), read: false });
  LS.set('notifications', notifs.slice(0, 50));
  updateNotifBadge();
}

function renderNotifPanel() {
  const list = document.getElementById('notifList');
  if (!list) return;
  const notifs = getNotifications();
  if (!notifs.length) {
    list.innerHTML = '<div style="text-align:center;color:#64748b;padding:40px;font-size:.9rem">No notifications</div>';
    return;
  }
  function timeAgo(ts) {
    const diff = (Date.now() - ts) / 1000;
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.round(diff/60) + 'm ago';
    if (diff < 86400) return Math.round(diff/3600) + 'h ago';
    return Math.round(diff/86400) + 'd ago';
  }
  list.innerHTML = notifs.map(n => `
    <div onclick="markNotifRead(${n.id})" style="padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.04);display:flex;gap:12px;cursor:pointer;background:${n.read ? 'transparent' : 'rgba(124,58,237,.06)'};transition:.15s" onmouseenter="this.style.background='rgba(255,255,255,.04)'" onmouseleave="this.style.background='${n.read ? 'transparent' : 'rgba(124,58,237,.06)'}'">
      <span style="font-size:1.4rem;flex-shrink:0;margin-top:2px">${n.icon}</span>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:3px">
          <div style="font-weight:${n.read ? '500' : '700'};font-size:.88rem;color:#e2e8f0">${n.title}</div>
          ${!n.read ? '<div style="width:7px;height:7px;border-radius:50%;background:#8b5cf6;flex-shrink:0"></div>' : ''}
        </div>
        <div style="font-size:.8rem;color:#64748b;line-height:1.4">${n.body}</div>
        <div style="font-size:.72rem;color:#475569;margin-top:4px">${timeAgo(n.time)}</div>
      </div>
    </div>
  `).join('');
}

// ═══════════════════ 10. ADVANCED ADMIN ANALYTICS ════════════════════
function renderAdminAnalytics() {
  const wrap = document.getElementById('adm-analytics');
  if (!wrap) return;
  const history = LS.get('testHistory', []) || [];
  const files = LS.get('files', []) || [];
  const questions = LS.get('questions', []) || [];
  const tasks = LS.get('planner_tasks', []) || [];

  // Subject breakdown
  const subjCounts = {};
  history.forEach(h => {
    const s = h.subject || h.subjects?.[0] || 'Mixed';
    subjCounts[s] = (subjCounts[s] || 0) + 1;
  });
  const maxSubj = Math.max(1, ...Object.values(subjCounts));

  wrap.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:20px">
      ${[
        { icon: '📝', label: 'Total Tests Taken', val: history.length, color: '#8b5cf6' },
        { icon: '📚', label: 'Materials Uploaded', val: files.length, color: '#06b6d4' },
        { icon: '❓', label: 'Questions in Bank', val: questions.length, color: '#22c55e' },
        { icon: '📋', label: 'Planner Tasks', val: tasks.length, color: '#f59e0b' },
      ].map(s => `
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px">
          <div style="font-size:1.6rem;margin-bottom:8px">${s.icon}</div>
          <div style="font-size:2rem;font-weight:800;color:${s.color};line-height:1">${s.val}</div>
          <div style="font-size:.75rem;color:#64748b;margin-top:4px;text-transform:uppercase;letter-spacing:.5px">${s.label}</div>
        </div>
      `).join('')}
    </div>

    <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px;margin-bottom:16px">
      <div style="font-weight:700;margin-bottom:16px">📊 Tests by Subject</div>
      ${Object.keys(subjCounts).length === 0 ? '<div style="color:#64748b;font-size:.88rem">No test data yet</div>' :
        Object.entries(subjCounts).sort((a,b)=>b[1]-a[1]).map(([s,c]) => `
          <div style="margin-bottom:10px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:.85rem;color:#e2e8f0">${s}</span>
              <span style="font-size:.8rem;color:#64748b">${c} tests</span>
            </div>
            <div style="background:rgba(255,255,255,.06);border-radius:99px;height:7px;overflow:hidden">
              <div style="height:100%;width:${Math.round(c/maxSubj*100)}%;background:linear-gradient(90deg,#8b5cf6,#06b6d4);border-radius:99px"></div>
            </div>
          </div>
        `).join('')
      }
    </div>

    <!-- Announcements panel (admin only) -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px">
      <div style="font-weight:700;margin-bottom:14px">📢 Send Announcement</div>
      <input id="announcementTitle" type="text" placeholder="Announcement title…" class="form-input" style="width:100%;box-sizing:border-box;margin-bottom:8px">
      <textarea id="announcementBody" placeholder="Message body…" class="form-input" rows="3" style="width:100%;box-sizing:border-box;resize:vertical;margin-bottom:10px"></textarea>
      <button onclick="sendAnnouncement()" style="background:linear-gradient(135deg,#f59e0b,#ef4444);border:none;color:#fff;border-radius:10px;padding:10px 22px;font-weight:700;cursor:pointer">📢 Send to All Students</button>
      <div id="announceSentMsg" style="font-size:.82rem;color:#22c55e;margin-top:8px;display:none">✅ Announcement sent!</div>
    </div>
  `;
}

function sendAnnouncement() {
  const title = (document.getElementById('announcementTitle') || {}).value?.trim();
  const body = (document.getElementById('announcementBody') || {}).value?.trim();
  if (!title || !body) return;
  addNotification('📢', title, body, 'announcement');
  const msg = document.getElementById('announceSentMsg');
  if (msg) { msg.style.display = ''; setTimeout(() => { msg.style.display = 'none'; }, 3000); }
  document.getElementById('announcementTitle').value = '';
  document.getElementById('announcementBody').value = '';
}

// ═══════════════════ PATCH showPage ══════════════════════════════════
window.addEventListener('load', function() {
  const _orig = window.showPage;
  window.showPage = function(id) {
    if (_orig) _orig.call(this, id);
    if (id === 'lectures')    { setTimeout(renderLecturePage,  50); }
    if (id === 'leaderboard') { setTimeout(renderLeaderboard,  50); }
    if (id === 'planner')     { setTimeout(renderPlanner,      50); }
    if (id === 'premium')     { setTimeout(renderPremiumPage,  50); }
    if (id === 'admin') {
      setTimeout(() => {
        if (!document.getElementById('adm-analytics')) {
          const tabs = document.querySelector('.adm-tabs');
          if (tabs) {
            const btn = document.createElement('button');
            btn.className = 'adm-tab';
            btn.innerHTML = '📈 Analytics';
            btn.onclick = function() { admTab('analytics', this); renderAdminAnalytics(); };
            tabs.appendChild(btn);
          }
          const overview = document.getElementById('adm-overview');
          if (overview && overview.parentNode) {
            const div = document.createElement('div');
            div.className = 'adm-section';
            div.id = 'adm-analytics';
            overview.parentNode.insertBefore(div, overview.nextSibling);
          }
        }
        renderAdminAnalytics();
      }, 100);
    }
  };
});

// ═══════════════════ KEYBOARD SHORTCUT (Cmd/Ctrl+K) ════════════════
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    if (searchOpen) closeGlobalSearch();
    else openGlobalSearch();
  }
  if (e.key === 'Escape') {
    closeGlobalSearch();
    closeNotifPanel();
  }
});

// ═══════════════════ INIT ════════════════════════════════════════════
onReady(() => {
  // Inject notification panel
  if (!document.getElementById('notifPanel')) {
    const panel = document.createElement('div');
    panel.id = 'notifPanel';
    panel.className = 'notif-panel';
    panel.innerHTML = `
      <div class="notif-header">
        <span style="font-weight:700">🔔 Notifications</span>
        <div style="display:flex;gap:8px;align-items:center">
          <button onclick="markAllNotifsRead()" style="font-size:.75rem;color:#8b5cf6;background:none;border:none;cursor:pointer;font-weight:600">Mark all read</button>
          <button onclick="closeNotifPanel()" style="background:rgba(255,255,255,.08);border:none;color:#e2e8f0;border-radius:6px;padding:3px 8px;cursor:pointer">✕</button>
        </div>
      </div>
      <div id="notifList"></div>
    `;
    document.body.appendChild(panel);
  }

  // Inject global search modal
  if (!document.getElementById('globalSearchModal')) {
    const modal = document.createElement('div');
    modal.id = 'globalSearchModal';
    modal.className = 'global-search-modal';
    modal.innerHTML = `
      <div class="global-search-inner" onclick="event.stopPropagation()">
        <div class="global-search-bar">
          <span style="font-size:1.1rem;color:#64748b">🔍</span>
          <input id="globalSearchInput" placeholder="Search notes, questions, topics…" autocomplete="off"
            oninput="renderSearchResults(this.value)"
            onkeydown="handleSearchKeydown(event)">
          <kbd style="font-size:.7rem;color:#475569;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:4px;padding:2px 6px">ESC</kbd>
        </div>
        <div id="searchResultsList" class="search-results-list"></div>
      </div>
    `;
    modal.addEventListener('click', closeGlobalSearch);
    document.body.appendChild(modal);
  }

  // Patch notification bell to open panel
  const bell = document.querySelector('.icon-btn');
  if (bell) {
    bell.onclick = () => {
      if (_notifOpen) closeNotifPanel();
      else openNotifPanel();
    };
  }

  // Patch search bar to open global search
  const searchInput = document.querySelector('.search-input');
  if (searchInput) {
    searchInput.onfocus = openGlobalSearch;
    searchInput.setAttribute('readonly', true);
    searchInput.style.cursor = 'pointer';
  }

  // Add new nav items for new pages
  const navList = document.getElementById('sidebarNav');
  if (navList) {
    const navSep = navList.querySelector('.nav-sep');
    const newNavItems = [
      { id: 'lectures', icon: '🎥', label: 'Lecture Hub' },
      { id: 'leaderboard', icon: '🏆', label: 'Leaderboard' },
      { id: 'planner', icon: '📅', label: 'Study Planner' },
    ];
    newNavItems.forEach(item => {
      if (!document.querySelector(`[data-nav="${item.id}"]`)) {
        const btn = document.createElement('button');
        btn.className = 'nav-item';
        btn.dataset.nav = item.id;
        btn.innerHTML = `${item.icon} ${item.label}`;
        btn.onclick = () => showPage(item.id);
        navList.insertBefore(btn, navSep);
      }
    });
  }

  // Create page placeholders for new pages
  ['lectures', 'leaderboard', 'planner'].forEach(id => {
    if (!document.getElementById(id)) {
      const content = document.querySelector('.content');
      if (content) {
        const div = document.createElement('div');
        div.className = 'page';
        div.id = id;
        content.appendChild(div);
      }
    }
  });

  // Update notification badge
  updateNotifBadge();

  // Start periodic tip notifications
  setTimeout(() => {
    addNotification('📊', 'Time to practice!', 'You haven\'t taken a test today. Keep your streak alive!', 'reminder');
  }, 30000);
});

// ═══════════════════ SEARCH KEYBOARD HANDLER ═════════════════════════
window.handleSearchKeydown = function(e) {
  const items = document.querySelectorAll('.search-result-item');
  let activeIdx = -1;
  items.forEach((el, i) => { if (el.classList.contains('active')) activeIdx = i; });
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    const next = Math.min(activeIdx + 1, items.length - 1);
    items.forEach(el => el.classList.remove('active'));
    if (items[next]) items[next].classList.add('active');
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    const prev = Math.max(activeIdx - 1, 0);
    items.forEach(el => el.classList.remove('active'));
    if (items[prev]) items[prev].classList.add('active');
  } else if (e.key === 'Enter') {
    if (activeIdx >= 0) execSearch(activeIdx);
    else if ((window._searchResults || []).length > 0) execSearch(0);
  }
};

// Expose needed globals
window.trackDownload = trackDownload;
window.togglePlannerTask = togglePlannerTask;
window.deletePlannerTask = deletePlannerTask;
window.addPlannerTask = addPlannerTask;
window.clearDoneTasks = clearDoneTasks;
window.playLecture = playLecture;
window.closeLecturePlayer = closeLecturePlayer;
window.switchLectureSubject = switchLectureSubject;
window.switchLectureSection = switchLectureSection;
window.toggleLectureAdmin = toggleLectureAdmin;
window.submitAddLecture = submitAddLecture;
window.confirmDeleteLecture = confirmDeleteLecture;
window.submitReplaceLecture = submitReplaceLecture;
window.extractYTId = extractYTId;
window.openGlobalSearch = openGlobalSearch;
window.closeGlobalSearch = closeGlobalSearch;
window.renderSearchResults = renderSearchResults;
window.execSearch = execSearch;
window.openNotifPanel = openNotifPanel;
window.closeNotifPanel = closeNotifPanel;
window.markNotifRead = markNotifRead;
window.markAllNotifsRead = markAllNotifsRead;
window.addNotification = addNotification;
window.sendAnnouncement = sendAnnouncement;
window.LS = LS;
