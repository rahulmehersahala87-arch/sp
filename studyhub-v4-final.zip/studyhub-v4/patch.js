// ═══════════════════════════════════════════════════════════════════
//  StudyHub patch.js — v7
//  • PDF open fix (blob URL + fallback chain)
//  • Materials section hidden (admin-only, not in main nav)
//  • Notes Hub  — admin add/edit/delete
//  • Formula Hub — admin add/edit/delete
//  • Lecture Hub — admin add/edit/delete (YouTube)
//  • Study Planner — admin controls for content
//  • Scroll + mobile CSS
//  • Loading screen fix, double-submit guard
// ═══════════════════════════════════════════════════════════════════

// ── showPage ─────────────────────────────────────────────────────────
function showPage(id) {
  if(id==='admin'&&!isAdmin()){showToast('🔒 Admin only','error');return;}
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const pg = document.getElementById(id);
  if(pg) pg.classList.add('active');
  document.querySelectorAll('.nav-list .nav-item').forEach(t=>t.classList.remove('active'));
  const navMap={home:0,dashboard:1,rooms:2,pyq:3,test:4,history:5};
  const idx=navMap[id];
  if(idx!==undefined){
    const items=document.querySelectorAll('.nav-list .nav-item');
    if(items[idx]) items[idx].classList.add('active');
  }
  document.querySelectorAll('.bottom-nav-btn').forEach(b=>b.classList.remove('active'));
  const pageMap={home:0,test:1,aitutor:2,premium:3};
  const bIdx=pageMap[id];
  const btns=document.querySelectorAll('.bottom-nav-btn');
  if(bIdx!==undefined&&btns[bIdx]) btns[bIdx].classList.add('active');
  const sidebar=document.getElementById('mainNav');
  const backdrop=document.getElementById('sidebarBackdrop');
  if(window.innerWidth<=768){
    if(sidebar) sidebar.classList.remove('mobile-open','open');
    if(backdrop) backdrop.classList.remove('active');
  }
  const contentEl=document.querySelector('.content');
  if(contentEl) contentEl.scrollTop=0;
  if(id==='history') renderHistory();
  if(id==='home') updateHomeStats();
  if(id==='dashboard') renderDashboard();
  if(id==='admin'){if(typeof renderAdminPanel==='function')renderAdminPanel();}
  if(id==='editor'){if(typeof applyEditorPermissions==='function')applyEditorPermissions();renderQTable();}
  if(id==='pyq'){if(typeof updatePYQChapterFilter==='function')updatePYQChapterFilter();if(typeof renderPYQ==='function')renderPYQ();}
  if(id==='upload'){if(typeof applyUploadPermissions==='function')applyUploadPermissions();renderFiles();}
  if(id==='rooms') initRooms();
  if(id==='aiquiz'){if(typeof initAIQuizPage==='function')initAIQuizPage();if(typeof renderComingSoonStatus==='function')setTimeout(renderComingSoonStatus,50);}
  if(id==='lectures') renderLecturePage();
  if(id==='planner') renderPlanner();
  if(id==='noteshub') renderNotesHub();
  if(id==='formulahub') renderFormulaHub();
  closeMobileNav();
}

function toggleMobileNav(){const nav=document.getElementById('mainNav');const overlay=document.getElementById('navOverlay');const open=nav.classList.toggle('mobile-open');if(overlay)overlay.classList.toggle('open',open);}
function closeMobileNav(){const nav=document.getElementById('mainNav');const overlay=document.getElementById('navOverlay');if(nav)nav.classList.remove('mobile-open');if(overlay)overlay.classList.remove('open');}
function toggleMobileSidebar(){const s=document.getElementById('mainNav');const b=document.getElementById('sidebarBackdrop');if(!s)return;const open=s.classList.contains('mobile-open')||s.classList.contains('open');if(open){s.classList.remove('mobile-open','open');if(b)b.classList.remove('active');}else{s.classList.add('mobile-open','open');if(b)b.classList.add('active');}}
window.toggleMobileSidebar=toggleMobileSidebar;

// ── debouncePersist ───────────────────────────────────────────────────
if(typeof debouncePersist==='undefined'){let _t=null;window.debouncePersist=function(){clearTimeout(_t);_t=setTimeout(()=>{try{if(typeof currentUser!=='undefined'&&currentUser&&typeof saveUserData==='function'){const ud=typeof getUserData==='function'?getUserData():null;if(ud)saveUserData(currentUser.uid,ud);}}catch(e){}},800);};}

// ── Fix 1: Splash screen (load event already fired — patch synchronously) ──
function hideSplash(){const s=document.getElementById('authSplash');if(!s)return;s.style.opacity='0';setTimeout(()=>{s.style.display='none';},400);}
(function(){const o=window.enterApp;if(typeof o==='function')window.enterApp=function(){hideSplash();o.apply(this,arguments);}})();
(function(){const o=window.setAuthLoading;if(typeof o==='function')window.setAuthLoading=function(on){if(!on)hideSplash();o.apply(this,arguments);}})();
setTimeout(hideSplash,5000);

// ── Fix 2: Double-submit guard ────────────────────────────────────────
(function(){let _f=false;['doLogin','doSignup'].forEach(fn=>{const o=window[fn];if(typeof o==='function')window[fn]=async function(){if(_f)return;_f=true;try{await o.apply(this,arguments);}finally{_f=false;}};});})();

// ── Fix 3: Empty states ───────────────────────────────────────────────
function renderEmptyState(c,icon,title,body,btnText,btnAction){if(!c)return;c.innerHTML=`<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;text-align:center;gap:16px"><div style="font-size:3.5rem">${icon}</div><div style="font-weight:700;font-size:1.1rem;color:#e2e8f0">${title}</div><div style="font-size:.88rem;color:#64748b;max-width:320px;line-height:1.6">${body}</div>${btnText?`<button onclick="${btnAction}" style="margin-top:8px;padding:10px 24px;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;border-radius:12px;color:#fff;font-weight:700;cursor:pointer">${btnText}</button>`:''}</div>`;}
window.renderEmptyState=renderEmptyState;
(function(){const o=window.renderFiles;if(typeof o==='function')window.renderFiles=function(){o.apply(this,arguments);setTimeout(()=>{const g=document.getElementById('filesGrid')||document.getElementById('filesList');if(g&&g.children.length===0)renderEmptyState(g,'📄','No study materials yet','Upload your first PDF, notes, or lecture to get started.','+ Upload Material',"showPage('upload')");},200);}})();

// ══════════════════════════════════════════════════════════════════════
//  PDF FIX — reliable PDF opening for all storage types
// ══════════════════════════════════════════════════════════════════════
(function patchViewFile() {
  const orig = window.viewFile;
  if (typeof orig !== 'function') return;

  window.viewFile = function(id) {
    // Call original to set up modal chrome (title, icon, download btn)
    orig.call(this, id);

    // Now check if it's a PDF and override the body content
    const f = (typeof files !== 'undefined' ? files : []).find(x => x.id === id);
    if (!f) return;
    const ext = (f.name || '').split('.').pop().toLowerCase();
    if (ext !== 'pdf') return;

    const body = document.getElementById('viewerBody');
    if (!body) return;

    const isCloud = f.storage === 'cloudinary' && f.cloudinaryUrl;
    const src = isCloud ? f.cloudinaryUrl : f.dataURL;

    if (!src) return;

    if (isCloud) {
      // Cloud PDF: try direct iframe first, fallback to Google Docs viewer
      body.innerHTML = `
        <div id="__pdfLoadMsg" style="text-align:center;padding:20px;color:#94a3b8;font-size:.85rem">
          ⏳ Loading PDF…
        </div>
        <iframe
          id="__pdfFrame"
          src="${src}#toolbar=1&view=FitH"
          style="width:100%;height:72vh;border:none;border-radius:8px;display:none"
          onload="document.getElementById('__pdfLoadMsg').style.display='none';this.style.display='block'"
          onerror="__pdfFallbackGDocs('${encodeURIComponent(src)}')"
        ></iframe>
        <p style="text-align:center;margin-top:10px;font-size:.8rem;color:#64748b">
          <a href="${src}" target="_blank" rel="noopener" style="color:#8b5cf6">🔗 Open in new tab</a>
          &nbsp;·&nbsp;
          <a onclick="__pdfFallbackGDocs('${encodeURIComponent(src)}')" style="color:#8b5cf6;cursor:pointer">
            Use Google Docs viewer
          </a>
        </p>`;
    } else {
      // Local dataURL PDF — convert to blob URL for maximum browser compatibility
      try {
        const b64 = src.split(',')[1];
        const byteChars = atob(b64);
        const byteNums = new Array(byteChars.length);
        for (let i = 0; i < byteChars.length; i++) byteNums[i] = byteChars.charCodeAt(i);
        const blob = new Blob([new Uint8Array(byteNums)], { type: 'application/pdf' });
        const blobUrl = URL.createObjectURL(blob);

        body.innerHTML = `
          <iframe
            src="${blobUrl}#toolbar=1&view=FitH"
            style="width:100%;height:72vh;border:none;border-radius:8px"
            onload="this.style.display='block'"
          ></iframe>
          <p style="text-align:center;margin-top:8px;font-size:.8rem;color:#64748b">
            <a href="${blobUrl}" download="${f.name}" style="color:#8b5cf6">⬇️ Download PDF</a>
          </p>`;

        // Clean up blob URL when viewer closes
        const closeBtn = document.querySelector('[onclick="closeViewer()"]');
        if (closeBtn) {
          const origClose = window.closeViewer;
          window.closeViewer = function() {
            URL.revokeObjectURL(blobUrl);
            window.closeViewer = origClose;
            if (origClose) origClose();
          };
        }
      } catch(e) {
        // Fallback: embed tag
        body.innerHTML = `
          <embed src="${src}" type="application/pdf" width="100%" height="520"
                 style="border-radius:8px">
          <p style="text-align:center;margin-top:12px;color:#64748b;font-size:.85rem">
            If PDF doesn't display, use the Download button above.
          </p>`;
      }
    }
  };
})();

window.__pdfFallbackGDocs = function(encodedUrl) {
  const body = document.getElementById('viewerBody');
  if (!body) return;
  const gdUrl = `https://docs.google.com/viewer?url=${encodedUrl}&embedded=true`;
  body.innerHTML = `
    <iframe src="${gdUrl}" width="100%" height="520"
            style="border:none;border-radius:8px"></iframe>
    <p style="text-align:center;margin-top:10px;font-size:.8rem;color:#64748b">
      <a href="${decodeURIComponent(encodedUrl)}" target="_blank" rel="noopener"
         style="color:#8b5cf6">Open PDF directly ↗</a>
    </p>`;
};

// ══════════════════════════════════════════════════════════════════════
//  HIDE "Materials" from navigation for non-admins
//  Admin can still access it via Admin Panel > Uploads
// ══════════════════════════════════════════════════════════════════════
(function hideMaterialsNav() {
  function applyMaterialsVisibility() {
    const uploadTab = document.getElementById('uploadTab');
    if (!uploadTab) return;
    if (typeof isAdmin === 'function' && isAdmin()) {
      uploadTab.style.display = ''; // Admin can see it
    } else {
      uploadTab.style.display = 'none'; // Hidden for students
    }
  }
  const origEnter = window.enterApp;
  if (typeof origEnter === 'function') {
    window.enterApp = function() {
      origEnter.apply(this, arguments);
      setTimeout(applyMaterialsVisibility, 100);
    };
  }
})();

// ══════════════════════════════════════════════════════════════════════
//  LECTURE HUB — admin add / edit / delete
// ══════════════════════════════════════════════════════════════════════
(function patchLectureHub() {

  function getLectures() {
    try {
      const saved = localStorage.getItem('sh_lectures_v2');
      if (saved) return JSON.parse(saved);
    } catch(e) {}
    // Seed from original LECTURE_PLAYLISTS
    if (typeof LECTURE_PLAYLISTS !== 'undefined') {
      const data = {};
      Object.keys(LECTURE_PLAYLISTS).forEach(subj => {
        data[subj] = LECTURE_PLAYLISTS[subj].map((l, i) => ({
          ...l, id: `${subj}_${i}_${Date.now()}_${Math.random().toString(36).slice(2)}`
        }));
      });
      localStorage.setItem('sh_lectures_v2', JSON.stringify(data));
      return data;
    }
    return {};
  }

  function saveLectures(data) {
    localStorage.setItem('sh_lectures_v2', JSON.stringify(data));
  }

  // Override renderLecturePage
  window.renderLecturePage = function() {
    const page = document.getElementById('lectures');
    if (!page) return;
    const data = getLectures();
    const subjects = Object.keys(data);
    const admin = typeof isAdmin === 'function' && isAdmin();
    const subj = window._currentLectureSubject || subjects[0] || 'Mathematics';
    window._currentLectureSubject = subj;
    const lectures = data[subj] || [];

    page.innerHTML = `
      <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#f59e0b">🎥 LECTURE HUB</div>
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin:0">Video <span style="background:linear-gradient(135deg,#f59e0b,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Lectures</span></h1>
        ${admin ? `<div style="display:flex;gap:8px">
          <button onclick="__lectureAddSubject()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#e2e8f0;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem">+ Subject</button>
          <button onclick="__lectureAdd('${subj}')" style="background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;color:#fff;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem;font-weight:700">+ Add Lecture</button>
        </div>` : ''}
      </div>
      <p style="color:#64748b;font-size:.9rem;margin-bottom:20px">Chapter-wise YouTube lectures for all subjects.</p>

      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:22px" id="lectureSubjTabs">
        ${subjects.map(s => `
          <div style="display:inline-flex;align-items:center;gap:4px">
            <button onclick="window._currentLectureSubject='${s}';renderLecturePage()" style="padding:7px 16px;border-radius:99px;border:none;cursor:pointer;font-size:.82rem;font-weight:600;background:${s===subj?'linear-gradient(135deg,#7c3aed,#06b6d4)':'rgba(255,255,255,.07)'};color:${s===subj?'#fff':'#94a3b8'}">${s}</button>
            ${admin && subjects.length > 1 ? `<button onclick="__lectureDeleteSubject('${s}')" style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171;border-radius:6px;padding:2px 6px;cursor:pointer;font-size:.72rem" title="Delete subject">✕</button>` : ''}
          </div>`).join('')}
      </div>

      <div id="lecturePlayerWrap" style="display:none;background:var(--surface);border:1px solid var(--border);border-radius:20px;overflow:hidden;margin-bottom:20px">
        <div style="position:relative;padding-bottom:56.25%;height:0">
          <iframe id="lectureIframe" src="" frameborder="0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%"></iframe>
        </div>
        <div style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div>
            <div id="lecturePlaying" style="font-weight:700;font-size:1rem;color:#e2e8f0">Loading…</div>
            <div style="font-size:.8rem;color:#64748b;margin-top:2px" id="lectureSubjLabel">${subj}</div>
          </div>
          <button onclick="closeLecturePlayer()" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#e2e8f0;border-radius:10px;padding:6px 14px;cursor:pointer;font-size:.85rem">✕ Close</button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:14px">
        ${lectures.length === 0 ? `<div style="grid-column:1/-1;text-align:center;color:#64748b;padding:40px">${admin ? 'No lectures yet. Click "+ Add Lecture" to add one.' : 'No lectures available yet.'}</div>` :
          lectures.map((l, i) => `
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;cursor:pointer;transition:.2s" onmouseenter="this.style.borderColor='rgba(124,58,237,.5)'" onmouseleave="this.style.borderColor='var(--border)'" onclick="playLecture('${l.yt}','${(l.title||'').replace(/'/g,"\\'")}','${subj}')">
              <div style="background:linear-gradient(135deg,rgba(124,58,237,.15),rgba(6,182,212,.08));aspect-ratio:16/9;display:flex;align-items:center;justify-content:center;position:relative">
                <img src="https://img.youtube.com/vi/${l.yt}/mqdefault.jpg" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;opacity:.7" loading="lazy">
                <div style="position:relative;z-index:1;width:48px;height:48px;background:rgba(0,0,0,.7);border-radius:50%;display:flex;align-items:center;justify-content:center">
                  <div style="width:0;height:0;border-style:solid;border-width:10px 0 10px 18px;border-color:transparent transparent transparent #fff;margin-left:3px"></div>
                </div>
              </div>
              <div style="padding:14px 16px">
                <div style="font-weight:600;font-size:.9rem;color:#e2e8f0;margin-bottom:4px">${l.title}</div>
                <div style="font-size:.78rem;color:#64748b">${l.duration || ''}</div>
                ${admin ? `<div style="display:flex;gap:6px;margin-top:10px" onclick="event.stopPropagation()">
                  <button onclick="__lectureEdit('${subj}','${l.id}')" style="flex:1;background:rgba(124,58,237,.15);border:1px solid rgba(124,58,237,.3);color:#c4b5fd;border-radius:8px;padding:5px 0;cursor:pointer;font-size:.78rem">✏️ Edit</button>
                  <button onclick="__lectureDelete('${subj}','${l.id}')" style="flex:1;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:5px 0;cursor:pointer;font-size:.78rem">🗑️ Delete</button>
                </div>` : ''}
              </div>
            </div>`).join('')}
      </div>`;
  };

  window.__lectureAdd = function(subj) { __lectureModal(subj, null); };
  window.__lectureEdit = function(subj, id) { __lectureModal(subj, id); };
  window.__lectureAddSubject = function() {
    const name = prompt('Subject name:');
    if (!name || !name.trim()) return;
    const data = getLectures();
    if (data[name.trim()]) { showToast('Subject already exists', 'error'); return; }
    data[name.trim()] = [];
    saveLectures(data);
    window._currentLectureSubject = name.trim();
    renderLecturePage();
  };
  window.__lectureDeleteSubject = function(subj) {
    if (!confirm(`Delete entire subject "${subj}" and all its lectures?`)) return;
    const data = getLectures();
    delete data[subj];
    saveLectures(data);
    const subjects = Object.keys(data);
    window._currentLectureSubject = subjects[0] || '';
    renderLecturePage();
  };
  window.__lectureDelete = function(subj, id) {
    if (!confirm('Delete this lecture?')) return;
    const data = getLectures();
    data[subj] = (data[subj] || []).filter(l => l.id !== id);
    saveLectures(data);
    renderLecturePage();
  };

  function __lectureModal(subj, editId) {
    const data = getLectures();
    const existing = editId ? (data[subj] || []).find(l => l.id === editId) : null;
    let modal = document.getElementById('__lectureModal');
    if (!modal) { modal = document.createElement('div'); modal.id = '__lectureModal'; document.body.appendChild(modal); }
    modal.style.cssText = 'position:fixed;inset:0;z-index:9100;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.75);padding:16px';
    modal.innerHTML = `
      <div style="background:#1e1b4b;border:1px solid rgba(124,58,237,.4);border-radius:20px;padding:24px;width:100%;max-width:440px;max-height:90vh;overflow-y:auto">
        <h3 style="margin:0 0 18px;color:#e2e8f0;font-size:1rem">${editId ? '✏️ Edit Lecture' : '➕ Add Lecture'}</h3>
        <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Title *</label>
        <input id="__lm_title" class="form-input" value="${existing ? existing.title : ''}" placeholder="e.g. Real Numbers" style="width:100%;box-sizing:border-box;margin-bottom:12px">
        <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">YouTube Video ID * <span style="color:#64748b">(from youtube.com/watch?v=<b>ID</b>)</span></label>
        <input id="__lm_yt" class="form-input" value="${existing ? existing.yt : ''}" placeholder="e.g. 5yw_J_OHiKk" style="width:100%;box-sizing:border-box;margin-bottom:12px">
        <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Duration</label>
        <input id="__lm_dur" class="form-input" value="${existing ? (existing.duration||'') : ''}" placeholder="e.g. 25 min" style="width:100%;box-sizing:border-box;margin-bottom:18px">
        <p id="__lm_err" style="color:#f87171;font-size:.8rem;margin:0 0 10px;display:none"></p>
        <div style="display:flex;gap:10px">
          <button onclick="__lectureSave('${subj}','${editId||''}')" style="flex:1;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;color:#fff;border-radius:12px;padding:11px;font-weight:700;cursor:pointer">💾 Save</button>
          <button onclick="document.getElementById('__lectureModal').style.display='none'" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:12px;padding:11px 16px;cursor:pointer">Cancel</button>
        </div>
      </div>`;
    modal.style.display = 'flex';
  }
  window.__lectureSave = function(subj, editId) {
    const title = document.getElementById('__lm_title').value.trim();
    const yt    = document.getElementById('__lm_yt').value.trim().replace(/.*v=|.*youtu\.be\//,'').split('&')[0];
    const dur   = document.getElementById('__lm_dur').value.trim();
    const err   = document.getElementById('__lm_err');
    if (!title || !yt) { err.textContent = '❌ Title and YouTube ID are required'; err.style.display='block'; return; }
    const data = getLectures();
    if (!data[subj]) data[subj] = [];
    if (editId) {
      const idx = data[subj].findIndex(l => l.id === editId);
      if (idx !== -1) { data[subj][idx] = { ...data[subj][idx], title, yt, duration: dur }; }
    } else {
      data[subj].push({ id: `lect_${Date.now()}_${Math.random().toString(36).slice(2)}`, title, yt, duration: dur });
    }
    saveLectures(data);
    document.getElementById('__lectureModal').style.display = 'none';
    renderLecturePage();
    showToast(editId ? '✅ Lecture updated!' : '✅ Lecture added!', 'success');
  };

  window.switchLectureSubject = function(subj) { window._currentLectureSubject = subj; renderLecturePage(); };
  window.playLecture = function(ytId, title, subj) {
    const wrap = document.getElementById('lecturePlayerWrap');
    const iframe = document.getElementById('lectureIframe');
    const label = document.getElementById('lecturePlaying');
    const subjLabel = document.getElementById('lectureSubjLabel');
    if (!wrap || !iframe) return;
    iframe.src = `https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0`;
    if (label) label.textContent = title;
    if (subjLabel) subjLabel.textContent = subj;
    wrap.style.display = 'block';
    wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  window.closeLecturePlayer = function() {
    const wrap = document.getElementById('lecturePlayerWrap');
    const iframe = document.getElementById('lectureIframe');
    if (iframe) iframe.src = '';
    if (wrap) wrap.style.display = 'none';
  };
})();

// ══════════════════════════════════════════════════════════════════════
//  NOTES HUB — new page, admin add/edit/delete
// ══════════════════════════════════════════════════════════════════════
(function buildNotesHub() {
  // Create page element if not exists
  function ensurePage() {
    if (document.getElementById('noteshub')) return;
    const pg = document.createElement('div');
    pg.id = 'noteshub';
    pg.className = 'page';
    document.querySelector('.content') && document.querySelector('.content').appendChild(pg);
    // fallback: insert into main content area
    const shell = document.getElementById('appShell') || document.querySelector('.content') || document.body;
    shell.appendChild(pg);
  }

  function getNotes() {
    try { const s = localStorage.getItem('sh_notes_hub'); if(s) return JSON.parse(s); } catch(e) {}
    return {
      Mathematics: [
        { id:'n1', title:'Real Numbers — Key Concepts', content:'• Euclid\'s Division Lemma: a = bq + r\n• HCF & LCM: HCF × LCM = Product of two numbers\n• Irrational numbers cannot be written as p/q', tags:['formula','concept'] },
        { id:'n2', title:'Quadratic Formula', content:'x = (−b ± √(b²−4ac)) / 2a\nFor ax² + bx + c = 0\nDiscriminant D = b²−4ac', tags:['formula'] },
      ],
      Science: [
        { id:'n3', title:'Chemical Reactions — Types', content:'1. Combination: A + B → AB\n2. Decomposition: AB → A + B\n3. Displacement: A + BC → AC + B\n4. Double Displacement: AB + CD → AD + CB', tags:['concept'] },
      ],
      English: [
        { id:'n4', title:'Letter Writing Format', content:'Sender\'s Address\nDate\nReceiver\'s Address\nSubject\nSalutation\nBody\nClosing', tags:['format'] },
      ],
    };
  }
  function saveNotes(data) { localStorage.setItem('sh_notes_hub', JSON.stringify(data)); }

  window.renderNotesHub = function() {
    ensurePage();
    const page = document.getElementById('noteshub');
    if (!page) return;
    const data = getNotes();
    const subjects = Object.keys(data);
    const admin = typeof isAdmin === 'function' && isAdmin();
    const subj = window._notesHubSubj || subjects[0] || 'Mathematics';
    window._notesHubSubj = subj;
    const notes = data[subj] || [];

    page.innerHTML = `
      <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#22c55e">📒 NOTES HUB</div>
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin:0">Study <span style="background:linear-gradient(135deg,#22c55e,#06b6d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Notes</span></h1>
        ${admin ? `<div style="display:flex;gap:8px">
          <button onclick="__notesAddSubject()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#e2e8f0;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem">+ Subject</button>
          <button onclick="__notesModal('${subj}',null)" style="background:linear-gradient(135deg,#22c55e,#06b6d4);border:none;color:#fff;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem;font-weight:700">+ Add Note</button>
        </div>` : ''}
      </div>
      <p style="color:#64748b;font-size:.9rem;margin-bottom:20px">Quick-access notes, summaries and key concepts for every subject.</p>

      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:22px">
        ${subjects.map(s => `
          <div style="display:inline-flex;align-items:center;gap:4px">
            <button onclick="window._notesHubSubj='${s}';renderNotesHub()" style="padding:7px 16px;border-radius:99px;border:none;cursor:pointer;font-size:.82rem;font-weight:600;background:${s===subj?'linear-gradient(135deg,#22c55e,#06b6d4)':'rgba(255,255,255,.07)'};color:${s===subj?'#fff':'#94a3b8'}">${s}</button>
            ${admin && subjects.length > 1 ? `<button onclick="__notesDeleteSubject('${s}')" style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171;border-radius:6px;padding:2px 6px;cursor:pointer;font-size:.72rem">✕</button>` : ''}
          </div>`).join('')}
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px">
        ${notes.length === 0 ? `<div style="grid-column:1/-1;text-align:center;color:#64748b;padding:40px">${admin ? 'No notes yet. Click "+ Add Note".' : 'No notes available.'}</div>` :
          notes.map(n => `
            <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:20px;transition:.2s" onmouseenter="this.style.borderColor='rgba(34,197,94,.4)'" onmouseleave="this.style.borderColor='var(--border)'">
              <div style="font-weight:700;font-size:.95rem;color:#e2e8f0;margin-bottom:10px">${n.title}</div>
              <pre style="white-space:pre-wrap;word-break:break-word;font-family:inherit;font-size:.82rem;color:#94a3b8;line-height:1.7;margin:0 0 12px;max-height:160px;overflow:hidden">${n.content}</pre>
              ${(n.tags||[]).length ? `<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px">${n.tags.map(t=>`<span style="background:rgba(34,197,94,.12);color:#22c55e;border-radius:6px;padding:2px 8px;font-size:.72rem">${t}</span>`).join('')}</div>` : ''}
              ${admin ? `<div style="display:flex;gap:6px">
                <button onclick="__notesModal('${subj}','${n.id}')" style="flex:1;background:rgba(124,58,237,.15);border:1px solid rgba(124,58,237,.3);color:#c4b5fd;border-radius:8px;padding:6px 0;cursor:pointer;font-size:.78rem">✏️ Edit</button>
                <button onclick="__notesDelete('${subj}','${n.id}')" style="flex:1;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:6px 0;cursor:pointer;font-size:.78rem">🗑️ Delete</button>
              </div>` : ''}
            </div>`).join('')}
      </div>`;
  };

  window.__notesAddSubject = function() {
    const name = prompt('Subject name:'); if(!name||!name.trim()) return;
    const data = getNotes(); if(data[name.trim()]){showToast('Already exists','error');return;}
    data[name.trim()] = []; saveNotes(data); window._notesHubSubj = name.trim(); renderNotesHub();
  };
  window.__notesDeleteSubject = function(s) {
    if(!confirm(`Delete subject "${s}"?`))return;
    const data=getNotes(); delete data[s]; saveNotes(data);
    window._notesHubSubj=Object.keys(data)[0]||''; renderNotesHub();
  };
  window.__notesDelete = function(subj, id) {
    if(!confirm('Delete this note?'))return;
    const data=getNotes(); data[subj]=(data[subj]||[]).filter(n=>n.id!==id); saveNotes(data); renderNotesHub();
  };
  window.__notesModal = function(subj, editId) {
    const data=getNotes(); const ex=editId?(data[subj]||[]).find(n=>n.id===editId):null;
    let modal=document.getElementById('__notesModal'); if(!modal){modal=document.createElement('div');modal.id='__notesModal';document.body.appendChild(modal);}
    modal.style.cssText='position:fixed;inset:0;z-index:9100;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.75);padding:16px';
    modal.innerHTML=`<div style="background:#1e1b4b;border:1px solid rgba(34,197,94,.35);border-radius:20px;padding:24px;width:100%;max-width:500px;max-height:90vh;overflow-y:auto">
      <h3 style="margin:0 0 18px;color:#e2e8f0;font-size:1rem">${editId?'✏️ Edit Note':'➕ Add Note'}</h3>
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Title *</label>
      <input id="__nm_title" class="form-input" value="${ex?ex.title:''}" placeholder="Note title" style="width:100%;box-sizing:border-box;margin-bottom:12px">
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Content *</label>
      <textarea id="__nm_content" class="form-input" rows="8" placeholder="Write your note here..." style="width:100%;box-sizing:border-box;resize:vertical;font-family:monospace;margin-bottom:12px">${ex?ex.content:''}</textarea>
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Tags <span style="color:#64748b">(comma separated)</span></label>
      <input id="__nm_tags" class="form-input" value="${ex?(ex.tags||[]).join(', '):''}" placeholder="formula, concept, revision" style="width:100%;box-sizing:border-box;margin-bottom:18px">
      <p id="__nm_err" style="color:#f87171;font-size:.8rem;margin:0 0 10px;display:none"></p>
      <div style="display:flex;gap:10px">
        <button onclick="__notesSave('${subj}','${editId||''}')" style="flex:1;background:linear-gradient(135deg,#22c55e,#06b6d4);border:none;color:#fff;border-radius:12px;padding:11px;font-weight:700;cursor:pointer">💾 Save</button>
        <button onclick="document.getElementById('__notesModal').style.display='none'" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:12px;padding:11px 16px;cursor:pointer">Cancel</button>
      </div>
    </div>`;
    modal.style.display='flex';
  };
  window.__notesSave = function(subj, editId) {
    const title=document.getElementById('__nm_title').value.trim();
    const content=document.getElementById('__nm_content').value.trim();
    const tags=document.getElementById('__nm_tags').value.split(',').map(t=>t.trim()).filter(Boolean);
    const err=document.getElementById('__nm_err');
    if(!title||!content){err.textContent='❌ Title and content required';err.style.display='block';return;}
    const data=getNotes(); if(!data[subj])data[subj]=[];
    if(editId){const idx=data[subj].findIndex(n=>n.id===editId);if(idx!==-1)data[subj][idx]={...data[subj][idx],title,content,tags};}
    else{data[subj].push({id:'n'+Date.now()+'_'+Math.random().toString(36).slice(2),title,content,tags});}
    saveNotes(data); document.getElementById('__notesModal').style.display='none'; renderNotesHub();
    showToast(editId?'✅ Note updated!':'✅ Note added!','success');
  };
})();

// ══════════════════════════════════════════════════════════════════════
//  FORMULA HUB — new page, admin add/edit/delete
// ══════════════════════════════════════════════════════════════════════
(function buildFormulaHub() {
  function ensurePage() {
    if (document.getElementById('formulahub')) return;
    const pg = document.createElement('div'); pg.id = 'formulahub'; pg.className = 'page';
    const shell = document.getElementById('appShell') || document.querySelector('.content') || document.body;
    shell.appendChild(pg);
  }

  function getFormulas() {
    try { const s=localStorage.getItem('sh_formula_hub'); if(s) return JSON.parse(s); } catch(e) {}
    return {
      Mathematics: [
        { id:'f1', title:'Quadratic Formula', formula:'x = (−b ± √(b²−4ac)) / 2a', description:'Solves ax² + bx + c = 0', category:'Algebra' },
        { id:'f2', title:'Area of Circle', formula:'A = πr²', description:'r = radius', category:'Geometry' },
        { id:'f3', title:'Pythagoras Theorem', formula:'a² + b² = c²', description:'c = hypotenuse', category:'Geometry' },
        { id:'f4', title:'Arithmetic Progression — nth term', formula:'aₙ = a + (n−1)d', description:'a=first term, d=common difference', category:'Sequences' },
      ],
      Science: [
        { id:'f5', title:'Ohm\'s Law', formula:'V = I × R', description:'V=Voltage, I=Current, R=Resistance', category:'Electricity' },
        { id:'f6', title:'Speed Formula', formula:'Speed = Distance / Time', description:'Units: m/s or km/h', category:'Motion' },
        { id:'f7', title:'Lens Formula', formula:'1/f = 1/v − 1/u', description:'f=focal length, v=image distance, u=object distance', category:'Light' },
      ],
      Chemistry: [
        { id:'f8', title:'Mole Concept', formula:'n = m / M', description:'n=moles, m=mass(g), M=molar mass', category:'Atoms' },
      ],
    };
  }
  function saveFormulas(data) { localStorage.setItem('sh_formula_hub', JSON.stringify(data)); }

  const catColors = { Algebra:'#7c3aed', Geometry:'#06b6d4', Sequences:'#f59e0b', Electricity:'#22c55e', Motion:'#ec4899', Light:'#f97316', Atoms:'#8b5cf6', default:'#6366f1' };

  window.renderFormulaHub = function() {
    ensurePage();
    const page = document.getElementById('formulahub');
    if (!page) return;
    const data = getFormulas();
    const subjects = Object.keys(data);
    const admin = typeof isAdmin === 'function' && isAdmin();
    const subj = window._formulaHubSubj || subjects[0] || 'Mathematics';
    window._formulaHubSubj = subj;
    const formulas = data[subj] || [];
    const cats = [...new Set(formulas.map(f=>f.category||'General'))];

    page.innerHTML = `
      <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#8b5cf6">🔢 FORMULA HUB</div>
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin:0">Formula <span style="background:linear-gradient(135deg,#8b5cf6,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Sheet</span></h1>
        ${admin ? `<div style="display:flex;gap:8px">
          <button onclick="__formulaAddSubject()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#e2e8f0;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem">+ Subject</button>
          <button onclick="__formulaModal('${subj}',null)" style="background:linear-gradient(135deg,#7c3aed,#ec4899);border:none;color:#fff;border-radius:10px;padding:7px 14px;cursor:pointer;font-size:.82rem;font-weight:700">+ Add Formula</button>
        </div>` : ''}
      </div>
      <p style="color:#64748b;font-size:.9rem;margin-bottom:20px">All key formulas and equations in one place.</p>

      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:22px">
        ${subjects.map(s => `
          <div style="display:inline-flex;align-items:center;gap:4px">
            <button onclick="window._formulaHubSubj='${s}';renderFormulaHub()" style="padding:7px 16px;border-radius:99px;border:none;cursor:pointer;font-size:.82rem;font-weight:600;background:${s===subj?'linear-gradient(135deg,#7c3aed,#ec4899)':'rgba(255,255,255,.07)'};color:${s===subj?'#fff':'#94a3b8'}">${s}</button>
            ${admin && subjects.length > 1 ? `<button onclick="__formulaDeleteSubject('${s}')" style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171;border-radius:6px;padding:2px 6px;cursor:pointer;font-size:.72rem">✕</button>` : ''}
          </div>`).join('')}
      </div>

      ${cats.length === 0 ? `<div style="text-align:center;color:#64748b;padding:40px">${admin ? 'No formulas yet. Click "+ Add Formula".' : 'No formulas available.'}</div>` :
        cats.map(cat => {
          const catFormulas = formulas.filter(f => (f.category||'General') === cat);
          const col = catColors[cat] || catColors.default;
          return `
            <div style="margin-bottom:24px">
              <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:${col};margin-bottom:12px;display:flex;align-items:center;gap:8px">
                <span style="display:inline-block;width:16px;height:2px;background:${col};border-radius:2px"></span>${cat}
              </div>
              <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px">
                ${catFormulas.map(f => `
                  <div style="background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:18px;transition:.2s" onmouseenter="this.style.borderColor='${col}55'" onmouseleave="this.style.borderColor='var(--border)'">
                    <div style="font-weight:600;font-size:.88rem;color:#e2e8f0;margin-bottom:10px">${f.title}</div>
                    <div style="background:linear-gradient(135deg,rgba(${col==='#7c3aed'?'124,58,237':col==='#06b6d4'?'6,182,212':col==='#22c55e'?'34,197,94':'139,92,246'},.15),transparent);border:1px solid ${col}33;border-radius:10px;padding:12px 16px;margin-bottom:10px;text-align:center">
                      <code style="font-size:1rem;font-weight:700;color:${col};letter-spacing:.02em;font-family:'Consolas','Courier New',monospace">${f.formula}</code>
                    </div>
                    <div style="font-size:.78rem;color:#64748b">${f.description||''}</div>
                    ${admin ? `<div style="display:flex;gap:6px;margin-top:12px">
                      <button onclick="__formulaModal('${subj}','${f.id}')" style="flex:1;background:rgba(124,58,237,.15);border:1px solid rgba(124,58,237,.3);color:#c4b5fd;border-radius:8px;padding:5px 0;cursor:pointer;font-size:.78rem">✏️ Edit</button>
                      <button onclick="__formulaDelete('${subj}','${f.id}')" style="flex:1;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:5px 0;cursor:pointer;font-size:.78rem">🗑️ Delete</button>
                    </div>` : ''}
                  </div>`).join('')}
              </div>
            </div>`;
        }).join('')}`;
  };

  window.__formulaAddSubject = function() {
    const name=prompt('Subject name:');if(!name||!name.trim())return;
    const data=getFormulas();if(data[name.trim()]){showToast('Already exists','error');return;}
    data[name.trim()]=[]; saveFormulas(data); window._formulaHubSubj=name.trim(); renderFormulaHub();
  };
  window.__formulaDeleteSubject = function(s) {
    if(!confirm(`Delete subject "${s}"?`))return;
    const data=getFormulas();delete data[s];saveFormulas(data);
    window._formulaHubSubj=Object.keys(data)[0]||'';renderFormulaHub();
  };
  window.__formulaDelete = function(subj,id) {
    if(!confirm('Delete this formula?'))return;
    const data=getFormulas();data[subj]=(data[subj]||[]).filter(f=>f.id!==id);saveFormulas(data);renderFormulaHub();
  };
  window.__formulaModal = function(subj,editId) {
    const data=getFormulas(); const ex=editId?(data[subj]||[]).find(f=>f.id===editId):null;
    let modal=document.getElementById('__formulaModal');if(!modal){modal=document.createElement('div');modal.id='__formulaModal';document.body.appendChild(modal);}
    modal.style.cssText='position:fixed;inset:0;z-index:9100;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.75);padding:16px';
    modal.innerHTML=`<div style="background:#1e1b4b;border:1px solid rgba(139,92,246,.35);border-radius:20px;padding:24px;width:100%;max-width:460px;max-height:90vh;overflow-y:auto">
      <h3 style="margin:0 0 18px;color:#e2e8f0;font-size:1rem">${editId?'✏️ Edit Formula':'➕ Add Formula'}</h3>
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Title *</label>
      <input id="__fm_title" class="form-input" value="${ex?ex.title:''}" placeholder="e.g. Quadratic Formula" style="width:100%;box-sizing:border-box;margin-bottom:12px">
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Formula * <span style="color:#64748b">(use plain text or Unicode math)</span></label>
      <input id="__fm_formula" class="form-input" value="${ex?ex.formula:''}" placeholder="e.g. x = (−b ± √(b²−4ac)) / 2a" style="width:100%;box-sizing:border-box;margin-bottom:12px;font-family:monospace">
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Description</label>
      <input id="__fm_desc" class="form-input" value="${ex?(ex.description||''):''}" placeholder="What does it solve?" style="width:100%;box-sizing:border-box;margin-bottom:12px">
      <label style="font-size:.8rem;color:#94a3b8;display:block;margin-bottom:4px">Category</label>
      <input id="__fm_cat" class="form-input" value="${ex?(ex.category||''):''}" placeholder="e.g. Algebra, Geometry…" style="width:100%;box-sizing:border-box;margin-bottom:18px">
      <p id="__fm_err" style="color:#f87171;font-size:.8rem;margin:0 0 10px;display:none"></p>
      <div style="display:flex;gap:10px">
        <button onclick="__formulaSave('${subj}','${editId||''}')" style="flex:1;background:linear-gradient(135deg,#7c3aed,#ec4899);border:none;color:#fff;border-radius:12px;padding:11px;font-weight:700;cursor:pointer">💾 Save</button>
        <button onclick="document.getElementById('__formulaModal').style.display='none'" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:12px;padding:11px 16px;cursor:pointer">Cancel</button>
      </div>
    </div>`;
    modal.style.display='flex';
  };
  window.__formulaSave = function(subj,editId) {
    const title=document.getElementById('__fm_title').value.trim();
    const formula=document.getElementById('__fm_formula').value.trim();
    const desc=document.getElementById('__fm_desc').value.trim();
    const cat=document.getElementById('__fm_cat').value.trim()||'General';
    const err=document.getElementById('__fm_err');
    if(!title||!formula){err.textContent='❌ Title and formula required';err.style.display='block';return;}
    const data=getFormulas();if(!data[subj])data[subj]=[];
    if(editId){const idx=data[subj].findIndex(f=>f.id===editId);if(idx!==-1)data[subj][idx]={...data[subj][idx],title,formula,description:desc,category:cat};}
    else{data[subj].push({id:'f'+Date.now()+'_'+Math.random().toString(36).slice(2),title,formula,description:desc,category:cat});}
    saveFormulas(data);document.getElementById('__formulaModal').style.display='none';renderFormulaHub();
    showToast(editId?'✅ Formula updated!':'✅ Formula added!','success');
  };
})();

// ══════════════════════════════════════════════════════════════════════
//  NAV INJECTION — add Notes Hub, Formula Hub to sidebar
// ══════════════════════════════════════════════════════════════════════
(function injectNavItems() {
  function inject() {
    const navList = document.querySelector('.nav-list');
    if (!navList || document.getElementById('__nav_noteshub')) return;

    const lectureBtn = navList.querySelector('[data-nav="lectures"]') ||
      Array.from(navList.querySelectorAll('button')).find(b => b.textContent.includes('Lecture'));

    function makeBtn(id, dataNav, icon, label, action) {
      const btn = document.createElement('button');
      btn.id = id;
      btn.className = 'nav-item';
      btn.setAttribute('data-nav', dataNav);
      btn.innerHTML = `${icon} ${label}`;
      btn.onclick = action;
      return btn;
    }

    const notesBtn = makeBtn('__nav_noteshub', 'noteshub', '📒', 'Notes Hub', () => { showPage('noteshub'); renderNotesHub(); });
    const formulaBtn = makeBtn('__nav_formulahub', 'formulahub', '🔢', 'Formula Hub', () => { showPage('formulahub'); renderFormulaHub(); });

    if (lectureBtn) {
      lectureBtn.after(formulaBtn);
      lectureBtn.after(notesBtn);
    } else {
      navList.appendChild(notesBtn);
      navList.appendChild(formulaBtn);
    }

    // Ensure pages exist in DOM
    ['noteshub','formulahub'].forEach(id => {
      if (!document.getElementById(id)) {
        const pg = document.createElement('div');
        pg.id = id; pg.className = 'page';
        const content = document.querySelector('.content');
        if (content) content.appendChild(pg);
      }
    });
  }

  const origEnter = window.enterApp;
  if (typeof origEnter === 'function') {
    window.enterApp = function() {
      origEnter.apply(this, arguments);
      setTimeout(inject, 150);
      // Hide Materials nav for students
      setTimeout(() => {
        const uploadTab = document.getElementById('uploadTab');
        if (uploadTab && typeof isAdmin === 'function' && !isAdmin()) {
          uploadTab.style.display = 'none';
        }
      }, 200);
    };
  }
})();

// ══════════════════════════════════════════════════════════════════════
//  SCROLL + MOBILE CSS
// ══════════════════════════════════════════════════════════════════════
(function injectCSS() {
  const s = document.createElement('style');
  s.textContent = `
    .content { overflow-y:auto!important; -webkit-overflow-scrolling:touch; overscroll-behavior:contain; }
    .page { overflow-x:hidden; }
    .page.active { display:block; min-height:0; }
    @media(max-width:768px){
      .content { padding-bottom:110px!important; }
      .stat-cards { grid-template-columns:1fr 1fr!important; gap:10px!important; }
      .file-item { flex-wrap:wrap; gap:8px; padding:12px 10px!important; }
      .file-item .file-info { min-width:0; flex:1 1 60%; }
      .file-item .file-actions { flex:0 0 auto; display:flex; gap:6px; }
      .modal { width:96vw!important; max-width:96vw!important; border-radius:16px!important; padding:18px!important; }
      .modal-inner { width:96vw!important; max-width:96vw!important; }
      .adm-table-wrap, table { overflow-x:auto; display:block; }
      table { min-width:480px; }
      .hero { padding:18px 14px!important; }
      .q-editor-grid { grid-template-columns:1fr!important; }
      .adm-two { grid-template-columns:1fr!important; }
      .topbar { padding:8px 12px!important; gap:8px!important; }
      .rooms-layout { grid-template-columns:1fr!important; }
      .rooms-sidebar { max-height:220px!important; }
      .auth-box { padding:20px 14px!important; margin:8px!important; }
      .viewer-wrap { width:98vw!important; border-radius:14px!important; }
      .viewer-body { min-height:200px!important; max-height:65vh!important; }
      .bottom-nav-btn { padding:8px 6px!important; min-width:44px!important; }
      .bottom-nav-btn .bn-icon { font-size:1.4rem!important; }
    }
    @media(max-width:400px){
      .stat-cards { grid-template-columns:1fr!important; }
      h1,.page h1 { font-size:1.25rem!important; }
      .content { padding:10px 10px 110px!important; }
    }
    .content::-webkit-scrollbar{width:4px}
    .content::-webkit-scrollbar-thumb{background:rgba(124,58,237,.4);border-radius:4px}
    .modal::-webkit-scrollbar{width:4px}
    .modal::-webkit-scrollbar-thumb{background:rgba(124,58,237,.3);border-radius:4px}
  `;
  document.head.appendChild(s);
})();

// ══════════════════════════════════════════════════════════════════════
//  BOOT — must be last
// ══════════════════════════════════════════════════════════════════════
bootApp();
