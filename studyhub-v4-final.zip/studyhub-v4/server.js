// ═══════════════════════════════════════════════════════════════════
//  StudyHub — Gemini API Proxy Server
//  Run: node server.js
//  The API key lives here only — never sent to the browser.
// ═══════════════════════════════════════════════════════════════════

const http   = require('http');
const https  = require('https');
const fs     = require('fs');
const path   = require('path');

// ── Config ────────────────────────────────────────────────────────
const PORT         = process.env.PORT || 3000;
const GEMINI_KEY   = process.env.GEMINI_API_KEY;
if (!GEMINI_KEY) {
  console.error('\n❌  GEMINI_API_KEY not set.\n    Copy .env.example → .env and add your key, then: node server.js\n');
  process.exit(1);
}
const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_UPSTREAM = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_KEY}`;

// ── MIME types for static files ───────────────────────────────────
const MIME = {
  '.html': 'text/html',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.png':  'image/png',
  '.json': 'application/json',
  '.ico':  'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

// ── Read body helper ──────────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

// ── Proxy a request to Gemini ─────────────────────────────────────
function proxyGemini(reqBody, res) {
  const options = {
    hostname: 'generativelanguage.googleapis.com',
    path:     `/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_KEY}`,
    method:   'POST',
    headers:  { 'Content-Type': 'application/json' },
  };

  const proxyReq = https.request(options, proxyRes => {
    res.writeHead(proxyRes.statusCode, {
      'Content-Type':                'application/json',
      'Access-Control-Allow-Origin': '*',
    });
    proxyRes.pipe(res);
  });

  proxyReq.on('error', err => {
    res.writeHead(502, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: { message: 'Proxy error: ' + err.message } }));
  });

  proxyReq.write(reqBody);
  proxyReq.end();
}

// ── HTTP Server ───────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  // ── /api/gemini — secure proxy ──────────────────────────────────
  if (req.url === '/api/gemini' && req.method === 'POST') {
    const body = await readBody(req).catch(() => '{}');
    return proxyGemini(body, res);
  }

  // ── Static file server ──────────────────────────────────────────
  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);

  // Prevent directory traversal
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403); return res.end('Forbidden');
  }

  // Default to index.html for SPA routes
  if (!path.extname(filePath)) filePath = path.join(__dirname, 'index.html');

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(500); return res.end('Server error');
    }
    const ext  = path.extname(filePath);
    const mime = MIME[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`\n✅ StudyHub running at http://localhost:${PORT}`);
  console.log(`🔐 Gemini API key is server-side only — never exposed to browser`);
  console.log(`📡 Proxy: POST /api/gemini → Gemini ${GEMINI_MODEL}\n`);
});
