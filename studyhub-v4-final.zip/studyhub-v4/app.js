// ── Gemini AI Config ─────────────────────────────────────────────────────────
const GEMINI_API_KEY = '';  // Key removed — routed via /api/gemini proxy
const GEMINI_MODEL   = 'gemini-2.5-flash';
const GEMINI_URL = '/api/gemini';

async function callGemini(prompt, maxTokens = 2048) {
  const res = await fetch(GEMINI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: maxTokens }
    })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err.error && err.error.message) || `HTTP ${res.status}`);
  }
  const data = await res.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

// ── Shared AI error fallback ─────────────────────────────────────────────────
const AI_UNAVAILABLE_MSG = '⚠️ AI service is temporarily unavailable. Please try again in a moment.';

// ── AI Tutor Chat ─────────────────────────────────────────────────────────────
async function askAITutor(question, subject = 'General') {
  const prompt = `You are an expert Class 10 CBSE tutor. Answer this student's question clearly and concisely.
Subject: ${subject}
Question: ${question}
Give a clear explanation with steps if needed. Keep it student-friendly and under 200 words.`;
  try { return await callGemini(prompt, 1024); } catch (err) { console.error('[askAITutor]', err); return AI_UNAVAILABLE_MSG; }
}

// ── Chapter Summarizer ────────────────────────────────────────────────────────
async function summarizeChapter(subject, chapter) {
  const prompt = `You are a Class 10 CBSE expert. Write a concise summary of the chapter "${chapter}" from ${subject}.
Include:
- Key concepts (3-5 bullet points)
- Important formulas or definitions
- Common exam topics
Keep it under 250 words. Use simple language for Class 10 students.`;
  try { return await callGemini(prompt, 1024); } catch (err) { console.error('[summarizeChapter]', err); return AI_UNAVAILABLE_MSG; }
}

// ── Doubt Solver ──────────────────────────────────────────────────────────────
async function solveDoubt(doubt) {
  const prompt = `You are a helpful Class 10 CBSE tutor. Solve this doubt step by step:
"${doubt}"
Provide:
1. Simple explanation
2. Step-by-step solution if applicable
3. Key point to remember
Keep response under 300 words. Be friendly and encouraging.`;
  try { return await callGemini(prompt, 1024); } catch (err) { console.error('[solveDoubt]', err); return AI_UNAVAILABLE_MSG; }
}

// ── AI Notes Generator ───────────────────────────────────────────────────────
async function generateAINotes(subject, chapter) {
  const prompt = `You are a Class 10 CBSE expert teacher. Generate comprehensive study notes for:
Subject: ${subject}\nChapter: ${chapter}

Provide:
## 📚 Key Concepts
(5-7 bullet points covering main ideas)

## 📝 Summary
(3-4 sentences overview)

## 🔢 Important Formulas / Definitions
(List all key formulas or definitions)

## ❓ Important Questions for Exam
(5 likely exam questions with brief answers)

## 💡 Quick Revision Tips
(3 memory tricks or tips)

Keep language simple and student-friendly for Class 10.`;
  try { return await callGemini(prompt, 2048); } catch (err) { console.error('[generateAINotes]', err); return AI_UNAVAILABLE_MSG; }
}

// ── Weakness Analyzer ────────────────────────────────────────────────────────
async function analyzeWeaknesses(weakChapters, subjectScores) {
  const subjectSummary = Object.entries(subjectScores).map(([s,p])=>`${s}: ${p}%`).join(', ');
  const weakList = weakChapters.slice(0,5).map(w=>`${w.chapter} (${w.subject})`).join(', ');
  const prompt = `You are an AI study coach for a Class 10 CBSE student.
Subject performance: ${subjectSummary}
Weakest chapters: ${weakList}

Provide a personalised study plan:
1. Which subject needs immediate attention and why
2. Top 3 chapters to revise first
3. Recommended daily study schedule (in hours)
4. One specific tip for each weak chapter
Keep response concise, friendly, and actionable.`;
  try { return await callGemini(prompt, 1024); } catch (err) { console.error('[analyzeWeaknesses]', err); return AI_UNAVAILABLE_MSG; }
}

// ── AI Study Coach ───────────────────────────────────────────────────────────
async function generateStudyPlan(daysLeft, subjects, weakChapters) {
  const weakList = (weakChapters||[]).slice(0,5).map(w=>`${w.chapter} (${w.subject})`).join(', ') || 'None identified yet';
  const prompt = `You are an expert CBSE Class 10 study coach.
Exam in: ${daysLeft} days
Subjects: ${subjects.join(', ')}
Weak areas: ${weakList}

Create a structured study plan:
## 📅 Daily Schedule (Week-wise)
## 📖 Revision Priority List
## 🧪 Mock Test Schedule
## 🔁 Last-Week Revision Plan
## ✅ Day-before-exam Tips

Be specific with days, timings, and chapters. Keep it realistic and motivating.`;
  try { return await callGemini(prompt, 2048); } catch (err) { console.error('[generateStudyPlan]', err); return AI_UNAVAILABLE_MSG; }
}

// ═══════════════════════════ CHAPTERS DATA ═══════════════════════════
const SUBJECTS_CHAPTERS = {
  'Mathematics':['Real Numbers','Polynomials','Linear Equations in Two Variables','Quadratic Equations','Arithmetic Progressions','Triangles','Coordinate Geometry','Introduction to Trigonometry','Applications of Trigonometry','Circles','Areas Related to Circles','Surface Areas and Volumes','Statistics','Probability'],
  'Science':['Chemical Reactions and Equations','Acids Bases and Salts','Metals and Non-metals','Carbon and its Compounds','Life Processes','Control and Coordination','How do Organisms Reproduce','Heredity and Evolution','Light - Reflection and Refraction','The Human Eye','Electricity','Magnetic Effects of Electric Current','Our Environment','Management of Natural Resources'],
  'English':['A Letter to God','Nelson Mandela','Two Stories About Flying','From the Diary of Anne Frank','Glimpses of India','Mijbil the Otter','Madam Rides the Bus','The Sermon at Benares','The Proposal','Dust of Snow','Fire and Ice','A Tiger in the Zoo','Grammar and Composition','Writing Skills'],
  'Social Studies':['Nationalism in Europe','Nationalism in India','The Making of a Global World','The Age of Industrialisation','Print Culture and the Modern World','Resources and Development','Forest and Wildlife Resources','Water Resources','Agriculture','Minerals and Energy Resources','Manufacturing Industries','Lifelines of National Economy','Power Sharing','Federalism','Democracy and Diversity','Gender Religion and Caste','Popular Struggles and Movements'],
  'Hindi':['Surdas ke Pad','Tulsidas ke Dohe','Dev ke Savaiyye','Jaishankar Prasad','Suryakant Tripathi Nirala','Nagarjun','Girija Kumar Mathur','Rituraaj','Mahadevi Verma','Balgobin Bhagat','Lakhnawi Andaaz','Netaji Ka Chashma','Vyakaran - Sandhi','Vyakaran - Samas'],
  'Computer Science':['Introduction to Computers','Networking Basics','Internet and Web Technologies','Database Concepts','HTML Fundamentals','Python Introduction','Problem Solving and Algorithms','Cybersecurity Basics']
};

// ═══════════════════════════ AI Q-BANK (Gemini Pro) ═══════════════════════════
const AI_QUESTION_BANK = {
  Mathematics:{
    'Real Numbers':[
      {q:'HCF of 420 and 130 is:',opts:['5','10','20','30'],ans:1,diff:'medium',expl:'By Euclid\'s division: HCF(420,130)=10.'},
      {q:'Which is irrational?',opts:['√4','√9','√7','√16'],ans:2,diff:'easy',expl:'√7 cannot be expressed as p/q.'},
      {q:'If HCF(60,b)=12 and LCM=360, b is:',opts:['72','84','60','96'],ans:0,diff:'medium',expl:'60×b=12×360 → b=72.'},
      {q:'Decimal expansion of 17/8 terminates after:',opts:['1','2','3','4'],ans:2,diff:'easy',expl:'8=2³, so 17/8=2.125 — 3 places.'},
      {q:'Product of two numbers = 9750, HCF = 25, LCM is:',opts:['300','375','390','450'],ans:2,diff:'hard',expl:'LCM=9750/25=390.'},
    ],
    'Polynomials':[
      {q:'Sum of zeros of 2x²-5x+3 is:',opts:['5/2','3/2','2/5','3/5'],ans:0,diff:'easy',expl:'Sum=-b/a=-(-5)/2=5/2.'},
      {q:'Zeros of x²-3x+2 are:',opts:['1 and 2','2 and 3','1 and 3','-1 and -2'],ans:0,diff:'medium',expl:'(x-1)(x-2)=0 → x=1 or 2.'},
      {q:'Product of zeros of ax²-6x-6=-3 gives a:',opts:['1','2','3','-1'],ans:1,diff:'hard',expl:'Product=-6/a=-3 → a=2.'},
      {q:'Degree of a cubic polynomial is:',opts:['1','2','3','4'],ans:2,diff:'easy',expl:'Cubic = degree 3.'},
    ],
    'Quadratic Equations':[
      {q:'Discriminant of 2x²-4x+3 is:',opts:['8','-8','28','-28'],ans:1,diff:'medium',expl:'D=16-24=-8.'},
      {q:'When D < 0, roots are:',opts:['Real & equal','Real & distinct','No real roots','Rational'],ans:2,diff:'easy',expl:'D<0 means no real roots.'},
      {q:'Roots of x²-5x+6=0:',opts:['2 and 3','1 and 6','-2 and -3','3 and 4'],ans:0,diff:'easy',expl:'(x-2)(x-3)=0.'},
      {q:'Sum of roots of 3x²-7x+4=0:',opts:['7/3','4/3','3/7','7/4'],ans:0,diff:'medium',expl:'Sum=-b/a=7/3.'},
    ],
    'Arithmetic Progressions':[
      {q:'nth term of AP 3,7,11,... is:',opts:['4n-1','4n+1','4n','3n'],ans:0,diff:'easy',expl:'a=3,d=4. aₙ=4n-1.'},
      {q:'Sum of first 20 terms of 1,3,5,...:',opts:['400','360','380','420'],ans:0,diff:'medium',expl:'S₂₀=20/2[2+38]=400.'},
      {q:'Common difference when a₃=7 and a₇=15:',opts:['2','3','4','1'],ans:0,diff:'medium',expl:'4d=8 → d=2.'},
      {q:'If Sₙ=3n²+5n, first term is:',opts:['8','11','5','6'],ans:0,diff:'hard',expl:'a₁=S₁=3+5=8.'},
    ],
    'Triangles':[
      {q:'In ΔABC, DE∥BC. AD=3, DB=6, AE=2, EC=?',opts:['2','4','6','3'],ans:1,diff:'medium',expl:'BPT: 3/6=2/EC → EC=4.'},
      {q:'ΔABC~ΔPQR with AB/PQ=3/5. Area ratio:',opts:['9:25','3:5','25:9','6:10'],ans:0,diff:'medium',expl:'Area ratio=(side ratio)²=9:25.'},
      {q:'Right triangle legs 5,12; hypotenuse:',opts:['13','15','17','14'],ans:0,diff:'easy',expl:'√(25+144)=13.'},
      {q:'All equilateral triangles are:',opts:['Congruent','Similar','Neither','Isosceles only'],ans:1,diff:'easy',expl:'All have 60° angles → similar.'},
    ],
    'Coordinate Geometry':[
      {q:'Distance between (3,4) and (7,1):',opts:['5','4','3√2','3'],ans:0,diff:'easy',expl:'√(16+9)=5.'},
      {q:'Midpoint of (2,6) and (8,2):',opts:['(5,4)','(6,4)','(5,3)','(4,5)'],ans:0,diff:'easy',expl:'((2+8)/2,(6+2)/2)=(5,4).'},
      {q:'Area of triangle with vertices (0,0),(3,0),(0,4):',opts:['6','12','8','10'],ans:0,diff:'easy',expl:'½×3×4=6.'},
      {q:'If (1,2),(4,y),(7,8) are collinear, y=?',opts:['5','6','4','3'],ans:0,diff:'hard',expl:'Collinearity formula gives y=5.'},
    ],
    'Introduction to Trigonometry':[
      {q:'sin30°×cos60°+sin60°×cos30°=',opts:['1','0','√3/2','1/2'],ans:0,diff:'medium',expl:'sin(30+60)=sin90°=1.'},
      {q:'If tanθ=5/12, sinθ=',opts:['5/13','12/13','5/12','13/5'],ans:0,diff:'medium',expl:'Hyp=13, sinθ=5/13.'},
      {q:'1+tan²θ equals:',opts:['sec²θ','cot²θ','cosec²θ','1'],ans:0,diff:'medium',expl:'Pythagorean identity.'},
      {q:'Value of sin²45°+cos²45°:',opts:['1','0','√2','2'],ans:0,diff:'easy',expl:'sin²θ+cos²θ=1.'},
    ],
    'Circles':[
      {q:'Tangent to circle makes __ with radius:',opts:['90°','60°','45°','180°'],ans:0,diff:'easy',expl:'Tangent is perpendicular to radius.'},
      {q:'Two tangents from external point are equal because:',opts:['Equal radii','Congruent triangles','Angle rule','Pythagoras'],ans:1,diff:'medium',expl:'△OAP≅△OBP (RHS) → PA=PB.'},
      {q:'Tangents from inside a circle:',opts:['0','1','2','Infinite'],ans:0,diff:'easy',expl:'No tangent from a point inside.'},
    ],
    'Statistics':[
      {q:'Mode of 3,5,7,5,3,5,2:',opts:['3','5','7','2'],ans:1,diff:'easy',expl:'5 appears most (3 times).'},
      {q:'Mean of 5,10,15,20,25:',opts:['10','15','20','25'],ans:1,diff:'easy',expl:'75/5=15.'},
      {q:'Mode=3Median-2Mean is called:',opts:['Empirical formula','Mode formula','Ogive','Quartile'],ans:0,diff:'medium',expl:'It is the empirical relationship.'},
      {q:'Cumulative frequency graph is:',opts:['Histogram','Ogive','Bar graph','Pie chart'],ans:1,diff:'easy',expl:'Ogive = cumulative frequency curve.'},
    ],
    'Probability':[
      {q:'P(Heads on fair coin):',opts:['1','0','1/2','1/4'],ans:2,diff:'easy',expl:'P(H)=1/2.'},
      {q:'P(number>4 on dice):',opts:['1/3','1/2','1/6','2/3'],ans:0,diff:'easy',expl:'{5,6}=2 outcomes. P=1/3.'},
      {q:'P(sum=8 on two dice):',opts:['5/36','6/36','7/36','4/36'],ans:0,diff:'medium',expl:'5 favorable outcomes.'},
      {q:'P(King from 52 cards):',opts:['1/52','1/26','1/13','2/13'],ans:2,diff:'easy',expl:'4 kings/52=1/13.'},
    ],
    'Surface Areas and Volumes':[
      {q:'Volume of sphere with r=7cm (π=22/7):',opts:['1437.3 cm³','1437 cm³','1000 cm³','1200 cm³'],ans:0,diff:'medium',expl:'V=4/3πr³=4/3×22/7×343≈1437.3cm³.'},
      {q:'Total surface area of cylinder with r=3, h=7:',opts:['188.4','150','200','160'],ans:0,diff:'medium',expl:'TSA=2πr(r+h)=2×22/7×3×10≈188.4.'},
    ],
    'Areas Related to Circles':[
      {q:'Area of circle with r=7cm (π=22/7):',opts:['154 cm²','144 cm²','164 cm²','174 cm²'],ans:0,diff:'easy',expl:'A=πr²=22/7×49=154cm².'},
      {q:'Area of semicircle with r=14 (π=22/7):',opts:['308','154','616','462'],ans:0,diff:'medium',expl:'½πr²=½×22/7×196=308cm².'},
    ],
  },
  Science:{
    'Chemical Reactions and Equations':[
      {q:'CaCO₃→CaO+CO₂ is a:',opts:['Combination','Decomposition','Displacement','Double displacement'],ans:1,diff:'easy',expl:'One compound breaks → decomposition.'},
      {q:'Fe₂O₃+2Al→Al₂O₃+2Fe is:',opts:['Combination','Displacement','Double displacement','Decomposition'],ans:1,diff:'medium',expl:'Al displaces Fe — displacement.'},
      {q:'Which is exothermic?',opts:['Electrolysis of water','Photosynthesis','Burning of gas','Decomposition of CaCO₃'],ans:2,diff:'medium',expl:'Burning releases heat — exothermic.'},
      {q:'AgNO₃+NaCl→AgCl+NaNO₃ white precipitate is:',opts:['NaNO₃','AgCl','AgNO₃','NaCl'],ans:1,diff:'medium',expl:'AgCl is insoluble — white precipitate.'},
    ],
    'Acids Bases and Salts':[
      {q:'Baking soda is:',opts:['NaOH','NaCl','NaHCO₃','Na₂CO₃'],ans:2,diff:'easy',expl:'Baking soda=NaHCO₃.'},
      {q:'Acid turns blue litmus:',opts:['Red','Green','Yellow','No change'],ans:0,diff:'easy',expl:'Acids turn blue litmus red.'},
      {q:'Plaster of Paris is:',opts:['CaSO₄·2H₂O','CaSO₄·½H₂O','Ca(OH)₂','CaCO₃'],ans:1,diff:'medium',expl:'PoP=CaSO₄·½H₂O.'},
      {q:'pH of a neutral solution:',opts:['0','7','14','1'],ans:1,diff:'easy',expl:'pH 7 = neutral.'},
    ],
    'Metals and Non-metals':[
      {q:'Metals can be drawn into wires — this property is:',opts:['Malleability','Ductility','Conductivity','Lustre'],ans:1,diff:'easy',expl:'Ductility = wire-drawing ability.'},
      {q:'Most reactive metal in reactivity series:',opts:['Gold','Silver','Potassium','Iron'],ans:2,diff:'easy',expl:'Potassium is most reactive.'},
      {q:'Non-metal that conducts electricity:',opts:['Sulphur','Phosphorus','Graphite','Iodine'],ans:2,diff:'medium',expl:'Graphite has delocalized electrons.'},
      {q:'Ionic compounds have __ melting points:',opts:['Low','High','Variable','Same as metals'],ans:1,diff:'medium',expl:'Strong electrostatic forces → high MP.'},
    ],
    'Life Processes':[
      {q:'Photosynthesis occurs in:',opts:['Mitochondria','Ribosome','Chloroplast','Nucleus'],ans:2,diff:'easy',expl:'Chloroplasts contain chlorophyll.'},
      {q:'In aerobic respiration glucose is oxidized to:',opts:['CO₂ and H₂O','Lactic acid','Ethanol','Pyruvate'],ans:0,diff:'medium',expl:'C₆H₁₂O₆+6O₂→6CO₂+6H₂O+energy.'},
      {q:'Powerhouse of the cell:',opts:['Nucleus','Ribosome','Mitochondria','Chloroplast'],ans:2,diff:'easy',expl:'Mitochondria produce ATP.'},
      {q:'Stomata are mainly for:',opts:['Water absorption','Gas exchange','Food storage','Support'],ans:1,diff:'easy',expl:'Stomata allow CO₂ in and O₂ out.'},
    ],
    'Electricity':[
      {q:'SI unit of charge:',opts:['Ampere','Volt','Coulomb','Ohm'],ans:2,diff:'easy',expl:'Coulomb (C) is the unit of charge.'},
      {q:'Ohm\'s law: V=',opts:['I/R','IR','I²R','I/R²'],ans:1,diff:'easy',expl:'V=IR.'},
      {q:'Heat produced H=I²Rt is:',opts:['Joule\'s law','Ohm\'s law','Faraday\'s law','Newton\'s law'],ans:0,diff:'medium',expl:'Joule\'s heating law: H=I²Rt.'},
      {q:'Power P=220V, I=5A:',opts:['1100 W','44 W','225 W','215 W'],ans:0,diff:'medium',expl:'P=VI=1100W.'},
    ],
    'Light - Reflection and Refraction':[
      {q:'Angle of incidence = angle of reflection is:',opts:['Snell\'s law','Law of reflection','Mirror formula','Refraction law'],ans:1,diff:'easy',expl:'First law of reflection.'},
      {q:'Focal length of concave mirror is:',opts:['Negative','Positive','Zero','Infinite'],ans:0,diff:'medium',expl:'By sign convention, f is negative.'},
      {q:'Refractive index of glass=1.5; speed of light in glass (c=3×10⁸):',opts:['2×10⁸','1.5×10⁸','3×10⁸','4.5×10⁸'],ans:0,diff:'medium',expl:'v=c/n=2×10⁸ m/s.'},
    ],
    'Our Environment':[
      {q:'Ozone layer is in:',opts:['Troposphere','Stratosphere','Mesosphere','Thermosphere'],ans:1,diff:'easy',expl:'Stratosphere, 15-35km above Earth.'},
      {q:'CFC causes:',opts:['Acid rain','Ozone depletion','Global warming only','Soil erosion'],ans:1,diff:'easy',expl:'CFCs break down ozone molecules.'},
      {q:'10% energy rule means:',opts:['10% stored,90% lost','90% stored,10% lost','Equal transfer','50/50 split'],ans:0,diff:'medium',expl:'Only 10% energy passed to next trophic level.'},
    ],
    'Control and Coordination':[
      {q:'Fight-or-flight hormone secreted by:',opts:['Thyroid','Pancreas','Adrenal gland','Pituitary'],ans:2,diff:'medium',expl:'Adrenaline from adrenal medulla.'},
      {q:'Largest part of human brain:',opts:['Cerebellum','Medulla','Cerebrum','Pons'],ans:2,diff:'easy',expl:'Cerebrum controls thought and voluntary actions.'},
    ],
    'Heredity and Evolution':[
      {q:'Father of Genetics:',opts:['Darwin','Mendel','Lamarck','Watson'],ans:1,diff:'easy',expl:'Gregor Mendel is the father of genetics.'},
      {q:'DNA stands for:',opts:['Deoxyribonucleic acid','Deoxyribose acid','Diribonucleic acid','Dinitrogen acid'],ans:0,diff:'easy',expl:'DNA=Deoxyribonucleic acid.'},
    ],
    'How do Organisms Reproduce':[
      {q:'Binary fission occurs in:',opts:['Amoeba','Yeast','Hydra','Fungi'],ans:0,diff:'easy',expl:'Amoeba reproduces by binary fission.'},
      {q:'Budding occurs in:',opts:['Amoeba','Yeast','Hydra','Both B and C'],ans:3,diff:'medium',expl:'Both yeast and hydra reproduce by budding.'},
    ],
    'The Human Eye':[
      {q:'Which part controls light entry into eye?',opts:['Retina','Iris','Cornea','Lens'],ans:1,diff:'easy',expl:'Iris controls pupil size.'},
      {q:'Defect corrected by concave lens:',opts:['Hypermetropia','Myopia','Presbyopia','Astigmatism'],ans:1,diff:'medium',expl:'Myopia (short-sight) corrected by concave lens.'},
    ],
    'Magnetic Effects of Electric Current':[
      {q:'A compass needle is deflected near a current-carrying wire — this shows:',opts:['Static electricity','Magnetic effect of current','Chemical effect','Thermal effect'],ans:1,diff:'easy',expl:'Oersted\'s experiment showed magnetic effect.'},
      {q:'Device that converts electrical energy to mechanical energy:',opts:['Generator','Motor','Transformer','Capacitor'],ans:1,diff:'easy',expl:'Electric motor converts electrical → mechanical energy.'},
    ],
    'Acids Bases and Salts':[],
    'Carbon and its Compounds':[
      {q:'Carbon forms 4 covalent bonds because it has __ valence electrons:',opts:['2','3','4','6'],ans:2,diff:'easy',expl:'Carbon has 4 valence electrons in its outer shell.'},
      {q:'Hydrocarbon with only single bonds is called:',opts:['Alkene','Alkyne','Alkane','Arene'],ans:2,diff:'easy',expl:'Alkanes have only C-C single bonds (saturated).'},
    ],
    'Management of Natural Resources':[
      {q:'3 R\'s of waste management:',opts:['Reduce Reuse Recycle','Remove Renew Replace','Reject Reduce Reuse','Reduce Replace Recover'],ans:0,diff:'easy',expl:'Reduce, Reuse, Recycle.'},
      {q:'Chipko movement aimed to:',opts:['Save water','Protect forests','Clean air','Save tigers'],ans:1,diff:'easy',expl:'Chipko (1970s) protested against deforestation.'},
    ],
  },
  'Social Studies':{
    'Nationalism in Europe':[
      {q:'Who painted allegorical "Germania"?',opts:['Philip Veit','Delacroix','Sorrieu','Lorenz Clasen'],ans:0,diff:'medium',expl:'Philip Veit painted Germania.'},
      {q:'Frankfurt Parliament (1848) met at:',opts:['Prussia','Berlin','St. Paul\'s Church','Vienna'],ans:2,diff:'medium',expl:'St. Paul\'s Church, Frankfurt.'},
      {q:'Bismarck\'s unification policy was:',opts:['Blood and Iron','Fire and Steel','Sword and Crown','Force and Unity'],ans:0,diff:'easy',expl:'Bismarck\'s "Blood and Iron" policy.'},
      {q:'Zollverein (1834) was a:',opts:['Military alliance','Customs union','Political party','Railway network'],ans:1,diff:'medium',expl:'Customs union boosting German economic unity.'},
    ],
    'Nationalism in India':[
      {q:'Non-Cooperation Movement launched in:',opts:['1919','1920','1921','1922'],ans:1,diff:'easy',expl:'Gandhi launched NCM in 1920.'},
      {q:'Jallianwala Bagh massacre:',opts:['April 6 1919','April 13 1919','March 30 1919','May 1 1919'],ans:1,diff:'easy',expl:'April 13, 1919.'},
      {q:'Civil Disobedience Movement started with:',opts:['Quit India','Dandi March','Simon Commission','Khilafat'],ans:1,diff:'easy',expl:'Dandi March, 1930.'},
      {q:'Khilafat Movement organized by:',opts:['Gandhi','Nehru','Muhammad Ali and Shaukat Ali','Maulana Azad'],ans:2,diff:'medium',expl:'Brothers Muhammad Ali and Shaukat Ali.'},
    ],
    'The Making of a Global World':[
      {q:'Great Depression began in:',opts:['1929','1930','1932','1928'],ans:0,diff:'easy',expl:'US stock market crash, 1929.'},
      {q:'Bretton Woods (1944) established:',opts:['UN','World Bank and IMF','NATO','GATT'],ans:1,diff:'medium',expl:'World Bank (IBRD) and IMF.'},
      {q:'Silk Routes connected:',opts:['Europe and Africa','Asia and Americas','China and Rome','India and Japan'],ans:2,diff:'medium',expl:'China, Central Asia, and Rome.'},
    ],
    'The Age of Industrialisation':[
      {q:'First country to industrialize:',opts:['France','USA','Britain','Germany'],ans:2,diff:'easy',expl:'Britain industrialized first (18th century).'},
      {q:'Spinning Jenny invented by:',opts:['James Watt','James Hargreaves','Arkwright','Cartwright'],ans:1,diff:'medium',expl:'Hargreaves, 1764.'},
      {q:'Proto-industrialization refers to:',opts:['Factory production','Rural cottage industries','Steam machines','Trade in raw materials'],ans:1,diff:'medium',expl:'Rural cottage industry pre-dating factories.'},
    ],
    'Print Culture and the Modern World':[
      {q:'Gutenberg developed printing press around:',opts:['1448','1449','1450','1455'],ans:2,diff:'easy',expl:'~1450, Gutenberg\'s movable type press.'},
      {q:'First book printed by Gutenberg:',opts:['Bible','Quran','Gita','Torah'],ans:0,diff:'easy',expl:'The 42-line Bible.'},
      {q:'"Print capitalism" coined by:',opts:['Karl Marx','Benedict Anderson','Max Weber','Gramsci'],ans:1,diff:'medium',expl:'Benedict Anderson, "Imagined Communities."'},
    ],
    'Resources and Development':[
      {q:'Black soil is also called:',opts:['Alluvial','Laterite','Regur','Red'],ans:2,diff:'medium',expl:'Regur soil — rich in lime and iron.'},
      {q:'Agenda 21 adopted at:',opts:['Rio Earth Summit 1992','Kyoto 1997','Copenhagen 2009','Paris 2015'],ans:0,diff:'medium',expl:'Rio Earth Summit, 1992.'},
      {q:'Best soil for cotton:',opts:['Alluvial','Black/Regur','Red','Laterite'],ans:1,diff:'easy',expl:'Black soil retains moisture, ideal for cotton.'},
    ],
    'Forest and Wildlife Resources':[
      {q:'Project Tiger launched in:',opts:['1972','1973','1974','1975'],ans:1,diff:'easy',expl:'1973.'},
      {q:'Chipko Movement aimed at:',opts:['Save water','Protect forests','Clean air','Save tigers'],ans:1,diff:'easy',expl:'Prevent deforestation, 1970s, Uttarakhand.'},
      {q:'Dachigam National Park known for:',opts:['Tigers','Hangul deer','Elephants','Rhinos'],ans:1,diff:'medium',expl:'Hangul (Kashmir stag) last refuge.'},
    ],
    'Water Resources':[
      {q:'Sardar Sarovar Dam on river:',opts:['Ganga','Narmada','Godavari','Krishna'],ans:1,diff:'easy',expl:'Narmada River.'},
      {q:'Rainwater harvesting cisterns in Rajasthan:',opts:['Kund','Johad','Khadeen','Tanka'],ans:3,diff:'hard',expl:'Tankas = underground cylindrical cisterns.'},
      {q:'Largest freshwater reservoir:',opts:['Rivers','Lakes','Glaciers','Groundwater'],ans:2,diff:'medium',expl:'Glaciers hold ~69% of freshwater.'},
    ],
    'Agriculture':[
      {q:'India is the largest producer of:',opts:['Wheat','Rice','Milk','Pulses'],ans:2,diff:'medium',expl:'India = world\'s largest milk producer.'},
      {q:'Green Revolution mainly benefited:',opts:['Pulses','Wheat and rice','Cotton','Fruits'],ans:1,diff:'easy',expl:'HYV seeds for wheat and rice.'},
      {q:'Rabi crops sown in:',opts:['June-July','Oct-Nov','March-April','Aug-Sept'],ans:1,diff:'easy',expl:'Oct-Nov sowing, harvest March-April.'},
    ],
    'Minerals and Energy Resources':[
      {q:'"Black Gold" refers to:',opts:['Coal','Iron','Petroleum','Manganese'],ans:2,diff:'easy',expl:'Petroleum = black gold.'},
      {q:'Major iron ore deposits in India:',opts:['Rajasthan','Jharkhand-Odisha belt','Punjab','Kerala'],ans:1,diff:'easy',expl:'Jharkhand, Odisha, Chhattisgarh, Karnataka.'},
    ],
    'Manufacturing Industries':[
      {q:'"Manchester of India":',opts:['Mumbai','Ahmedabad','Kolkata','Surat'],ans:1,diff:'medium',expl:'Ahmedabad for its textile industry.'},
      {q:'Steel city of India:',opts:['Jamshedpur','Bokaro','Bhilai','Durgapur'],ans:0,diff:'easy',expl:'Jamshedpur (TATA Steel).'},
      {q:'First cotton mill in India (1854):',opts:['Surat','Mumbai','Ahmedabad','Kolkata'],ans:1,diff:'medium',expl:'Bombay Spinning Mill, 1854.'},
    ],
    'Lifelines of National Economy':[
      {q:'Longest national highway in India:',opts:['NH-1','NH-44','NH-7','NH-2'],ans:1,diff:'medium',expl:'NH-44 (~3745 km).'},
      {q:'"Golden Quadrilateral" connects:',opts:['4 major metros','4 zones','4 dams','4 ports'],ans:0,diff:'easy',expl:'Delhi, Mumbai, Chennai, Kolkata.'},
      {q:'"Queen of the Arabian Sea":',opts:['Mumbai','Kochi','Kandla','Ennore'],ans:1,diff:'medium',expl:'Kochi.'},
    ],
    'Power Sharing':[
      {q:'Power sharing reduces:',opts:['Conflict','Government power','Centralisation','Decision speed'],ans:0,diff:'easy',expl:'Reduces conflict, ensures stability.'},
      {q:'Sri Lanka majoritarian policy favoured:',opts:['Equal rights','Sinhalese domination','Tamil rights','Federal system'],ans:1,diff:'medium',expl:'Gave preference to Sinhalese.'},
      {q:'Prudential reason for power sharing:',opts:['Morally right','Reduces conflict','Legally required','More efficient'],ans:1,diff:'medium',expl:'Prudential = practical stability.'},
    ],
    'Federalism':[
      {q:'India is:',opts:['Federal','Unitary','Quasi-federal','Confederal'],ans:2,diff:'medium',expl:'Quasi-federal — strong Centre.'},
      {q:'73rd Constitutional Amendment relates to:',opts:['Fundamental Rights','Panchayati Raj','Directive Principles','EC'],ans:1,diff:'medium',expl:'1992 — Panchayati Raj.'},
      {q:'Union List includes:',opts:['Agriculture','Police','Defence','Education'],ans:2,diff:'easy',expl:'Defence, foreign affairs, currency.'},
    ],
    'Democracy and Diversity':[
      {q:'1968 Mexico Olympics protest by:',opts:['Carl Lewis','Jesse Owens','Tommie Smith & John Carlos','Muhammad Ali'],ans:2,diff:'medium',expl:'Black Power salute.'},
      {q:'Social differences become divisions when they:',opts:['Are natural','Overlap with other differences','Are cultural','Are small'],ans:1,diff:'medium',expl:'Overlapping social differences cause divisions.'},
    ],
    'Gender Religion and Caste':[
      {q:'Gender division assigns __ work to women:',opts:['Paid','Domestic unpaid','Technical','All of above'],ans:1,diff:'medium',expl:'Traditional gender roles give domestic/unpaid work to women.'},
      {q:'Communalism means:',opts:['Community service','Using religion for politics','Social harmony','Festivals'],ans:1,diff:'medium',expl:'Religious identity used for political ends.'},
      {q:'Feminist movements demanded:',opts:['Legal rights equal to men','Separate laws','Religious reform only','Education only'],ans:0,diff:'easy',expl:'Equal legal, property, and voting rights.'},
    ],
    'Popular Struggles and Movements':[
      {q:'Bolivia water movement (2000) opposed:',opts:['Oil price hike','Privatisation of water','Tax increase','Army takeover'],ans:1,diff:'medium',expl:'Multinational privatisation of water supply.'},
      {q:'Nepal movement 2006 aimed at:',opts:['Establish monarchy','Restore democracy','Independence','Join India'],ans:1,diff:'easy',expl:'Restored multiparty democracy.'},
      {q:'Pressure groups influence through:',opts:['Elections only','Lobbying and campaigns','Overthrowing govt','No means'],ans:1,diff:'medium',expl:'Lobbying, public campaigns, opinion.'},
    ],
  },
  English:{
    'A Letter to God':[
      {q:'"A Letter to God" written by:',opts:['G.L. Fuentes','Edgar Poe','R.K. Narayan','Ruskin Bond'],ans:0,diff:'easy',expl:'Gregorio López y Fuentes.'},
      {q:'Lencho\'s crop was destroyed by:',opts:['Drought','Hailstorm','Flood','Fire'],ans:1,diff:'easy',expl:'A violent hailstorm.'},
    ],
    'Nelson Mandela':[
      {q:'Mandela became President of South Africa in:',opts:['1990','1992','1994','1996'],ans:2,diff:'easy',expl:'May 1994.'},
      {q:'Apartheid means:',opts:['Black rule','White rule','Racial segregation','Democracy'],ans:2,diff:'easy',expl:'Racial segregation policy (1948-1994).'},
    ],
    'Grammar and Composition':[
      {q:'Passive of "She writes a letter":',opts:['A letter is written by her.','A letter was written.','A letter will be written.','She had written.'],ans:0,diff:'medium',expl:'Present active → is written by.'},
      {q:'"The camel is the ship of the desert" is:',opts:['Simile','Personification','Metaphor','Hyperbole'],ans:2,diff:'easy',expl:'Comparison without like/as = metaphor.'},
      {q:'Coordinating conjunction joins:',opts:['Dependent clauses','Independent equal clauses','Phrases only','None of above'],ans:1,diff:'medium',expl:'And, but, or join equal/independent clauses.'},
    ],
  },
  Hindi:{
    'Balgobin Bhagat':[
      {q:'"बालगोबिन भगत" के लेखक:',opts:['रामवृक्ष बेनीपुरी','प्रेमचंद','रामचंद्र शुक्ल','हजारीप्रसाद'],ans:0,diff:'easy',expl:'रामवृक्ष बेनीपुरी।'},
      {q:'बालगोबिन भगत किसके भक्त थे?',opts:['राम','कृष्ण','शिव','कबीर'],ans:3,diff:'easy',expl:'कबीर के अनुयायी।'},
    ],
    'Vyakaran - Sandhi':[
      {q:'"विद्यालय" में संधि:',opts:['स्वर','व्यंजन','विसर्ग','कोई नहीं'],ans:0,diff:'medium',expl:'विद्या + आलय — दीर्घ स्वर संधि।'},
      {q:'"अनुचित" में उपसर्ग:',opts:['अ','अन','अनु','न'],ans:1,diff:'easy',expl:'"अन्" उपसर्ग।'},
    ],
    'Vyakaran - Samas':[
      {q:'"विद्यार्थी" में समास:',opts:['तत्पुरुष','द्विगु','अव्ययीभाव','बहुव्रीहि'],ans:0,diff:'medium',expl:'तत्पुरुष समास।'},
      {q:'"यथाशक्ति" में समास:',opts:['तत्पुरुष','अव्ययीभाव','बहुव्रीहि','कर्मधारय'],ans:1,diff:'medium',expl:'अव्ययीभाव समास।'},
      {q:'"गाय" का बहुवचन:',opts:['गायें','गाय','गाये','गायों'],ans:0,diff:'easy',expl:'गायें।'},
    ],
  },
  'Computer Science':{
    'Networking Basics':[
      {q:'LAN stands for:',opts:['Large Area Network','Local Area Network','Long Area Network','Linked Area Node'],ans:1,diff:'easy',expl:'Local Area Network.'},
      {q:'Device connecting different networks:',opts:['Switch','Hub','Router','Repeater'],ans:2,diff:'medium',expl:'Router.'},
      {q:'IP stands for:',opts:['Internet Protocol','Internal Process','Internet Provider','Inbound Protocol'],ans:0,diff:'easy',expl:'Internet Protocol.'},
    ],
    'Python Introduction':[
      {q:'Python is a __ level language:',opts:['Low','Middle','High','Machine'],ans:2,diff:'easy',expl:'High-level, interpreted language.'},
      {q:'Comment symbol in Python:',opts:['//','/* */','#','--'],ans:2,diff:'easy',expl:'# for single-line comments.'},
      {q:'Output of print(2**3):',opts:['6','8','9','5'],ans:1,diff:'easy',expl:'2³=8.'},
      {q:'Function to convert string to int:',opts:['str()','float()','int()','bool()'],ans:2,diff:'easy',expl:'int("5")=5.'},
    ],
    'HTML Fundamentals':[
      {q:'HTML stands for:',opts:['HyperText Markup Language','High Text Making Language','Home Tool Makeup Language','Hyper Transfer Markup Language'],ans:0,diff:'easy',expl:'HyperText Markup Language.'},
      {q:'Largest heading tag:',opts:['<h6>','<h1>','<head>','<header>'],ans:1,diff:'easy',expl:'<h1> is largest.'},
      {q:'href attribute used in:',opts:['<img>','<p>','<a>','<div>'],ans:2,diff:'easy',expl:'<a href="..."> for links.'},
    ],
    'Database Concepts':[
      {q:'SQL stands for:',opts:['Structured Query Language','Simple Query Language','Standard Query Logic','Sequential Query Language'],ans:0,diff:'easy',expl:'Structured Query Language.'},
      {q:'PRIMARY KEY uniquely identifies:',opts:['A table','Each row','Each column','A database'],ans:1,diff:'medium',expl:'PRIMARY KEY uniquely identifies each record.'},
    ],
  }
};

// ═══════════════════════════ BUILT-IN QUESTIONS ═══════════════════════════
const BUILTIN_QUESTIONS = [
  {id:'b1',subject:'Mathematics',chapter:'Real Numbers',difficulty:'easy',question:'What is the value of √144?',options:['10','11','12','13'],answer:2,explanation:'√144=12.',type:'custom'},
  {id:'b2',subject:'Mathematics',chapter:'Quadratic Equations',difficulty:'medium',question:'If 2x+3=11, x=?',options:['3','4','5','6'],answer:1,explanation:'2x=8, x=4.',type:'custom'},
  {id:'b3',subject:'Mathematics',chapter:'Real Numbers',difficulty:'medium',question:'HCF of 36 and 48:',options:['6','9','12','18'],answer:2,explanation:'HCF=12.',type:'custom'},
  {id:'b4',subject:'Mathematics',chapter:'Triangles',difficulty:'hard',question:'Right triangle: leg=3, hyp=5, other leg=?',options:['2','3','4','6'],answer:2,explanation:'3²+b²=5² → b=4.',type:'custom'},
  {id:'b5',subject:'Mathematics',chapter:'Triangles',difficulty:'easy',question:'Sum of angles in a triangle:',options:['90°','180°','270°','360°'],answer:1,explanation:'180°.',type:'custom'},
  {id:'b6',subject:'Mathematics',chapter:'Areas Related to Circles',difficulty:'medium',question:'Area of circle r=7cm (π=22/7):',options:['154 cm²','144 cm²','164 cm²','174 cm²'],answer:0,explanation:'πr²=154cm².',type:'custom'},
  {id:'b7',subject:'Mathematics',chapter:'Quadratic Equations',difficulty:'hard',question:'Roots of x²−5x+6=0:',options:['2 and 3','1 and 6','2 and 4','−2 and −3'],answer:0,explanation:'(x−2)(x−3)=0.',type:'custom'},
  {id:'b8',subject:'Science',chapter:'Chemical Reactions and Equations',difficulty:'easy',question:'Chemical formula of water:',options:['H₂O','CO₂','O₂','H₂'],answer:0,explanation:'H₂O.',type:'custom'},
  {id:'b9',subject:'Science',chapter:'Life Processes',difficulty:'medium',question:'Powerhouse of the cell:',options:['Nucleus','Ribosome','Mitochondria','Chloroplast'],answer:2,explanation:'Mitochondria produce ATP.',type:'custom'},
  {id:'b10',subject:'Science',chapter:'Electricity',difficulty:'medium',question:'Newton\'s second law F=',options:['ma','mv','m/a','a/m'],answer:0,explanation:'F=ma.',type:'custom'},
  {id:'b11',subject:'Science',chapter:'Acids Bases and Salts',difficulty:'hard',question:'pH of neutral solution at 25°C:',options:['0','7','14','1'],answer:1,explanation:'pH 7=neutral.',type:'custom'},
  {id:'b12',subject:'Science',chapter:'Life Processes',difficulty:'easy',question:'Gas released during photosynthesis:',options:['CO₂','N₂','O₂','H₂'],answer:2,explanation:'O₂.',type:'custom'},
  {id:'b13',subject:'English',chapter:'Grammar and Composition',difficulty:'medium',question:'Passive of "She writes a letter":',options:['A letter is written by her.','A letter was written by her.','A letter will be written.','Letter is being written.'],answer:0,explanation:'Present → is written by.',type:'custom'},
  {id:'b14',subject:'Social Studies',chapter:'Nationalism in India',difficulty:'easy',question:'Who wrote the Indian National Anthem?',options:['Bankim Chandra','Rabindranath Tagore','Gandhi','Patel'],answer:1,explanation:'Tagore, 1911.',type:'custom'},
  {id:'b15',subject:'Hindi',chapter:'Vyakaran - Samas',difficulty:'easy',question:'"गाय" का बहुवचन:',options:['गायें','गाय','गाये','गायों'],answer:0,explanation:'गायें।',type:'custom'},
];

const PYQ_BANK = [
  {id:'p1',subject:'Mathematics',chapter:'Polynomials',year:'2023',difficulty:'medium',question:'Sum of zeros of 3x²−kx+6 is 3; k=?',options:['6','9','3','12'],answer:1,explanation:'k/3=3→k=9.',type:'pyq'},
  {id:'p2',subject:'Mathematics',chapter:'Triangles',year:'2022',difficulty:'hard',question:'Ladder 10m reaches window 8m high. Distance from wall=?',options:['4m','6m','5m','7m'],answer:1,explanation:'√(100-64)=6m.',type:'pyq'},
  {id:'p3',subject:'Mathematics',chapter:'Real Numbers',year:'2021',difficulty:'easy',question:'Decimal expansion of 17/8:',options:['2.125','2.1','2.25','2.5'],answer:0,explanation:'17÷8=2.125.',type:'pyq'},
  {id:'p4',subject:'Mathematics',chapter:'Arithmetic Progressions',year:'2020',difficulty:'medium',question:'If nth term of AP is (2n+1), sum of first n terms:',options:['n(n+1)','n²+2n','n(n+2)','2n²+1'],answer:2,explanation:'n(n+2).',type:'pyq'},
  {id:'p5',subject:'Mathematics',chapter:'Probability',year:'2019',difficulty:'hard',question:'P(sum=7 on two dice):',options:['1/6','5/36','1/9','7/36'],answer:0,explanation:'6 favorable outcomes/36=1/6.',type:'pyq'},
  {id:'p6',subject:'Mathematics',chapter:'Coordinate Geometry',year:'2018',difficulty:'medium',question:'Distance between (2,3) and (4,1):',options:['2√2','2√3','4','3√2'],answer:0,explanation:'√8=2√2.',type:'pyq'},
  {id:'p7',subject:'Science',chapter:'Chemical Reactions and Equations',year:'2023',difficulty:'medium',question:'Which is a decomposition reaction?',options:['C+O₂→CO₂','2H₂O→2H₂+O₂','CaO+H₂O→Ca(OH)₂','AgNO₃+NaCl→AgCl+NaNO₃'],answer:1,explanation:'One compound breaks into simpler substances.',type:'pyq'},
  {id:'p8',subject:'Science',chapter:'The Human Eye',year:'2022',difficulty:'easy',question:'Which part controls light entering the eye?',options:['Retina','Iris','Cornea','Lens'],answer:1,explanation:'Iris controls pupil size.',type:'pyq'},
  {id:'p9',subject:'Science',chapter:'Electricity',year:'2021',difficulty:'hard',question:'I=2A, R=5Ω, t=10min. Heat produced (J):',options:['6000','12000','600','1200'],answer:1,explanation:'H=I²Rt=4×5×600=12000J.',type:'pyq'},
  {id:'p10',subject:'Science',chapter:'Light - Reflection and Refraction',year:'2020',difficulty:'medium',question:'Image in concave mirror when object is at C:',options:['Virtual,erect,magnified','Real,inverted,same size','Real,inverted,magnified','Virtual,erect,same size'],answer:1,explanation:'Real, inverted, same size.',type:'pyq'},
  {id:'p11',subject:'Science',chapter:'Metals and Non-metals',year:'2019',difficulty:'easy',question:'Highest electronegativity element:',options:['Oxygen','Chlorine','Nitrogen','Fluorine'],answer:3,explanation:'Fluorine (3.98 Pauling).',type:'pyq'},
  {id:'p12',subject:'Science',chapter:'Control and Coordination',year:'2018',difficulty:'medium',question:'Fight-or-flight hormone secreted by:',options:['Thyroid','Pancreas','Adrenal gland','Pituitary'],answer:2,explanation:'Adrenal medulla.',type:'pyq'},
  {id:'p13',subject:'English',chapter:'Grammar and Composition',year:'2023',difficulty:'medium',question:'Reported speech of: He said, "I am going to school."',options:['He said that he was going to school.','He said that I am going to school.','He said that he is going.','He told that he was going.'],answer:0,explanation:'am→was, I→he.',type:'pyq'},
  {id:'p14',subject:'English',chapter:'Nelson Mandela',year:'2022',difficulty:'easy',question:'"Benevolent" means:',options:['Cruel','Kind and generous','Selfish','Timid'],answer:1,explanation:'Well-meaning and kindly.',type:'pyq'},
  {id:'p15',subject:'English',chapter:'Grammar and Composition',year:'2021',difficulty:'medium',question:'"The camel is the ship of the desert" — figure of speech:',options:['Simile','Personification','Metaphor','Hyperbole'],answer:2,explanation:'Metaphor.',type:'pyq'},
  {id:'p16',subject:'Social Studies',chapter:'Nationalism in India',year:'2023',difficulty:'medium',question:'Jallianwala Bagh massacre:',options:['1917','1919','1920','1921'],answer:1,explanation:'April 13, 1919.',type:'pyq'},
  {id:'p17',subject:'Social Studies',chapter:'Power Sharing',year:'2022',difficulty:'easy',question:'Which is NOT a feature of democracy?',options:['Free elections','Rule of law','Single-party rule','Fundamental rights'],answer:2,explanation:'Single-party rule contradicts democracy.',type:'pyq'},
  {id:'p18',subject:'Social Studies',chapter:'Manufacturing Industries',year:'2021',difficulty:'hard',question:'Sector where natural products are processed through manufacturing:',options:['Primary','Secondary','Tertiary','Quaternary'],answer:1,explanation:'Secondary sector.',type:'pyq'},
  {id:'p19',subject:'Social Studies',chapter:'Federalism',year:'2020',difficulty:'medium',question:'73rd Constitutional Amendment relates to:',options:['Fundamental Rights','Panchayati Raj','Directive Principles','EC'],answer:1,explanation:'1992 — Panchayati Raj.',type:'pyq'},
  {id:'p20',subject:'Hindi',chapter:'Vyakaran - Samas',year:'2023',difficulty:'medium',question:'"विद्यार्थी" में समास:',options:['तत्पुरुष','द्विगु','अव्ययीभाव','बहुव्रीहि'],answer:0,explanation:'तत्पुरुष।',type:'pyq'},
  {id:'p21',subject:'Hindi',chapter:'Vyakaran - Sandhi',year:'2022',difficulty:'easy',question:'"अनुचित" में उपसर्ग:',options:['अ','अन','अनु','न'],answer:1,explanation:'"अन्"।',type:'pyq'},
];

// ═══════════════════════════ STATE ═══════════════════════════


// ═══════════════════════════ STATE ═══════════════════════════
let currentUser=null,files=[],customQuestions=[],testHistory=[];
let activeFilter='all',activePYQSubj='Mathematics';
let currentQuestions=[],currentQ=0,userAnswers=[];
let timerInterval=null,timeLeft=0,testStartTime=null;
let editingQId=null,generatedQuestions=[];
let imgZoom=100;

// ═══════════════════════════════════════════════════════════════════════════════
// FIREBASE ENGINE — Auth + Firestore + Hosting + Backend APIs
// ═══════════════════════════════════════════════════════════════════════════════

// Admin roles are managed via Firebase Auth custom claims / Firestore
// Do not hardcode credentials here
const ADMIN_EMAILS = [];

// ── Firebase Config (replace with your own from Firebase Console) ─────────────
const FIREBASE_CONFIG = {
  apiKey:            "AIzaSyD_4yCL3oAmTsNgvFhWjMpYB5FHs0PXDn4",
  authDomain:        "study-hub-3aaf6.firebaseapp.com",
  projectId:         "study-hub-3aaf6",
  storageBucket:     "study-hub-3aaf6.firebasestorage.app",
  messagingSenderId: "44505430852",
  appId:             "1:44505430852:web:fab5459ca2d93a82353511",
  measurementId:     "G-00WH0FSKDC"
};

// ── Firebase SDK (loaded via CDN) ─────────────────────────────────────────────
let _fbApp = null, _fbAuth = null, _fbDb = null;
let _fbReady = false;
let _fbReadyCallbacks = [];

function onFirebaseReady(cb) {
  if (_fbReady) cb(); else _fbReadyCallbacks.push(cb);
}


// ── Demo Data (shown when no real data exists) ────────────────────────────────
function injectDemoDataIfEmpty() {
  // Demo students
  const demoUsers = [
    { uid:'demo1', name:'Priya Sharma', username:'priya_s', email:'priya@studyhub.local', role:'student', classSection:'10A', joinedAt:'2026-01-10T00:00:00Z', score:88 },
    { uid:'demo2', name:'Arjun Mehta', username:'arjun_m', email:'arjun@studyhub.local', role:'student', classSection:'10B', joinedAt:'2026-01-12T00:00:00Z', score:76 },
    { uid:'demo3', name:'Sneha Patel', username:'sneha_p', email:'sneha@studyhub.local', role:'student', classSection:'10A', joinedAt:'2026-01-15T00:00:00Z', score:92 },
    { uid:'demo4', name:'Rohit Das', username:'rohit_d', email:'rohit@studyhub.local', role:'student', classSection:'10C', joinedAt:'2026-02-01T00:00:00Z', score:65 },
    { uid:'demo5', name:'Ananya Singh', username:'ananya_s', email:'ananya@studyhub.local', role:'student', classSection:'10B', joinedAt:'2026-02-05T00:00:00Z', score:80 },
  ];
  demoUsers.forEach(u => {
    if (!LS.get('users_' + u.uid)) LS.set('users_' + u.uid, u);
  });

  // Demo notes/materials
  const demoFiles = LS.get('demoFiles');
  if (!demoFiles) {
    LS.set('demoFiles', [
      { id:'df1', name:'Mathematics - Real Numbers Notes.pdf', subject:'Mathematics', chapter:'Real Numbers', size:'1.2 MB', uploadedAt:'2026-03-01T00:00:00Z', storage:'demo', demoUrl:'#' },
      { id:'df2', name:'Science - Chemical Reactions Summary.pdf', subject:'Science', chapter:'Chemical Reactions and Equations', size:'0.9 MB', uploadedAt:'2026-03-05T00:00:00Z', storage:'demo', demoUrl:'#' },
      { id:'df3', name:'English - Letter Writing Guide.pdf', subject:'English', chapter:'Writing Skills', size:'0.5 MB', uploadedAt:'2026-03-10T00:00:00Z', storage:'demo', demoUrl:'#' },
    ]);
  }

  // Demo analytics
  if (!LS.get('analytics')) {
    LS.set('analytics', {
      totalStudents: 5,
      activeToday: 3,
      quizzesCompleted: 42,
      avgScore: 80,
      topSubject: 'Mathematics',
    });
  }
}

// ── localStorage helpers (replaces Firestore) ────────────────────────────────
const LS = {
  get: (key) => { try { return JSON.parse(localStorage.getItem('sh_'+key)); } catch(e) { return null; } },
  set: (key, val) => { try { localStorage.setItem('sh_'+key, JSON.stringify(val)); } catch(e) {} },
  del: (key) => { try { localStorage.removeItem('sh_'+key); } catch(e) {} },
};

async function initFirebase() {
  if (_fbReady) return;
  const [{ initializeApp }, { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
          signOut, onAuthStateChanged, updateProfile, sendPasswordResetEmail,
          sendEmailVerification, GoogleAuthProvider, signInWithPopup },
         { getFirestore, doc, getDoc, setDoc, updateDoc, collection, getDocs,
           query, where, orderBy, limit, serverTimestamp, deleteDoc, onSnapshot }
  ] = await Promise.all([
    import('https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js'),
    import('https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js'),
    import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js'),
  ]);

  _fbApp  = initializeApp(FIREBASE_CONFIG);
  _fbAuth = getAuth(_fbApp);
  _fbDb   = getFirestore(_fbApp);
  window._fbStorage = null;

  const _googleProvider = new GoogleAuthProvider();
  window._fb = {
    // Auth
    createUser: (email, pass) => createUserWithEmailAndPassword(_fbAuth, email, pass),
    signIn:     (email, pass) => signInWithEmailAndPassword(_fbAuth, email, pass),
    signOut:    ()            => signOut(_fbAuth),
    updateProfile: (user, data) => updateProfile(user, data),
    onAuthStateChanged: (cb)  => onAuthStateChanged(_fbAuth, cb),
    currentFbUser: ()         => _fbAuth.currentUser,
    resetPassword: (email)    => sendPasswordResetEmail(_fbAuth, email),
    verifyEmail:  (user)      => sendEmailVerification(user),
    googleSignIn: ()          => signInWithPopup(_fbAuth, _googleProvider),
    // Real Firestore
    doc: (col, id) => doc(_fbDb, col, id),
    getDoc, setDoc, updateDoc,
    collection: (col) => collection(_fbDb, col),
    getDocs, query, where, orderBy, limit,
    serverTimestamp, deleteDoc, onSnapshot,
    // Storage handled by Cloudinary
    db: () => _fbDb,
    userDoc:  (uid) => doc(_fbDb, 'users', uid),
    dataDoc:  (uid) => doc(_fbDb, 'userData', uid),
    roomsCol: ()    => collection(_fbDb, 'rooms'),
    roomDoc:  (id)  => doc(_fbDb, 'rooms', id),
    logCol:   ()    => collection(_fbDb, 'adminLog'),
  };

  _fbReady = true;
  _fbReadyCallbacks.forEach(cb => cb());
  _fbReadyCallbacks = [];
  // Cache flag so repeat visits skip SDK load
  try { sessionStorage.setItem('fb_init','1'); } catch(e) {}
}

// ── In-memory cache (mirrors Firestore data locally) ─────────────────────────
let _cache = {
  userData: {},   // { [uid]: { files, questions, history } }
  rooms:    {},   // { [roomId]: room }
  users:    {},   // { [uid]: userProfile }
  adminLog: [],
};
let _dbDirty  = false;
let _saveTimer = null;

// ── Show/hide sync status ─────────────────────────────────────────────────────
function showDbStatus(msg) {
  let el = document.getElementById('dbStatusBar');
  if (!el) {
    el = document.createElement('div');
    el.id = 'dbStatusBar';
    el.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--surface);border:1px solid var(--purple);color:var(--purple3);padding:8px 20px;border-radius:20px;font-size:.82rem;z-index:9999;display:flex;align-items:center;gap:8px;box-shadow:0 4px 20px rgba(124,58,237,.3);';
    document.body.appendChild(el);
  }
  el.innerHTML = '<span style="animation:spin 1s linear infinite;display:inline-block">⚙️</span> ' + msg;
  el.style.display = 'flex';
}
function hideDbStatus() {
  const el = document.getElementById('dbStatusBar');
  if (el) el.style.display = 'none';
}

// ── User profile CRUD via Firestore ──────────────────────────────────────────
async function fbGetUserProfile(uid) {
  if (_cache.users[uid]) return _cache.users[uid];
  const snap = await window._fb.getDoc(window._fb.userDoc(uid));
  if (snap.exists()) { _cache.users[uid] = snap.data(); return snap.data(); }
  return null;
}

async function fbSaveUserProfile(uid, data) {
  _cache.users[uid] = data;
  await window._fb.setDoc(window._fb.userDoc(uid), data, { merge: true });
}

// ── User data (files, questions, history) via Firestore ───────────────────────
async function fbGetUserData(uid) {
  if (_cache.userData[uid]) return _cache.userData[uid];
  try {
    const snap = await window._fb.getDoc(window._fb.dataDoc(uid));
    const d = snap.exists() ? snap.data() : { files:[], questions:[...BUILTIN_QUESTIONS], history:[] };
    _cache.userData[uid] = d;
    return d;
  } catch(e) {
    return { files:[], questions:[...BUILTIN_QUESTIONS], history:[] };
  }
}

async function fbSaveUserData(uid, data) {
  _cache.userData[uid] = data;
  try {
    await window._fb.setDoc(window._fb.dataDoc(uid), data);
  } catch(e) { console.warn('Firestore save failed:', e); }
}

// ── Rooms via Firestore ───────────────────────────────────────────────────────
async function fbGetRooms() {
  try {
    const snap = await window._fb.getDocs(window._fb.roomsCol());
    const rooms = {};
    snap.forEach(d => { rooms[d.id] = { id: d.id, ...d.data() }; });
    _cache.rooms = rooms;
    return rooms;
  } catch(e) { return _cache.rooms || {}; }
}

async function fbSaveRoom(id, data) {
  _cache.rooms[id] = data;
  await window._fb.setDoc(window._fb.roomDoc(id), data);
}

async function fbDeleteRoom(id) {
  delete _cache.rooms[id];
  await window._fb.deleteDoc(window._fb.roomDoc(id));
}

// ── Admin log via Firestore ───────────────────────────────────────────────────
async function fbAddLog(type, msg) {
  try {
    const logEntry = { type, msg, time: new Date().toLocaleString(), ts: Date.now() };
    _cache.adminLog.unshift(logEntry);
    if (_cache.adminLog.length > 100) _cache.adminLog = _cache.adminLog.slice(0, 100);
    // Save as subdoc under adminLog collection
    const id = 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2,6);
    await window._fb.setDoc(
      window._fb.doc(window._fb.db(), 'adminLog', id),
      logEntry
    );
  } catch(e) {}
}

async function fbGetAdminLog() {
  if (_cache.adminLog.length) return _cache.adminLog;
  try {
    const { query, collection, orderBy, limit, getDocs } = window._fb;
    const q = query(collection(window._fb.db(), 'adminLog'), orderBy('ts','desc'), limit(100));
    const snap = await getDocs(q);
    _cache.adminLog = snap.docs.map(d => d.data());
    return _cache.adminLog;
  } catch(e) { return []; }
}

// ── Public API — same interface as old _db helpers ────────────────────────────
function getAllAccounts() { return _cache.users || {}; }
function saveAllAccounts(a) { _cache.users = a; markDirty(); }
function getUsers() { return Object.values(_cache.users||{}).map(u=>({...u,passwordHash:undefined})); }
function saveUsers() {}

function getUserData(uid) {
  return _cache.userData[uid] || { files:[], questions:[...BUILTIN_QUESTIONS], history:[] };
}
function saveUserData(uid, d) {
  _cache.userData[uid] = d;
  markDirty();
}

function loadUserState() {
  const d = getUserData(currentUser.uid);
  files           = d.files || [];
  customQuestions = d.questions && d.questions.length ? d.questions : [...BUILTIN_QUESTIONS];
  testHistory     = d.history || [];
}
function persistUserState() {
  saveUserData(currentUser.uid, { files, questions: customQuestions, history: testHistory });
  // Async write to Firestore (non-blocking)
  if (_fbReady && currentUser) {
    fbSaveUserData(currentUser.uid, { files, questions: customQuestions, history: testHistory })
      .catch(() => {});
  }
}

function getRooms()   { return _cache.rooms || {}; }
function saveRooms(r) {
  const prev = _cache.rooms || {};
  _cache.rooms = r;
  // Diff and sync changed/new rooms
  if (_fbReady) {
    Object.keys(r).forEach(id => {
      if (JSON.stringify(r[id]) !== JSON.stringify(prev[id])) {
        fbSaveRoom(id, r[id]).catch(() => {});
      }
    });
    Object.keys(prev).forEach(id => {
      if (!r[id]) fbDeleteRoom(id).catch(() => {});
    });
  }
}

function getAdminLog()   { return _cache.adminLog || []; }
function saveAdminLog(l) { _cache.adminLog = l; }
function addAdminLog(type, msg) {
  const entry = { type, msg, time: new Date().toLocaleString(), ts: Date.now() };
  _cache.adminLog.unshift(entry);
  if (_fbReady) fbAddLog(type, msg).catch(() => {});
}

function markDirty() {
  _dbDirty = true;
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => { if (currentUser) persistUserState(); }, 800);
}

// ── dbLoad / dbSave (kept for compat — backed by Firestore now) ────────────────
async function dbLoad() {
  // Firebase handles its own loading — this is a no-op placeholder
}
async function dbSave(force=false) {
  if (currentUser) await persistUserState();
}

// ── SHA-256 hash (kept for legacy compat) ─────────────────────────────────────
async function hashPass(p) {
  const msgBuf = new TextEncoder().encode(p + '|sh2025_secure');
  const hashBuf = await crypto.subtle.digest('SHA-256', msgBuf);
  return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

// ── ls/lsSet for non-critical UI state ────────────────────────────────────────
function ls(k,d){try{const v=localStorage.getItem('ui_'+k);return v?JSON.parse(v):d;}catch{return d;}}
function lsSet(k,v){try{localStorage.setItem('ui_'+k,JSON.stringify(v));}catch{}}



// ═══════════════════════════ CHAPTER HELPERS ═══════════════════════════
function getChapters(s){return SUBJECTS_CHAPTERS[s]||[];}
function populateSelect(id,subj,selected,allLabel){
  const el=document.getElementById(id); if(!el)return;
  const chs=getChapters(subj);
  el.innerHTML=`<option value="">${allLabel||'All Chapters'}</option>`+
    chs.map(c=>`<option value="${c}"${c===selected?' selected':''}>${c}</option>`).join('');
}
function updateModalChapter(sel){
  const subj=document.getElementById('qSubject').value;
  populateSelect('qChapter',subj,sel||'','— Select Chapter —');
}
function updateQChapterFilter(){
  const subj=document.getElementById('qSubjFilter').value;
  if(subj)populateSelect('qChapterFilter',subj,'','All Chapters');
  else document.getElementById('qChapterFilter').innerHTML='<option value="">All Chapters</option>';
}
function updatePYQChapterFilter(){
  populateSelect('pyqChapterFilter',activePYQSubj,'','All Chapters');
}
function updateAIChapters(){
  const subj=document.getElementById('aiSubject')?.value||'Mathematics';
  populateSelect('aiChapter',subj,'','— All Chapters —');
  const el=document.getElementById('aiChapter');
  if(el&&el.options.length>1)el.selectedIndex=1;
}
function updateTestChapterFilter(){
  const checked=[...document.querySelectorAll('#subjCheckboxes input:checked')].map(c=>c.value);
  if(checked.length===1)populateSelect('testChapterFilter',checked[0],'','All Chapters');
  else document.getElementById('testChapterFilter').innerHTML='<option value="">All Chapters</option>';
}

// ═══════════════════════════ TOAST ═══════════════════════════
function showToast(msg,type='info',dur=3000){
  const c=document.getElementById('toastContainer');
  if(!c)return;
  const t=document.createElement('div');
  t.className='toast toast-'+type;
  t.textContent=msg;
  c.appendChild(t);
  setTimeout(()=>t.classList.add('show'),10);
  setTimeout(()=>{t.classList.remove('show');setTimeout(()=>t.remove(),300);},dur);
}


// ═══════════════════════════ NAV ═══════════════════════════
const PAGES=['home','dashboard','upload','rooms','pyq','test','history','ai','editor','admin'];
function showPage(id){
  if (id === 'profile') { setTimeout(() => { renderProfilePage(); }, 50); }
  if(id==='admin'&&!isAdmin()){showToast('🔒 Admin only','error');return;}
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  // Update sidebar active state
  document.querySelectorAll('#sidebarNav .nav-tab').forEach(t=>t.classList.remove('active'));
  const idx = PAGES.indexOf(id);
  if(idx>=0) document.querySelectorAll('#sidebarNav .nav-tab')[idx]?.classList.add('active');
  if(id==='history')renderHistory();
  if(id==='home')updateHomeStats();
  if(id==='dashboard')renderDashboard();
  if(id==='admin'){renderAdminPanel();}
  if(id==='editor'){applyEditorPermissions();renderQTable();}
  if(id==='pyq'){updatePYQChapterFilter();renderPYQ();}
  if(id==='upload'){applyUploadPermissions();renderFiles();}
  if(id==='rooms'){initRooms();}
}

// ═══════════════════════════ HOME STATS ═══════════════════════════
function updateHomeStats(){
  // Animate all stat counters
  setTimeout(() => {
    document.querySelectorAll('[data-counter]').forEach(el => {
      const target = parseInt(el.dataset.counter || el.textContent);
      if (!isNaN(target)) animateCounter(el, target);
    });
  }, 200);
  document.getElementById('statFiles').textContent=files.length;
  document.getElementById('statTests').textContent=testHistory.length;
  const rooms=getRooms(); const roomCount=Object.keys(rooms).length;
  const statRoomsEl=document.getElementById('statRooms');
  if(statRoomsEl) statRoomsEl.textContent=roomCount;
  const allAccounts=getAllAccounts(); const studentCount=Object.values(allAccounts).filter(u=>u.role!=='admin').length;
  document.getElementById('statQs').textContent=studentCount||Object.keys(allAccounts).length;
  const uploadTabEl=document.getElementById('uploadTab');
  if(uploadTabEl && files.length) {
    const badge=uploadTabEl.querySelector('.badge-pill');
    if(!badge){const b=document.createElement('span');b.className='badge-pill';b.textContent=files.length;uploadTabEl.appendChild(b);}
    else badge.textContent=files.length;
  }
}

// ═══════════════════════════ FILE UPLOAD + VIEWER ═══════════════════════════


// ═══════════════════════════ FILE UPLOAD + VIEWER ═══════════════════════════
const uploadZone=document.getElementById('uploadZone');
uploadZone.addEventListener('dragover',e=>{e.preventDefault();uploadZone.classList.add('drag-over');});
uploadZone.addEventListener('dragleave',()=>uploadZone.classList.remove('drag-over'));
uploadZone.addEventListener('drop',e=>{e.preventDefault();uploadZone.classList.remove('drag-over');handleFiles(e.dataTransfer.files);});
uploadZone.addEventListener('click',()=>document.getElementById('fileInput').click());

// ═══════════════════════════════════════════════════════════════════════════════
// CLOUDINARY CLOUD STORAGE ENGINE
// Files are uploaded directly to Cloudinary from the browser using an
// unsigned upload preset. No server required. Config saved in localStorage.
// Fallback: if Cloudinary is not configured, old local DataURL mode is used.
// ═══════════════════════════════════════════════════════════════════════════════

const CLD_LS_KEY = 'sh_cloudinary_config';
// ── Hardcoded Cloudinary Config ───────────────────────────────────────────────
const CLOUDINARY_CONFIG = {
  cloudName: 'dg7dbea60',
  uploadPreset: 'studyhub_uploads',
};
// Auto-save to localStorage on load
(function() {
  if (!localStorage.getItem(CLD_LS_KEY)) {
    localStorage.setItem(CLD_LS_KEY, JSON.stringify(CLOUDINARY_CONFIG));
  }
})();
const MAX_PREVIEW_BYTES = 4 * 1024 * 1024; // 4 MB local preview fallback

// ── Load / save Cloudinary config ─────────────────────────────────────────────
function getCldConfig() {
  try {
    const saved = JSON.parse(localStorage.getItem(CLD_LS_KEY) || 'null');
    return saved || CLOUDINARY_CONFIG;
  } catch { return CLOUDINARY_CONFIG; }
}
function isCldEnabled() {
  return true; // Always enabled with hardcoded config
}

function saveCldConfig() {
  const cloudName = document.getElementById('cldCloudName').value.trim();
  const uploadPreset = document.getElementById('cldUploadPreset').value.trim();
  const msg = document.getElementById('cldStatusMsg');
  if (!cloudName || !uploadPreset) {
    msg.textContent = '❌ Both fields are required.'; msg.className = 'cld-status-msg err'; return;
  }
  localStorage.setItem(CLD_LS_KEY, JSON.stringify({ cloudName, uploadPreset }));
  updateCldUI();
  msg.textContent = '✅ Saved! Cloudinary is now active. Files will upload to cloud.'; msg.className = 'cld-status-msg ok';
  setTimeout(() => { msg.textContent = ''; }, 3500);
  showToast('☁️ Cloudinary enabled — files will upload to cloud!', 'success');
}

async function testCldConnection() {
  const cfg = getCldConfig();
  const msg = document.getElementById('cldStatusMsg');
  if (!cfg) { msg.textContent = '❌ Save config first.'; msg.className = 'cld-status-msg err'; return; }
  msg.textContent = '⏳ Testing…'; msg.className = 'cld-status-msg';
  try {
    // Ping the Cloudinary ping endpoint to verify cloud name exists
    const res = await fetch(`https://api.cloudinary.com/v1_1/${cfg.cloudName}/ping`);
    const data = await res.json();
    if (data.status === 'ok') {
      msg.textContent = '✅ Connected! Cloud "' + cfg.cloudName + '" is reachable.';
      msg.className = 'cld-status-msg ok';
    } else {
      msg.textContent = '❌ Cloud name not found — check spelling.';
      msg.className = 'cld-status-msg err';
    }
  } catch(e) {
    msg.textContent = '❌ Network error — check Cloud Name.';
    msg.className = 'cld-status-msg err';
  }
}

function updateCldUI() {
  const cfg = getCldConfig();
  const badge = document.getElementById('cldBadge');
  if (!badge) return;
  if (cfg && cfg.cloudName && cfg.uploadPreset) {
    badge.textContent = '✅ Active — ' + cfg.cloudName;
    badge.className = 'cld-badge';
    document.getElementById('cldCloudName').value = cfg.cloudName;
    document.getElementById('cldUploadPreset').value = cfg.uploadPreset;
    document.getElementById('uploadZoneTitle').textContent = '☁️ Drag & Drop — uploads to Cloudinary';
    document.getElementById('uploadLimitLabel').textContent = 'up to 100 MB · stored in cloud forever';
    document.getElementById('uploadZoneSubtitle').style.color = '#4ade80';
  } else {
    badge.textContent = 'Not Configured';
    badge.className = 'cld-badge inactive';
    document.getElementById('uploadZoneTitle').textContent = 'Drag & Drop files here';
    document.getElementById('uploadLimitLabel').textContent = 'max 4 MB (local preview)';
    document.getElementById('uploadZoneSubtitle').style.color = '';
  }
}

// ── Upload a single file to Cloudinary via unsigned upload ────────────────────
async function uploadToCloudinary(file, onProgress) {
  const cfg = getCldConfig();
  if (!cfg) throw new Error('Cloudinary not configured');

  // Determine resource type
  const ext = file.name.split('.').pop().toLowerCase();
  const isVideo = ['mp4','webm','ogg','mov','avi','mkv'].includes(ext);
  const isRaw = ['pdf','doc','docx','ppt','pptx','xls','xlsx','txt','md','zip','rar','py','js','html','css'].includes(ext);
  const resourceType = isVideo ? 'video' : isRaw ? 'raw' : 'image';

  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', cfg.uploadPreset);
  fd.append('folder', 'studyhub');
  fd.append('public_id', 'sh_' + Date.now() + '_' + file.name.replace(/[^a-zA-Z0-9._-]/g,'_'));

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `https://api.cloudinary.com/v1_1/${cfg.cloudName}/${resourceType}/upload`);
    xhr.upload.onprogress = e => {
      if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded / e.total * 100));
    };
    xhr.onload = () => {
      if (xhr.status === 200) {
        resolve(JSON.parse(xhr.responseText));
      } else {
        let errMsg = 'Upload failed';
        try { errMsg = JSON.parse(xhr.responseText).error?.message || errMsg; } catch {}
        reject(new Error(errMsg));
      }
    };
    xhr.onerror = () => reject(new Error('Network error during upload'));
    xhr.send(fd);
  });
}

// ── Set upload progress UI ────────────────────────────────────────────────────
function setUploadProgress(pct, label) {
  const wrap = document.getElementById('uploadProgressWrap');
  const fill = document.getElementById('uploadProgressFill');
  const lbl  = document.getElementById('uploadProgressLabel');
  if (!wrap) return;
  if (pct === null) { wrap.classList.remove('show'); return; }
  wrap.classList.add('show');
  fill.style.width = pct + '%';
  lbl.textContent  = label || ('Uploading… ' + pct + '%');
}

// ── Main handleFiles — Cloudinary if configured, local DataURL fallback ───────
async function handleFiles(fl) {
  if (!isAdmin()) { showToast('🔒 Only admin can upload', 'error'); return; }
  const subject = document.getElementById('uploadSubject').value || 'General';
  const type    = document.getElementById('uploadType').value;
  const titleEl = document.getElementById('uploadTitle');
  const customTitle = titleEl ? titleEl.value.trim() : '';
  const arr     = Array.from(fl);
  if (!arr.length) return;

  if (isCldEnabled()) {
    // ── CLOUDINARY PATH ──────────────────────────────────────────────────────
    let uploaded = 0;
    for (const f of arr) {
      setUploadProgress(0, `☁️ Uploading "${f.name}" (${uploaded + 1}/${arr.length})…`);
      try {
        const result = await uploadToCloudinary(f, pct => {
          const overall = Math.round((uploaded / arr.length + pct / 100 / arr.length) * 100);
          setUploadProgress(overall, `☁️ "${f.name}" — ${pct}%`);
        });

        files.unshift({
          id:           'f' + Date.now() + Math.random().toString(36).substr(2, 5),
          name:         customTitle || f.name,
          size:         f.size,
          type, subject,
          date:         new Date().toLocaleDateString(),
          mimeType:     f.type,
          // Cloudinary fields
          cloudinaryUrl:    result.secure_url,
          cloudinaryId:     result.public_id,
          cloudinaryType:   result.resource_type,
          cloudName:        getCldConfig().cloudName,
          storage:          'cloudinary',
          previewable:      true,
          dataURL:          null,
        });
        uploaded++;
        persistUserState();
        renderFiles();
        updateHomeStats();
      } catch (err) {
        setUploadProgress(null);
        showToast('❌ Upload failed: ' + err.message, 'error');
        return;
      }
    }
    setUploadProgress(100, '✅ All files uploaded to Cloudinary!');
    setTimeout(() => setUploadProgress(null), 2000);
    showToast(`☁️ ${uploaded} file(s) uploaded to Cloudinary!`, 'success');

  } else {
    // ── LOCAL DATAURL FALLBACK ───────────────────────────────────────────────
    let processed = 0;
    const total = arr.length;
    arr.forEach(f => {
      const reader = new FileReader();
      reader.onload = e => {
        const dataURL = f.size <= MAX_PREVIEW_BYTES ? e.target.result : null;
        files.unshift({
          id:       'f' + Date.now() + Math.random().toString(36).substr(2, 5),
          name:     f.name, size: f.size, type, subject,
          date:     new Date().toLocaleDateString(),
          mimeType: f.type, dataURL, storage: 'local',
          previewable: !!dataURL,
        });
        processed++;
        if (processed === total) {
          persistUserState(); renderFiles(); updateHomeStats();
          showToast(`✅ ${total} file(s) saved locally.`, 'success');
          if (arr.some(x => x.size > MAX_PREVIEW_BYTES))
            showToast('💡 Configure Cloudinary above to remove the 4 MB limit!', 'info');
        }
      };
      reader.readAsDataURL(f);
    });
  }
}

function getFileIcon(n){
  const e=n.split('.').pop().toLowerCase();
  const map={pdf:'📕',doc:'📘',docx:'📘',ppt:'📙',pptx:'📙',xls:'📗',xlsx:'📗',jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🖼️',webp:'🖼️',mp4:'🎬',avi:'🎬',mov:'🎬',mp3:'🎵',wav:'🎵',txt:'📝',py:'🐍',html:'🌐',css:'🎨',js:'💛'};
  return map[e]||'📄';
}
function fmtSize(b){if(b<1024)return b+'B';if(b<1048576)return(b/1024).toFixed(1)+'KB';return(b/1048576).toFixed(1)+'MB';}
function setFilter(f,el){activeFilter=f;document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));el.classList.add('active');renderFiles();}

function applyUploadPermissions(){
  const admin=isAdmin();
  document.getElementById('uploadControlsWrap').style.display=admin?'':'none';
  document.getElementById('viewOnlyBannerMat').style.display=admin?'none':'';
  if(admin){ updateCldUI(); document.getElementById('cldConfigPanel').style.display=''; }
  else { document.getElementById('cldConfigPanel').style.display='none'; }
}

function renderFiles(){
  const search=(document.getElementById('searchInput')?.value||'').toLowerCase();
  const filterSubj=(document.getElementById('filterSubjectDrop')?.value||'').toLowerCase();
  const filterType=(document.getElementById('filterTypeDrop')?.value||'');
  let list=files.filter(f=>{
    const mf=!filterType||f.type===filterType;
    const ms=!search||f.name.toLowerCase().includes(search)||(f.subject||'').toLowerCase().includes(search);
    const msubj=!filterSubj||(f.subject||'').toLowerCase()===filterSubj;
    return mf&&ms&&msubj;
  });
  const el=document.getElementById('filesList');
  if(!list.length){el.innerHTML=`<div class="empty-state" style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:60px 20px;"><div class="icon" style="font-size:3rem;margin-bottom:12px;">📄</div><p>No materials yet. Upload your first file above.</p></div>`;return;}
  const typeIcons={notes:'📄',lecture:'🎓',formula:'🔢',other:'📎'};
  const admin=isAdmin();
  el.innerHTML=list.map(f=>{
    const isCloud = f.storage === 'cloudinary' && f.cloudinaryUrl;
    const hasLocal = !!f.dataURL;
    const dlHref   = isCloud ? f.cloudinaryUrl : (hasLocal ? f.dataURL : null);
    const storageBadge = isCloud
      ? `<span class="cloud-badge">☁️ Cloud</span>`
      : `<span class="cloud-badge local">💾 Local</span>`;
    return `
    <div class="file-item">
      <div class="file-icon-lrg">${getFileIcon(f.name)}</div>
      <div class="file-info">
        <div class="fname">${f.name}${!f.previewable&&!isCloud?'<span title="File &gt;4MB — download only" style="font-size:.68rem;color:var(--warning);margin-left:5px">⚡No Preview</span>':''}</div>
        <div class="fmeta">📅 ${f.date} · 💾 ${fmtSize(f.size)} · 📚 ${f.subject}</div>
      </div>
      <span class="file-tag tag-${f.type}">${typeIcons[f.type]||'📎'} ${f.type.charAt(0).toUpperCase()+f.type.slice(1)}</span>
      ${storageBadge}
      <div class="file-actions">
        <button class="btn-icon view-btn" onclick="viewFile('${f.id}')" title="View / Play">👁️</button>
        ${dlHref?`<a class="btn-icon dl-btn" href="${dlHref}" ${isCloud?'target="_blank" rel="noopener"':'download="'+f.name+'"'} title="Download ${f.name}" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;">⬇️</a>`:''}
        ${admin?`<button class="btn-icon del-btn" onclick="deleteFile('${f.id}')" title="Delete">🗑️</button>`:''}
      </div>
    </div>`;
  }).join('');
}

function deleteFile(id){
  if(!isAdmin()){showToast('🔒 Only admin can delete','error');return;}
  const f = files.find(x=>x.id===id);
  if(f && f.storage === 'cloudinary'){
    // Note: Cloudinary deletion from browser requires a signed request (server-side).
    // We remove from the DB; the asset stays in Cloudinary but is no longer referenced.
    showToast('☁️ Removed from library (Cloudinary asset retained — delete via Cloudinary dashboard)', 'info');
  }
  files=files.filter(f=>f.id!==id);persistUserState();renderFiles();updateHomeStats();
  showToast('🗑️ File removed','error');
}

// ─── FILE VIEWER — supports both Cloudinary URLs and local DataURLs ───────────
function viewFile(id){
  const f=files.find(x=>x.id===id);
  if(!f)return;
  document.getElementById('viewerTitle').textContent=f.name;
  document.getElementById('viewerIcon').textContent=getFileIcon(f.name);
  const toolbar=document.getElementById('viewerToolbar');
  const body=document.getElementById('viewerBody');
  const dlBtn=document.getElementById('viewerDownload');
  toolbar.style.display='none';
  imgZoom=100;

  // Resolve the best src: Cloudinary URL > local dataURL > nothing
  const isCloud = f.storage === 'cloudinary' && f.cloudinaryUrl;
  const src     = isCloud ? f.cloudinaryUrl : f.dataURL;
  const dlHref  = isCloud ? f.cloudinaryUrl : f.dataURL;

  if(src){
    if(dlHref){ dlBtn.href=dlHref; if(!isCloud) dlBtn.download=f.name; else dlBtn.target='_blank'; } 
    dlBtn.style.opacity='1'; dlBtn.removeAttribute('title');
    const ext=f.name.split('.').pop().toLowerCase();
    if(['jpg','jpeg','png','gif','webp','svg'].includes(ext)){
      toolbar.style.display='flex';
      body.innerHTML=`<div class="img-wrap"><img id="viewerImg" src="${src}" alt="${f.name}" style="transform:scale(1);transform-origin:center center;transition:transform .2s;max-width:100%;max-height:68vh;border-radius:8px;" crossorigin="anonymous"></div>`;
    } else if(ext==='pdf'){
      if(isCloud){
        // Cloudinary raw PDF — open in iframe via Google Docs viewer for reliability
        body.innerHTML=`<iframe src="https://docs.google.com/viewer?url=${encodeURIComponent(src)}&embedded=true" width="100%" height="520" style="border:none;border-radius:8px;"></iframe>
          <p style="text-align:center;margin-top:10px;color:var(--muted);font-size:.82rem">Having trouble? <a href="${src}" target="_blank" style="color:var(--primary)">Open PDF directly ↗</a></p>`;
      } else {
        body.innerHTML=`<embed src="${src}" type="application/pdf" width="100%" height="520" style="border-radius:8px;">
          <p style="text-align:center;margin-top:12px;color:var(--muted);font-size:.85rem">If PDF doesn't load inline, use the Download button above.</p>`;
      }
    } else if(['mp4','webm','ogg','mov'].includes(ext)){
      body.innerHTML=`<video controls autoplay style="width:100%;border-radius:10px;max-height:68vh;" ${isCloud?'crossorigin="anonymous"':''}><source src="${src}" type="${f.mimeType||'video/mp4'}">Your browser doesn't support video.</video>`;
    } else if(['mp3','wav','ogg','m4a'].includes(ext)){
      body.innerHTML=`<div style="text-align:center;padding:40px 0"><div style="font-size:4rem;margin-bottom:16px">🎵</div><h3 style="margin-bottom:20px">${f.name}</h3><audio controls style="width:100%"><source src="${src}" type="${f.mimeType||'audio/mpeg'}">Your browser doesn't support audio.</audio></div>`;
    } else if(ext==='txt'||ext==='md'){
      if(isCloud){
        body.innerHTML=`<div style="text-align:center;padding:30px;color:var(--muted)">
          <div style="font-size:3rem;margin-bottom:12px">📝</div>
          <p style="margin-bottom:16px">Text file stored in Cloudinary.</p>
          <a href="${src}" target="_blank" rel="noopener" class="btn btn-primary" style="text-decoration:none;display:inline-flex">Open in new tab ↗</a>
        </div>`;
      } else {
        try{
          const b64=src.split(',')[1];
          const text=decodeURIComponent(escape(atob(b64)));
          body.innerHTML=`<pre>${text.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre>`;
        }catch{body.innerHTML=`<pre>Unable to decode text file.</pre>`;}
      }
    } else {
      body.innerHTML=`<div class="no-preview-box">
        <span class="np-icon">${getFileIcon(f.name)}</span>
        <h3 style="margin-bottom:8px">${f.name}</h3>
        <p style="color:var(--muted);margin-bottom:24px">In-app preview is not available for .${f.name.split('.').pop().toUpperCase()} files.</p>
        <a href="${dlHref}" ${isCloud?'target="_blank" rel="noopener"':'download="'+f.name+'"'} class="btn btn-primary" style="text-decoration:none;display:inline-flex">⬇️ ${isCloud?'Open in Cloud':'Download'} ${f.name}</a>
      </div>`;
    }
  } else {
    dlBtn.removeAttribute('href');dlBtn.removeAttribute('download');dlBtn.style.opacity='.4';dlBtn.title='No preview available';
    body.innerHTML=`<div class="no-preview-box">
      <span class="np-icon">📦</span>
      <h3 style="margin-bottom:8px">${f.name}</h3>
      <p style="color:var(--muted)">This file (${fmtSize(f.size)}) exceeds the 4 MB local limit and has no preview.<br>
      <strong style="color:#fbbf24">💡 Configure Cloudinary</strong> in the Materials page to enable unlimited cloud uploads and previews.</p>
    </div>`;
  }
  document.getElementById('viewerModal').classList.add('open');
}

let _zoomImgEl=null;
function zoomImg(delta){
  if(!delta){imgZoom=100;}
  else{imgZoom=Math.min(300,Math.max(25,imgZoom+delta));}
  const img=document.getElementById('viewerImg');
  if(img)img.style.transform=`scale(${imgZoom/100})`;
  document.getElementById('zoomVal').textContent=imgZoom+'%';
}
function closeViewer(){
  document.getElementById('viewerModal').classList.remove('open');
  document.getElementById('viewerBody').innerHTML='';
  document.getElementById('viewerToolbar').style.display='none';
}

// ═══════════════════════════ PYQ ═══════════════════════════


// ═══════════════════════════ PYQ ═══════════════════════════
const PYQ_SUBJECTS=[...new Set(PYQ_BANK.map(q=>q.subject))];
function buildPYQTabs(){
  document.getElementById('pyqSubjTabs').innerHTML=PYQ_SUBJECTS.map(s=>
    `<button class="pyq-tab${s===activePYQSubj?' active':''}" onclick="setPYQSubj('${s}',this)">${s}</button>`
  ).join('');
}
function setPYQSubj(s,el){
  activePYQSubj=s;
  document.querySelectorAll('.pyq-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  updatePYQChapterFilter();
  document.getElementById('pyqChapterFilter').value='';
  renderPYQ();
}
function renderPYQ(){
  const year=document.getElementById('pyqYearFilter').value;
  const diff=document.getElementById('pyqDiffFilter').value;
  const chapter=document.getElementById('pyqChapterFilter').value;
  let list=PYQ_BANK.filter(q=>q.subject===activePYQSubj);
  if(year)list=list.filter(q=>q.year===year);
  if(diff)list=list.filter(q=>q.difficulty===diff);
  if(chapter)list=list.filter(q=>q.chapter===chapter);
  const dc={easy:'diff-easy',medium:'diff-medium',hard:'diff-hard'};
  document.getElementById('pyqList').innerHTML=list.length?list.map((q,i)=>`
    <div class="pyq-card">
      <div class="pyq-top">
        <span class="tag tag-pyq">📜 CBSE ${q.year}</span>
        <span class="q-diff ${dc[q.difficulty]||''}">${q.difficulty.toUpperCase()}</span>
        ${q.chapter?`<span class="chapter-badge">📖 ${q.chapter}</span>`:''}
      </div>
      <div class="pyq-q">${q.question}</div>
      <div style="font-size:.82rem;color:var(--muted);margin-bottom:8px">${q.options.map((o,j)=>`<strong>${'ABCD'[j]})</strong> ${o}`).join('&nbsp; ')}</div>
      <button class="btn btn-secondary btn-sm" onclick="togglePYQAns('pa${q.id}',this)">👁 Show Answer</button>
      <div class="pyq-ans" id="pa${q.id}">✅ <strong>Correct: ${q.options[q.answer]}</strong><br><br>💡 ${q.explanation}</div>
    </div>`).join('')
  :`<div class="empty-state"><div class="icon">📜</div><p>No PYQ found for this filter.</p></div>`;
}
function togglePYQAns(id,btn){const el=document.getElementById(id);el.classList.toggle('show');btn.textContent=el.classList.contains('show')?'🙈 Hide Answer':'👁 Show Answer';}
function startPYQTest(){document.getElementById('includePYQ').checked=true;document.getElementById('includeCustom').checked=false;showPage('test');showToast('📜 PYQ mode enabled','info');}

// ═══════════════════════════ Q-EDITOR ═══════════════════════════


// ═══════════════════════════ Q-EDITOR ═══════════════════════════
function applyEditorPermissions(){
  const admin=isAdmin();
  document.getElementById('addQBtn').style.display=admin?'':'none';
  document.getElementById('aiGenBtn').style.display='';// all users can see AI gen banner
  document.getElementById('viewOnlyBannerEditor').style.display=admin?'none':'';
  document.getElementById('adminEditorBanner').style.display=admin?'':'none';
}
function renderQTable(){
  const search=(document.getElementById('qSearchInput')?.value||'').toLowerCase();
  const subj=document.getElementById('qSubjFilter').value;
  const chapter=document.getElementById('qChapterFilter').value;
  const diff=document.getElementById('qDiffFilter').value;
  let list=customQuestions.filter(q=>{
    return(!search||q.question.toLowerCase().includes(search)||(q.subject||'').toLowerCase().includes(search))
      &&(!subj||q.subject===subj)&&(!chapter||q.chapter===chapter)&&(!diff||q.difficulty===diff);
  });
  const dc={easy:'diff-easy',medium:'diff-medium',hard:'diff-hard'};
  const tbody=document.getElementById('qTableBody');
  const empty=document.getElementById('qTableEmpty');
  if(!list.length){tbody.innerHTML='';empty.style.display='';return;}
  empty.style.display='none';
  tbody.innerHTML=list.map((q,i)=>`
    <tr>
      <td>${i+1}</td>
      <td class="q-text" title="${q.question}">${q.question}</td>
      <td><span class="subject-tag" style="white-space:nowrap">${q.subject}</span></td>
      <td style="font-size:.77rem;color:#fb7185;white-space:nowrap">${q.chapter||'—'}</td>
      <td><span class="q-diff ${dc[q.difficulty]||''}">${q.difficulty}</span></td>
      <td style="font-size:.77rem;color:var(--success);max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${q.options[q.answer]}</td>
      <td>
        ${isAdmin()?`<button class="btn btn-warning btn-sm" onclick="openEditModal('${q.id}')" style="margin-right:4px">✏️</button>
                     <button class="btn btn-danger btn-sm" onclick="deleteQuestion('${q.id}')">🗑️</button>`
        :'<span style="color:var(--muted);font-size:.77rem">🔒 View only</span>'}
      </td>
    </tr>`).join('');
}
function openAddModal(){
  if(!isAdmin()){showToast('🔒 Only admin can add questions','error');return;}
  editingQId=null;
  document.getElementById('modalTitle').textContent='➕ Add Question';
  document.getElementById('editQId').value='';
  document.getElementById('qText').value='';
  document.getElementById('qSubject').value='Mathematics';
  updateModalChapter();
  document.getElementById('qDifficulty').value='medium';
  ['opt0','opt1','opt2','opt3'].forEach(id=>document.getElementById(id).value='');
  document.querySelectorAll('input[name="correctOpt"]').forEach(r=>r.checked=false);
  document.getElementById('qExplan').value='';
  document.getElementById('modalErr').textContent='';
  document.getElementById('qModal').classList.add('open');
}
function openEditModal(id){
  if(!isAdmin()){showToast('🔒 Only admin can edit','error');return;}
  const q=customQuestions.find(x=>x.id===id);if(!q)return;
  editingQId=id;
  document.getElementById('modalTitle').textContent='✏️ Edit Question';
  document.getElementById('editQId').value=id;
  document.getElementById('qText').value=q.question;
  document.getElementById('qSubject').value=q.subject;
  updateModalChapter(q.chapter||'');
  document.getElementById('qDifficulty').value=q.difficulty;
  q.options.forEach((o,i)=>document.getElementById('opt'+i).value=o);
  document.querySelectorAll('input[name="correctOpt"]').forEach(r=>r.checked=parseInt(r.value)===q.answer);
  document.getElementById('qExplan').value=q.explanation||'';
  document.getElementById('modalErr').textContent='';
  document.getElementById('qModal').classList.add('open');
}
function closeModal(){document.getElementById('qModal').classList.remove('open');}
function saveQuestion(){
  const text=document.getElementById('qText').value.trim();
  const subj=document.getElementById('qSubject').value;
  const chapter=document.getElementById('qChapter').value;
  const diff=document.getElementById('qDifficulty').value;
  const opts=['opt0','opt1','opt2','opt3'].map(id=>document.getElementById(id).value.trim());
  const correctRadio=document.querySelector('input[name="correctOpt"]:checked');
  const explan=document.getElementById('qExplan').value.trim();
  if(!text){document.getElementById('modalErr').textContent='❌ Question text required';return;}
  if(opts.some(o=>!o)){document.getElementById('modalErr').textContent='❌ All 4 options required';return;}
  if(!correctRadio){document.getElementById('modalErr').textContent='❌ Select the correct answer';return;}
  const answer=parseInt(correctRadio.value);
  if(editingQId){
    const idx=customQuestions.findIndex(q=>q.id===editingQId);
    if(idx!==-1)customQuestions[idx]={...customQuestions[idx],question:text,subject:subj,chapter,difficulty:diff,options:opts,answer,explanation:explan};
    showToast('✅ Question updated!','success');
  }else{
    customQuestions.push({id:'q'+Date.now(),subject:subj,chapter,difficulty:diff,question:text,options:opts,answer,explanation:explan,type:'custom'});
    showToast('✅ Question added!','success');
  }
  persistUserState();closeModal();renderQTable();updateHomeStats();
}
function deleteQuestion(id){
  if(!isAdmin()){showToast('🔒 Only admin can delete','error');return;}
  if(!confirm('Delete this question?'))return;
  customQuestions=customQuestions.filter(q=>q.id!==id);
  persistUserState();renderQTable();updateHomeStats();
  showToast('🗑️ Question deleted','error');
}

// ═══════════════════════════ GEMINI PRO AI GENERATOR ═══════════════════════════


// ═══════════════════════════ GEMINI PRO AI GENERATOR ═══════════════════════════
function openAIModal(){
  document.getElementById('aiModal').classList.add('open');
  resetAIPanel();
  updateAIChapters();
}
function closeAIModal(){document.getElementById('aiModal').classList.remove('open');}
function resetAIPanel(){
  document.getElementById('aiSetupPanel').style.display='';
  document.getElementById('aiGenerating').style.display='none';
  document.getElementById('aiPreviewPanel').style.display='none';
  generatedQuestions=[];
  // API key is hardcoded — no input needed
}
function saveGeminiKey(val){ /* key managed server-side */ }
function saveGeminiKeyBtn(){ showToast('API key is configured server-side','info'); }
async function generateAIQuestions(){
  const subj=document.getElementById('aiSubject').value;
  const chapter=document.getElementById('aiChapter').value;
  const diffPref=document.getElementById('aiDifficulty').value;
  const count=parseInt(document.getElementById('aiCount').value);


  // show loading
  document.getElementById('aiSetupPanel').style.display='none';
  document.getElementById('aiGenerating').style.display='';
  document.getElementById('aiPreviewPanel').style.display='none';

  const chapterLabel=chapter||'any chapter';
  const diffText=diffPref==='mixed'?'a mix of easy, medium, and hard':diffPref;
  const prompt=`You are a Class 10 CBSE exam expert. Generate exactly ${count} multiple-choice questions for the subject "${subj}", chapter "${chapterLabel}".
Difficulty: ${diffText}.
Return ONLY a valid JSON array (no markdown, no explanation, no backticks) in this exact format:
[
  {
    "question": "Question text here?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": 0,
    "difficulty": "easy",
    "explanation": "Brief explanation of the correct answer."
  }
]
Rules:
- "answer" is the 0-based index of the correct option (0=A, 1=B, 2=C, 3=D)
- All 4 options must be distinct and plausible
- Questions must be relevant to Class 10 CBSE syllabus for ${subj} — ${chapterLabel}
- Difficulty must be one of: easy, medium, hard
- Return ONLY the JSON array, nothing else`;

  try{
    const res=await fetch(GEMINI_URL,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.7,maxOutputTokens:4096}})
    });

    if(!res.ok){
      const err=await res.json().catch(()=>({}));
      const msg=(err.error&&err.error.message)||`HTTP ${res.status}`;
      throw new Error(msg);
    }

    const data=await res.json();
    const rawText=data?.candidates?.[0]?.content?.parts?.[0]?.text||'';
    // Strip possible markdown code fences
    const cleaned=rawText.replace(/```json[\s\S]*?```|```[\s\S]*?```/g,'').trim();
    // Extract JSON array
    const jsonMatch=cleaned.match(/\[[\s\S]*\]/);
    if(!jsonMatch)throw new Error('Gemini returned an unexpected format. Please try again.');

    const parsed=JSON.parse(jsonMatch[0]);
    if(!Array.isArray(parsed)||parsed.length===0)throw new Error('No questions returned. Try a different chapter.');

    generatedQuestions=parsed.map((q,i)=>({
      id:'ai_'+Date.now()+'_'+i,
      subject:subj,
      chapter:chapter||'General',
      difficulty:q.difficulty||'medium',
      question:q.question,
      options:q.options,
      answer:q.answer,
      explanation:q.explanation||'',
      type:'custom'
    }));

    document.getElementById('aiGenerating').style.display='none';
    document.getElementById('aiSetupPanel').style.display='';
    document.getElementById('aiPreviewPanel').style.display='';

    const chLabel=chapter?chapter:'All Chapters';
    document.getElementById('aiPreviewTitle').textContent=`${subj} — ${chLabel} (${generatedQuestions.length} questions)`;

    const dc={easy:'diff-easy',medium:'diff-medium',hard:'diff-hard'};
    const listEl=document.getElementById('aiPreviewList');
    document.getElementById('addAllBtn').textContent='➕ Add All to Bank';
    document.getElementById('addAllBtn').disabled=false;

    listEl.innerHTML=generatedQuestions.map((q,i)=>`
      <div class="gen-card" id="gencard_${i}">
        <div class="gen-card-header">
          <span class="ai-badge-pill">Gemini Pro</span>
          <span class="q-subject-badge">${q.subject}</span>
          <span class="chapter-badge">📖 ${q.chapter}</span>
          <span class="q-diff ${dc[q.difficulty]||''}">${q.difficulty}</span>
        </div>
        <div class="gc-q">${i+1}. ${q.question}
          <button class="btn btn-success btn-sm gc-add-btn" onclick="addGeneratedQuestion(${i})" id="gcbtn_${i}">➕</button>
        </div>
        <div class="gc-opts">${q.options.map((o,j)=>`<div class="gc-opt${j===q.answer?' correct-opt':''}">${'ABCD'[j]}) ${o}</div>`).join('')}</div>
        <div class="gc-expl">💡 ${q.explanation}</div>
      </div>`).join('');
    showToast(`✨ ${generatedQuestions.length} real questions from Gemini Pro!`,'ai');

  }catch(err){
    document.getElementById('aiGenerating').style.display='none';
    document.getElementById('aiSetupPanel').style.display='';
    showToast('❌ Gemini error: '+err.message,'error');
    console.error('Gemini API error:',err);
  }
}
function addGeneratedQuestion(idx){
  if(!isAdmin()){showToast('🔒 Only admin can add questions','error');return;}
  const q=generatedQuestions[idx];if(!q)return;
  if(customQuestions.find(x=>x.question===q.question)){showToast('⚠️ Already in bank','info');return;}
  customQuestions.push({...q,id:'q'+Date.now()+'_'+idx});
  persistUserState();updateHomeStats();renderQTable();
  const btn=document.getElementById('gcbtn_'+idx);
  if(btn){btn.textContent='✅';btn.disabled=true;btn.style.background='var(--success)';}
  showToast('✅ Added to question bank!','success');
}
function addAllGenerated(){
  if(!isAdmin()){showToast('🔒 Only admin can add questions','error');return;}
  let added=0;
  generatedQuestions.forEach((q,i)=>{
    if(!customQuestions.find(x=>x.question===q.question)){
      customQuestions.push({...q,id:'q'+Date.now()+'_all_'+i});added++;
    }
  });
  persistUserState();updateHomeStats();renderQTable();
  generatedQuestions.forEach((_,i)=>{
    const btn=document.getElementById('gcbtn_'+i);
    if(btn){btn.textContent='✅';btn.disabled=true;btn.style.background='var(--success)';}
  });
  const allBtn=document.getElementById('addAllBtn');
  allBtn.textContent='✅ All Added';allBtn.disabled=true;
  showToast(`✅ ${added} question(s) added!`,'success');
}

// ═══════════════════════════ MOCK TEST ═══════════════════════════


// ═══════════════════════════ MOCK TEST ═══════════════════════════
const ALL_SUBJECTS=['Mathematics','Science','English','Social Studies','Hindi','Computer Science'];
function buildSubjCheckboxes(){
  document.getElementById('subjCheckboxes').innerHTML=ALL_SUBJECTS.map(s=>
    `<label class="subj-checkbox"><input type="checkbox" value="${s}" ${['Mathematics','Science'].includes(s)?'checked':''} onchange="updateTestChapterFilter()"><span>${s}</span></label>`
  ).join('');
}
function startTest(){
  const subjects=[...document.querySelectorAll('#subjCheckboxes input:checked')].map(c=>c.value);
  if(!subjects.length){showToast('⚠️ Select at least one subject!','error');return;}
  const diff=document.getElementById('difficultySelect').value;
  const qCount=parseInt(document.getElementById('qCountSelect').value);
  const chapter=document.getElementById('testChapterFilter').value;
  timeLeft=parseInt(document.getElementById('timeSelect').value);
  const incPYQ=document.getElementById('includePYQ').checked;
  const incCustom=document.getElementById('includeCustom').checked;
  if(!incPYQ&&!incCustom){showToast('⚠️ Select a question source!','error');return;}
  let pool=[];
  if(incCustom)pool.push(...customQuestions.filter(q=>subjects.includes(q.subject)));
  if(incPYQ)pool.push(...PYQ_BANK.filter(q=>subjects.includes(q.subject)));
  if(diff!=='mixed')pool=pool.filter(q=>q.difficulty===diff);
  if(chapter)pool=pool.filter(q=>q.chapter===chapter);
  if(!pool.length){showToast('⚠️ No questions for this selection!','error');return;}
  currentQuestions=shuffle(pool).slice(0,Math.min(qCount,pool.length));
  userAnswers=new Array(currentQuestions.length).fill(null);
  currentQ=0;testStartTime=Date.now();
  document.getElementById('testSetup').style.display='none';
  document.getElementById('quizContainer').style.display='block';
  document.getElementById('resultsContainer').style.display='none';
  const subLabel=subjects.slice(0,2).join(', ')+(subjects.length>2?'…':'');
  document.getElementById('quizTitle').textContent=`📝 ${subLabel}${chapter?' · '+chapter:''} Mock Test`;
  renderQuestion();renderDots();
  if(timeLeft>0)startTimer();
  else document.getElementById('timerDisplay').textContent='⏱ No Limit';
}
function shuffle(arr){return[...arr].sort(()=>Math.random()-.5);}
function renderQuestion(){
  const q=currentQuestions[currentQ];
  const ua=userAnswers[currentQ];
  const answered=ua!==null;
  const pct=((currentQ+1)/currentQuestions.length)*100;
  document.getElementById('progressFill').style.width=pct+'%';
  document.getElementById('progressLabel').textContent=`Question ${currentQ+1} of ${currentQuestions.length}`;
  const dc={easy:'diff-easy',medium:'diff-medium',hard:'diff-hard'}[q.difficulty]||'';
  const pyqBadge=q.type==='pyq'?`<span class="q-year">📜 CBSE ${q.year}</span>`:`<span class="tag tag-custom">⚙️ Custom</span>`;
  const chBadge=q.chapter?`<span class="q-chapter-badge">📖 ${q.chapter}</span>`:'';
  document.getElementById('questionArea').innerHTML=`
    <div class="question-card">
      <div class="q-number">Q${currentQ+1} <span class="q-subject-badge">${q.subject}</span>${chBadge}<span class="q-diff ${dc}">${q.difficulty.toUpperCase()}</span>${pyqBadge}</div>
      <div class="question-text">${q.question}</div>
      <div class="options">
        ${q.options.map((opt,i)=>{
          let cls='';
          if(answered){if(i===q.answer)cls='correct';else if(i===ua)cls='wrong';cls+=' disabled';}
          return`<div class="option ${cls}" onclick="selectAnswer(${i})"><span class="option-letter">${'ABCD'[i]}</span>${opt}</div>`;
        }).join('')}
      </div>
      <div class="explanation${answered?' show':''}" id="expl">💡 <strong>Explanation:</strong> ${q.explanation||'—'}</div>
    </div>`;
  document.getElementById('prevBtn').style.display=currentQ===0?'none':'';
  const isLast=currentQ===currentQuestions.length-1;
  document.getElementById('nextBtn').style.display=isLast?'none':'';
  document.getElementById('submitBtn').style.display=isLast?'':'none';
}
function selectAnswer(idx){if(userAnswers[currentQ]!==null)return;userAnswers[currentQ]=idx;renderQuestion();renderDots();}
function nextQuestion(){if(currentQ<currentQuestions.length-1){currentQ++;renderQuestion();renderDots();}}
function prevQuestion(){if(currentQ>0){currentQ--;renderQuestion();renderDots();}}
function renderDots(){
  document.getElementById('qDots').innerHTML=currentQuestions.map((q,i)=>{
    let cls='';
    if(i===currentQ)cls='current';
    else if(userAnswers[i]!==null)cls=userAnswers[i]===q.answer?'correct-dot':'wrong-dot';
    return`<div class="q-dot ${cls}" onclick="goTo(${i})" title="Q${i+1}"></div>`;
  }).join('');
}
function goTo(i){currentQ=i;renderQuestion();renderDots();}
function startTimer(){
  const el=document.getElementById('timerDisplay');
  timerInterval=setInterval(()=>{
    timeLeft--;
    const m=Math.floor(timeLeft/60),s=timeLeft%60;
    el.textContent=`⏱ ${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    if(timeLeft<=30)el.classList.add('urgent');
    if(timeLeft<=0){clearInterval(timerInterval);submitTest();}
  },1000);
}
function submitTest(){
  clearInterval(timerInterval);
  const timeTaken=Math.round((Date.now()-testStartTime)/1000);
  let correct=0,wrong=0,skipped=0;
  currentQuestions.forEach((q,i)=>{
    if(userAnswers[i]===null)skipped++;
    else if(userAnswers[i]===q.answer)correct++;
    else wrong++;
  });
  const total=currentQuestions.length,pct=Math.round((correct/total)*100);
  const subjects=[...new Set(currentQuestions.map(q=>q.subject))];
  const record={id:'h'+Date.now(),date:new Date().toLocaleString(),pct,correct,wrong,skipped,total,timeTaken,subjects,
    answers:userAnswers.map((a,i)=>({q:currentQuestions[i].question,ch:currentQuestions[i].chapter||'',ua:a,correct:currentQuestions[i].answer,opts:currentQuestions[i].options,expl:currentQuestions[i].explanation||''}))};
  testHistory.unshift(record);persistUserState();updateHomeStats();
  showResults(correct,wrong,skipped,total,pct,timeTaken);
}
function showResults(correct,wrong,skipped,total,pct,timeTaken){
  document.getElementById('quizContainer').style.display='none';
  document.getElementById('resultsContainer').style.display='block';
  document.getElementById('scorePct').textContent=pct+'%';
  const circ=377;
  setTimeout(()=>{document.getElementById('scoreCircle').style.strokeDashoffset=circ-(pct/100)*circ;},100);
  let grade,msg,color;
  if(pct>=90){grade='🏆 A+ Outstanding!';msg='Exceptional! Fully exam-ready.';color='#22c55e';}
  else if(pct>=75){grade='🥇 A Great Job!';msg='Excellent! Review missed questions.';color='#6c63ff';}
  else if(pct>=60){grade='🥈 B Good Effort';msg='Decent score. Focus on weak areas.';color='#f59e0b';}
  else if(pct>=40){grade='🥉 C Keep Practicing';msg='More practice needed.';color='#f97316';}
  else{grade='📚 D Study More';msg="Don't give up! Revise and retry.";color='#ef4444';}
  document.getElementById('resultGrade').textContent=grade;
  document.getElementById('resultGrade').style.color=color;
  document.getElementById('resultMsg').textContent=msg;
  const m=Math.floor(timeTaken/60),s=timeTaken%60;
  document.getElementById('resultStats').innerHTML=`
    <div class="result-stat"><div class="v" style="color:var(--success)">${correct}</div><div class="l">✅ Correct</div></div>
    <div class="result-stat"><div class="v" style="color:var(--danger)">${wrong}</div><div class="l">❌ Wrong</div></div>
    <div class="result-stat"><div class="v" style="color:var(--muted)">${skipped}</div><div class="l">⏭ Skipped</div></div>
    <div class="result-stat"><div class="v">${total}</div><div class="l">📋 Total</div></div>
    <div class="result-stat"><div class="v">${m}:${String(s).padStart(2,'0')}</div><div class="l">⏱ Time</div></div>`;
  document.getElementById('reviewList').innerHTML=currentQuestions.map((q,i)=>{
    const ua=userAnswers[i],ok=ua===q.answer,skip=ua===null;
    return`<div class="review-item">
      <div style="font-size:.88rem;font-weight:600;margin-bottom:5px">${ok?'✅':skip?'⏭':'❌'} Q${i+1}: ${q.question}</div>
      ${q.chapter?`<div style="font-size:.74rem;color:#fb7185;margin-bottom:5px">📖 ${q.chapter}</div>`:''}
      <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:.84rem">
        <span style="color:var(--success)">✅ ${q.options[q.answer]}</span>
        ${!ok&&!skip?`<span style="color:var(--danger)">❌ ${q.options[ua]}</span>`:''}
        ${skip?'<span style="color:var(--muted)">⏭ Skipped</span>':''}
      </div>
      ${q.explanation?`<div style="font-size:.8rem;color:#a78bfa;margin-top:5px">💡 ${q.explanation}</div>`:''}
    </div>`;
  }).join('');
}
function retakeTest(){
  currentQ=0;userAnswers=new Array(currentQuestions.length).fill(null);
  testStartTime=Date.now();clearInterval(timerInterval);
  timeLeft=parseInt(document.getElementById('timeSelect').value);
  document.getElementById('resultsContainer').style.display='none';
  document.getElementById('quizContainer').style.display='block';
  renderQuestion();renderDots();
  if(timeLeft>0)startTimer();
}
function resetTest(){
  clearInterval(timerInterval);
  document.getElementById('testSetup').style.display='';
  document.getElementById('quizContainer').style.display='none';
  document.getElementById('resultsContainer').style.display='none';
}

// ═══════════════════════════ HISTORY ═══════════════════════════


// ═══════════════════════════ HISTORY ═══════════════════════════
function renderHistory(){
  const list=testHistory;
  const el=document.getElementById('historyList');
  const empty=document.getElementById('historyEmpty');
  if(!list.length){el.innerHTML='';empty.style.display='';document.getElementById('histStats').innerHTML='';return;}
  empty.style.display='none';
  const avg=Math.round(list.reduce((a,t)=>a+t.pct,0)/list.length);
  const best=Math.max(...list.map(t=>t.pct));
  const totalQ=list.reduce((a,t)=>a+t.total,0);
  const totalC=list.reduce((a,t)=>a+t.correct,0);
  document.getElementById('histStats').innerHTML=`
    <div class="stat-box"><div class="sv">${list.length}</div><div class="sl">Tests Taken</div></div>
    <div class="stat-box"><div class="sv" style="color:var(--success)">${best}%</div><div class="sl">Best Score</div></div>
    <div class="stat-box"><div class="sv" style="color:var(--warning)">${avg}%</div><div class="sl">Avg Score</div></div>
    <div class="stat-box"><div class="sv">${totalQ}</div><div class="sl">Qs Attempted</div></div>
    <div class="stat-box"><div class="sv" style="color:var(--info)">${totalQ?Math.round(totalC/totalQ*100):0}%</div><div class="sl">Accuracy</div></div>`;
  const gc=p=>p>=90?'#22c55e':p>=75?'#6c63ff':p>=60?'#f59e0b':p>=40?'#f97316':'#ef4444';
  const gg=p=>p>=90?'A+':p>=75?'A':p>=60?'B':p>=40?'C':'D';
  el.innerHTML=list.map((t,i)=>{
    const m=Math.floor(t.timeTaken/60),s=t.timeTaken%60;
    return`<div class="history-item" onclick="showHistDetail(${i})">
      <div class="hi-score" style="color:${gc(t.pct)}">${t.pct}%</div>
      <div class="hi-info">
        <div class="hi-title">📝 ${t.subjects?.join(', ')||'Mock Test'}</div>
        <div class="hi-meta">📅 ${t.date} · ✅ ${t.correct}/${t.total} · ⏱ ${m}:${String(s).padStart(2,'0')}</div>
      </div>
      <span class="hi-badge" style="background:${gc(t.pct)}22;color:${gc(t.pct)}">${gg(t.pct)}</span>
      <button class="btn btn-danger btn-sm" onclick="event.stopPropagation();deleteHistory('${t.id}')">🗑️</button>
    </div>`;
  }).join('');
}
function showHistDetail(idx){
  const t=testHistory[idx];if(!t)return;
  const m=Math.floor(t.timeTaken/60),s=t.timeTaken%60;
  document.getElementById('histModalContent').innerHTML=`
    <div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:16px">
      <div><strong style="font-size:2rem;color:${t.pct>=75?'#22c55e':t.pct>=40?'#f59e0b':'#ef4444'}">${t.pct}%</strong></div>
      <div style="font-size:.88rem;color:var(--muted)">📅 ${t.date}<br>✅ ${t.correct} · ❌ ${t.wrong} · ⏭ ${t.skipped}<br>⏱ ${m}:${String(s).padStart(2,'0')} · 📋 ${t.total} questions</div>
    </div>
    <hr class="divider">
    ${(t.answers||[]).map((a,i)=>{
      const ok=a.ua===a.correct,skip=a.ua===null;
      return`<div style="margin-bottom:10px;padding:10px;background:var(--surface2);border-radius:8px">
        <div style="font-size:.87rem;font-weight:600;margin-bottom:4px">${ok?'✅':skip?'⏭':'❌'} Q${i+1}: ${a.q}</div>
        ${a.ch?`<div style="font-size:.74rem;color:#fb7185;margin-bottom:4px">📖 ${a.ch}</div>`:''}
        <div style="font-size:.82rem"><span style="color:var(--success)">✅ ${a.opts[a.correct]}</span>
        ${!ok&&!skip?`<span style="color:var(--danger);margin-left:10px">❌ ${a.opts[a.ua]}</span>`:''}
        </div>${a.expl?`<div style="font-size:.78rem;color:#a78bfa;margin-top:4px">💡 ${a.expl}</div>`:''}
      </div>`;
    }).join('')}`;
  document.getElementById('histModal').classList.add('open');
}
function closeHistModal(){document.getElementById('histModal').classList.remove('open');}
function deleteHistory(id){
  if(!confirm('Delete this record?'))return;
  testHistory=testHistory.filter(t=>t.id!==id);persistUserState();renderHistory();
  showToast('🗑️ Record deleted','error');
}

// ═══════════════════════════ TOAST ═══════════════════════════
function showToast(msg,type='success'){
  const t=document.createElement('div');
  t.className=`toast ${type}`;t.textContent=msg;
  document.getElementById('toastContainer').appendChild(t);
  setTimeout(()=>t.remove(),3200);
}

// ═══════════════════════════ DASHBOARD ═══════════════════════════


// ═══════════════════════════ DASHBOARD ═══════════════════════════
function renderDashboard(){
  const h=testHistory;
  // Update hello name
  const dashHello=document.getElementById('dashHelloName');
  if(dashHello&&currentUser) dashHello.textContent=(currentUser.name||'').toUpperCase();
  // ── Top stats ──
  const totalTests=h.length;
  const avgScore=totalTests?Math.round(h.reduce((a,t)=>a+t.pct,0)/totalTests):0;
  const bestScore=totalTests?Math.max(...h.map(t=>t.pct)):0;
  const totalQs=h.reduce((a,t)=>a+(t.total||0),0);
  const totalCorrect=h.reduce((a,t)=>a+(t.correct||0),0);
  const accuracy=totalQs?Math.round(totalCorrect/totalQs*100):0;
  const streak=calcStreak();
  document.getElementById('dashStats').innerHTML=`
    <div class="dash-stat"><div class="ds-icon">✏️</div><div class="ds-val" style="color:var(--primary)">${totalTests}</div><div class="ds-lbl">Tests Taken</div></div>
    <div class="dash-stat"><div class="ds-icon">📊</div><div class="ds-val" style="color:var(--info)">${avgScore}%</div><div class="ds-lbl">Avg Score</div></div>
    <div class="dash-stat"><div class="ds-icon">🏆</div><div class="ds-val" style="color:var(--success)">${bestScore}%</div><div class="ds-lbl">Best Score</div></div>
    <div class="dash-stat"><div class="ds-icon">🎯</div><div class="ds-val" style="color:var(--warning)">${accuracy}%</div><div class="ds-lbl">Accuracy</div></div>
    <div class="dash-stat"><div class="ds-icon">🔥</div><div class="ds-val" style="color:#f97316">${streak}</div><div class="ds-lbl">Day Streak</div></div>
    <div class="dash-stat"><div class="ds-icon">📋</div><div class="ds-val">${totalQs}</div><div class="ds-lbl">Qs Attempted</div></div>`;

  // ── Score trend (last 8) ──
  const last8=h.slice(0,8).reverse();
  if(last8.length){
    const max=Math.max(...last8.map(t=>t.pct),1);
    const bars=last8.map(t=>{
      const ht=Math.round((t.pct/100)*60)+8;
      const col=t.pct>=75?'var(--success)':t.pct>=50?'var(--warning)':'var(--danger)';
      const label=t.date.split(',')[0];
      return`<div class="trend-bar" style="height:${ht}px;background:${col};opacity:.85" data-tip="${t.pct}% · ${label}"></div>`;
    }).join('');
    const labels=last8.map((_,i)=>`<div style="flex:1;text-align:center;font-size:.65rem;color:var(--muted)">T${i+1}</div>`).join('');
    document.getElementById('dashTrend').innerHTML=`
      <div class="perf-trend">${bars}</div>
      <div style="display:flex;margin-top:3px">${labels}</div>
      <div style="font-size:.76rem;color:var(--muted);margin-top:8px">Hover a bar to see score · newest on right</div>`;
  } else {
    document.getElementById('dashTrend').innerHTML='<div class="dash-empty">No tests taken yet</div>';
  }

  // ── Subject performance bars ──
  const subjMap={};
  h.forEach(t=>{
    (t.subjects||[]).forEach(s=>{
      if(!subjMap[s])subjMap[s]={total:0,correct:0,count:0};
      subjMap[s].total+=t.total||0;
      subjMap[s].correct+=t.correct||0;
      subjMap[s].count++;
    });
    // also scan individual answer-level data for per-subject correct
  });
  // enrich using answer-level data if available
  h.forEach(t=>{
    if(t.answers){
      // rebuild per-subject correct from answer records if subjects were mixed
    }
  });
  const subjEntries=Object.entries(subjMap).sort((a,b)=>{
    const pa=a[1].total?Math.round(a[1].correct/a[1].total*100):0;
    const pb=b[1].total?Math.round(b[1].correct/b[1].total*100):0;
    return pb-pa;
  });
  if(subjEntries.length){
    document.getElementById('dashSubjBars').innerHTML=subjEntries.map(([subj,d])=>{
      const pct=d.total?Math.round(d.correct/d.total*100):0;
      const col=pct>=75?'#22c55e':pct>=50?'#f59e0b':'#ef4444';
      const short=subj.length>14?subj.slice(0,13)+'…':subj;
      return`<div class="subj-bar-row">
        <div class="subj-bar-label"><span class="sbl-name">${short}</span><span class="sbl-pct">${pct}% (${d.count} test${d.count>1?'s':''})</span></div>
        <div class="subj-bar-track"><div class="subj-bar-fill" style="width:${pct}%;background:${col}"></div></div>
      </div>`;
    }).join('');
  } else {
    document.getElementById('dashSubjBars').innerHTML='<div class="dash-empty">No tests taken yet</div>';
  }

  // ── Weak chapters (from answer-level data) ──
  const chMap={};
  h.forEach(t=>{
    if(!t.answers)return;
    t.answers.forEach(a=>{
      const key=a.ch||'Unknown';
      if(!chMap[key])chMap[key]={correct:0,total:0};
      chMap[key].total++;
      if(a.ua===a.correct)chMap[key].correct++;
    });
  });
  const weakChapters=Object.entries(chMap)
    .filter(([_,d])=>d.total>=2)
    .map(([ch,d])=>({ch,pct:Math.round(d.correct/d.total*100),total:d.total}))
    .sort((a,b)=>a.pct-b.pct)
    .slice(0,6);
  if(document.getElementById('dashWeak')) {
  if(weakChapters.length){
    document.getElementById('dashWeak').innerHTML='<div class="weak-list">'+weakChapters.map(w=>{
      const cls=w.pct<40?'acc-bad':w.pct<60?'acc-mid':'acc-ok';
      const short=w.ch.length>22?w.ch.slice(0,21)+'…':w.ch;
      return`<div class="weak-item">
        <span style="font-size:1rem">${w.pct<40?'🔴':w.pct<60?'🟡':'🟢'}</span>
        <span class="wi-chapter">${short}</span>
        <span class="wi-acc ${cls}">${w.pct}%</span>
        <span style="font-size:.72rem;color:var(--muted)">${w.total}q</span>
      </div>`;
    }).join('')+'</div>';
  } else {
    document.getElementById('dashWeak').innerHTML='<div class="dash-empty">Take tests to discover weak chapters</div>';
  }
  }

  // ── Recent activity ──
  const acts=h.slice(0,8).map(t=>{
    const dot=t.pct>=75?'ai-dot-green':t.pct>=50?'ai-dot-yellow':'ai-dot-red';
    const subj=(t.subjects||[]).join(', ')||'Mixed';
    const short=subj.length>22?subj.slice(0,21)+'…':subj;
    const d=t.date.split(',')[0];
    return`<div class="activity-item"><div class="ai-dot ${dot}"></div><div style="flex:1"><strong>${short}</strong> — ${t.pct}%</div><div style="color:var(--muted);font-size:.74rem">${d}</div></div>`;
  });
  if(document.getElementById('dashActivity')) {
  document.getElementById('dashActivity').innerHTML=acts.length
    ?`<div class="activity-list">${acts.join('')}</div>`
    :'<div class="dash-empty">No activity yet</div>';
  }

  // ── Streak calendar ──
  renderStreakCalendar();

  // ── Badges ──
  renderBadges(totalTests,bestScore,avgScore,streak,accuracy,weakChapters);
}

function calcStreak(){
  if(!testHistory.length)return 0;
  const days=new Set(testHistory.map(t=>{
    const d=new Date(t.date);
    return isNaN(d)?null:d.toDateString();
  }).filter(Boolean));
  let streak=0,cur=new Date();
  for(let i=0;i<60;i++){
    if(days.has(cur.toDateString()))streak++;
    else if(i>0)break;
    cur.setDate(cur.getDate()-1);
  }
  return streak;
}

function renderStreakCalendar(){
  const days=new Set(testHistory.map(t=>{
    const d=new Date(t.date);
    return isNaN(d)?null:d.toDateString();
  }).filter(Boolean));
  const today=new Date();
  const labels=['S','M','T','W','T','F','S'];
  let html='<div class="streak-row">';
  for(let i=13;i>=0;i--){
    const d=new Date(today);
    d.setDate(d.getDate()-i);
    const isToday=i===0;
    const active=days.has(d.toDateString());
    const dow=d.getDay();
    const cls=active?'active':isToday?'today':'';
    html+=`<div class="streak-day ${cls}" title="${d.toDateString()}">${labels[dow]}</div>`;
  }
  html+='</div>';
  document.getElementById('dashStreak').innerHTML=html;
  const s=calcStreak();
  document.getElementById('dashStreakLabel').textContent=
    s>0?`🔥 ${s}-day active streak! Keep it up!`:'No active streak — take a test today!';
}

function renderBadges(tests,best,avg,streak,accuracy,weak){
  const earned=[];
  if(tests>=1)earned.push({icon:'🎯',label:'First Test',cls:'badge-blue'});
  if(tests>=5)earned.push({icon:'📚',label:'5 Tests Done',cls:'badge-blue'});
  if(tests>=10)earned.push({icon:'🏋️',label:'10 Tests Done',cls:'badge-purple'});
  if(best>=90)earned.push({icon:'🏆',label:'90%+ Scorer',cls:'badge-gold'});
  if(best>=75)earned.push({icon:'🥇',label:'75%+ Score',cls:'badge-gold'});
  if(avg>=70)earned.push({icon:'📈',label:'Consistent Performer',cls:'badge-purple'});
  if(streak>=3)earned.push({icon:'🔥',label:`${streak}-Day Streak`,cls:'badge-gold'});
  if(accuracy>=80)earned.push({icon:'🎯',label:'Sharp Shooter',cls:'badge-gold'});
  if(tests>0&&weak.filter(w=>w.pct<40).length===0)earned.push({icon:'💪',label:'No Red Zones',cls:'badge-blue'});
  const locked=[
    {icon:'🌟',label:'Score 100%',cls:'badge-silver'},
    {icon:'📅',label:'7-Day Streak',cls:'badge-silver'},
    {icon:'🚀',label:'20 Tests',cls:'badge-silver'},
  ].filter(b=>!earned.find(e=>e.label===b.label));
  let html='';
  if(earned.length){
    html+=earned.map(b=>`<span class="dash-badge ${b.cls}">${b.icon} ${b.label}</span>`).join('');
  }
  if(locked.length){
    html+='<div style="font-size:.74rem;color:var(--muted);margin:10px 0 5px">🔒 Locked:</div>';
    html+=locked.map(b=>`<span class="dash-badge badge-silver" style="opacity:.4">${b.icon} ${b.label}</span>`).join('');
  }
  document.getElementById('dashBadges').innerHTML=html||'<div class="dash-empty">Take tests to earn badges!</div>';
}

// ═══════════════════════════ MODAL CLOSE ON OVERLAY ═══════════════════════════
['qModal','histModal','aiModal','viewerModal','addStudentModal'].forEach(id=>{
  document.getElementById(id).addEventListener('click',e=>{
    if(e.target===e.currentTarget){
      if(id==='viewerModal')closeViewer();
      else if(id==='aiModal')closeAIModal();
      else if(id==='histModal')closeHistModal();
      else if(id==='addStudentModal')closeAddStudentModal();
      else closeModal();
    }
  });
});

// ═══════════════════════════ ADMIN LOG ═══════════════════════════


// ═══════════════════════════ ADMIN LOG ═══════════════════════════
function getAdminLog(){return ls('sh_admin_log',[]);}
function saveAdminLog(log){lsSet('sh_admin_log',log);}
function addAdminLog(type,msg){
  const log=getAdminLog();
  log.unshift({type,msg,time:new Date().toLocaleString()});
  if(log.length>200)log.length=200;
  saveAdminLog(log);
}
function clearAdminLog(){
  if(!confirm('Clear all activity logs?'))return;
  saveAdminLog([]);
  renderAdminLogs();
  showToast('🗑️ Log cleared','info');
}

// ═══════════════════════════ ADMIN PANEL ═══════════════════════════
function admTab(id,el){
  document.querySelectorAll('.adm-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.adm-tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('adm-'+id)?.classList.add('active');
  el.classList.add('active');
  if(id==='overview')renderAdmOverview();
  if(id==='students')renderStudentsTable();
  if(id==='uploads')renderAdmUploads();
  if(id==='questions')renderAdmQTable();
  if(id==='logs')renderAdminLogs();
  if(id==='payments')renderAdminPayments();
  if(id==='settings')renderAdmSettings();
}

function renderAdminPanel(){
  renderAdmOverview();
}

function getAllStudentsData(){
  const users=getUsers().filter(u=>u.role!=='admin');
  return users.map(u=>{
    const d=getUserData(u.username);
    const h=d.history||[];
    const avg=h.length?Math.round(h.reduce((a,t)=>a+t.pct,0)/h.length):0;
    const best=h.length?Math.max(...h.map(t=>t.pct)):0;
    return{...u,tests:h.length,avg,best,history:h};
  });
}

function renderAdmOverview(){
  const users=getUsers();
  const students=users.filter(u=>u.role!=='admin');
  const allData=getAllStudentsData();
  const totalTests=allData.reduce((a,s)=>a+s.tests,0);
  const activeToday=allData.filter(s=>s.history.some(t=>{
    const d=new Date(t.date);return!isNaN(d)&&d.toDateString()===new Date().toDateString();
  })).length;
  const overallAvg=allData.filter(s=>s.tests>0).length
    ?Math.round(allData.filter(s=>s.tests>0).reduce((a,s)=>a+s.avg,0)/allData.filter(s=>s.tests>0).length):0;

  document.getElementById('admKpis').innerHTML=`
    <div class="adm-kpi"><div class="kv" style="color:var(--primary)">${students.length}</div><div class="kl">Total Students</div></div>
    <div class="adm-kpi"><div class="kv" style="color:var(--success)">${activeToday}</div><div class="kl">Active Today</div></div>
    <div class="adm-kpi"><div class="kv" style="color:var(--warning)">${totalTests}</div><div class="kl">Tests Completed</div></div>
    <div class="adm-kpi"><div class="kv" style="color:var(--info)">${overallAvg}%</div><div class="kl">Overall Avg</div></div>
    <div class="adm-kpi"><div class="kv">${files.length}</div><div class="kl">Uploaded Files</div></div>
    <div class="adm-kpi"><div class="kv" style="color:var(--ai)">${customQuestions.length}</div><div class="kl">Questions</div></div>`;

  // Top performers
  const top=allData.filter(s=>s.tests>0).sort((a,b)=>b.avg-a.avg).slice(0,5);
  document.getElementById('admTopPerformers').innerHTML=top.length
    ?top.map((s,i)=>`
      <div class="weak-item">
        <span style="font-size:1rem">${['🥇','🥈','🥉','4️⃣','5️⃣'][i]}</span>
        <span class="wi-chapter">${s.name} <span style="font-size:.74rem;color:var(--muted)">(${s.classSection})</span></span>
        <span class="wi-acc acc-ok">${s.avg}%</span>
        <span style="font-size:.72rem;color:var(--muted)">${s.tests}t</span>
      </div>`).join('')
    :'<div class="dash-empty">No test data yet</div>';

  // Needs help
  const weak=allData.filter(s=>s.tests>0&&s.avg<50).sort((a,b)=>a.avg-b.avg).slice(0,5);
  document.getElementById('admNeedHelp').innerHTML=weak.length
    ?weak.map(s=>`
      <div class="weak-item">
        <span style="font-size:1rem">⚠️</span>
        <span class="wi-chapter">${s.name} <span style="font-size:.74rem;color:var(--muted)">(${s.classSection})</span></span>
        <span class="wi-acc acc-bad">${s.avg}%</span>
        <span style="font-size:.72rem;color:var(--muted)">${s.tests}t</span>
      </div>`).join('')
    :'<div class="dash-empty">All students performing well!</div>';

  // Subject averages
  const subjTotals={};
  allData.forEach(s=>s.history.forEach(t=>(t.subjects||[]).forEach(sub=>{
    if(!subjTotals[sub])subjTotals[sub]={sum:0,cnt:0};
    subjTotals[sub].sum+=t.pct;subjTotals[sub].cnt++;
  })));
  const subjEntries=Object.entries(subjTotals).sort((a,b)=>b[1].sum/b[1].cnt-a[1].sum/a[1].cnt);
  document.getElementById('admSubjAvg').innerHTML=subjEntries.length
    ?subjEntries.map(([sub,d])=>{
      const avg=Math.round(d.sum/d.cnt);
      const col=avg>=75?'#22c55e':avg>=50?'#f59e0b':'#ef4444';
      return`<div class="subj-bar-row">
        <div class="subj-bar-label"><span class="sbl-name">${sub}</span><span class="sbl-pct">${avg}% avg · ${d.cnt} test${d.cnt>1?'s':''}</span></div>
        <div class="subj-bar-track"><div class="subj-bar-fill" style="width:${avg}%;background:${col}"></div></div>
      </div>`;
    }).join('')
    :'<div class="dash-empty">No test data across subjects yet</div>';
}

function renderStudentsTable(){
  const search=(document.getElementById('studSearchInput')?.value||'').toLowerCase();
  const allData=getAllStudentsData();
  const list=allData.filter(s=>!search||s.name.toLowerCase().includes(search)||s.username.toLowerCase().includes(search));
  const gc=p=>p>=75?'#22c55e':p>=50?'#f59e0b':'#ef4444';
  const tbody=document.getElementById('studTableBody');
  const empty=document.getElementById('studTableEmpty');
  if(!list.length){tbody.innerHTML='';empty.style.display='';return;}
  empty.style.display='none';
  tbody.innerHTML=list.map((s,i)=>`
    <tr>
      <td>${i+1}</td>
      <td><strong>${s.name}</strong></td>
      <td style="color:var(--muted)">${s.username}</td>
      <td>${s.classSection||'—'}</td>
      <td><span class="role-badge ${s.role==='admin'?'role-admin':'role-student'}">${s.role}</span></td>
      <td>${s.tests}</td>
      <td><span style="color:${s.tests?gc(s.avg):'var(--muted)'}">${s.tests?s.avg+'%':'—'}</span></td>
      <td><span style="color:${s.tests?gc(s.best):'var(--muted)'}">${s.tests?s.best+'%':'—'}</span></td>
      <td style="display:flex;gap:5px;align-items:center">
        <button class="btn btn-warning btn-sm" onclick="openEditStudentModal('${s.username}')">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="deleteStudent('${s.username}')">🗑️</button>
        ${s.tests?`<button class="btn btn-secondary btn-sm" onclick="clearStudentHistory('${s.username}')">🔄</button>`:''}
      </td>
    </tr>`).join('');
}

function openAddStudentModal(){
  document.getElementById('addStudTitle').textContent='➕ Add Student';
  document.getElementById('editStudUsername').value='';
  document.getElementById('newStudName').value='';
  document.getElementById('newStudUser').value='';
  document.getElementById('newStudClass').value='';
  document.getElementById('newStudPass').value='';
  document.getElementById('newStudRole').value='student';
  document.getElementById('addStudErr').textContent='';
  document.getElementById('addStudentModal').classList.add('open');
}
function openEditStudentModal(username){
  const users=getUsers();
  const u=users.find(x=>x.username===username);
  if(!u)return;
  document.getElementById('addStudTitle').textContent='✏️ Edit Student';
  document.getElementById('editStudUsername').value=username;
  document.getElementById('newStudName').value=u.name;
  document.getElementById('newStudUser').value=u.username;
  document.getElementById('newStudClass').value=u.classSection||'';
  document.getElementById('newStudPass').value='';
  document.getElementById('newStudRole').value=u.role;
  document.getElementById('addStudErr').textContent='';
  document.getElementById('addStudentModal').classList.add('open');
}
function closeAddStudentModal(){document.getElementById('addStudentModal').classList.remove('open');}
function saveStudent(){
  const editUser=document.getElementById('editStudUsername').value;
  const name=document.getElementById('newStudName').value.trim();
  const username=document.getElementById('newStudUser').value.trim();
  const cls=document.getElementById('newStudClass').value.trim();
  const pass=document.getElementById('newStudPass').value;
  const role=document.getElementById('newStudRole').value;
  const errEl=document.getElementById('addStudErr');
  if(!name||!username){errEl.textContent='❌ Name and username required';return;}
  const users=getUsers();
  if(!editUser){
    if(!pass){errEl.textContent='❌ Password required for new student';return;}
    if(users.find(u=>u.username===username)){errEl.textContent='❌ Username already taken';return;}
    users.push({username,password:pass,name,classSection:cls||'10',role});
    addAdminLog('add_user','➕ Added user: '+name+' ('+username+')');
    showToast('✅ Student added!','success');
  } else {
    const idx=users.findIndex(u=>u.username===editUser);
    if(idx===-1){errEl.textContent='❌ User not found';return;}
    users[idx].name=name;users[idx].classSection=cls||'10';users[idx].role=role;
    if(pass)users[idx].password=pass;
    if(username!==editUser&&!users.find(u=>u.username===username&&u.username!==editUser))
      users[idx].username=username;
    addAdminLog('edit_user','✏️ Edited user: '+name);
    showToast('✅ Student updated!','success');
  }
  saveUsers(users);
  closeAddStudentModal();
  renderStudentsTable();
  renderAdmOverview();
}
function deleteStudent(username){
  if(username===currentUser.username){showToast('❌ Cannot delete yourself','error');return;}
  if(!confirm('Delete student "'+username+'"? All their data will be lost.'))return;
  const users=getUsers().filter(u=>u.username!==username);
  saveUsers(users);
  localStorage.removeItem('sh_data_'+username);
  addAdminLog('delete_user','🗑️ Deleted user: '+username);
  showToast('🗑️ Student deleted','error');
  renderStudentsTable();
  renderAdmOverview();
}
function clearStudentHistory(username){
  if(!confirm('Clear all test history for "'+username+'"?'))return;
  const d=getUserData(username);
  d.history=[];
  saveUserData(username,d);
  addAdminLog('clear_history','🔄 Cleared test history for: '+username);
  showToast('🔄 History cleared','info');
  renderStudentsTable();
}

function renderAdmUploads(){
  const list=files;
  const container=document.getElementById('admUploadsList');
  const empty=document.getElementById('admUploadsEmpty');
  if(!list.length){container.innerHTML='';empty.style.display='';return;}
  empty.style.display='none';
  container.innerHTML=list.map(f=>`
    <div class="um-item">
      <div class="um-icon">${getFileIcon(f.name)}</div>
      <div class="um-info">
        <div class="um-name">${f.name}</div>
        <div class="um-meta">${f.subject} · ${f.type} · ${fmtSize(f.size)} · ${f.date}</div>
      </div>
      <span class="file-tag ${f.type==='notes'?'tag-notes':f.type==='lecture'?'tag-lecture':f.type==='formula'?'tag-formula':'tag-other'}">${f.type}</span>
      <button class="btn btn-danger btn-sm" onclick="adminDeleteFile('${f.id}')">🗑️</button>
    </div>`).join('');
}
function adminDeleteFile(id){
  if(!confirm('Delete this file?'))return;
  const f=files.find(x=>x.id===id);
  files=files.filter(x=>x.id!==id);
  persistUserState();
  addAdminLog('delete_file','🗑️ Deleted file: '+(f?f.name:id));
  showToast('🗑️ File deleted','error');
  renderAdmUploads();
  renderFiles();
  updateHomeStats();
}

function renderAdmQTable(){
  const search=(document.getElementById('qAdmSearch')?.value||'').toLowerCase();
  const subj=(document.getElementById('qAdmSubjFilter')?.value||'');
  let list=customQuestions.filter(q=>{
    return(!search||q.question.toLowerCase().includes(search)||(q.subject||'').toLowerCase().includes(search)||(q.chapter||'').toLowerCase().includes(search))
      &&(!subj||q.subject===subj);
  });
  document.getElementById('qAdmCount').textContent=`${list.length} question${list.length!==1?'s':''}`;
  const dc={easy:'diff-easy',medium:'diff-medium',hard:'diff-hard'};
  const tbody=document.getElementById('qAdmTableBody');
  const empty=document.getElementById('qAdmEmpty');
  if(!list.length){tbody.innerHTML='';empty.style.display='';return;}
  empty.style.display='none';
  tbody.innerHTML=list.map((q,i)=>`
    <tr>
      <td>${i+1}</td>
      <td class="q-text" title="${q.question}" style="max-width:220px">${q.question}</td>
      <td><span class="subject-tag" style="white-space:nowrap">${q.subject}</span></td>
      <td style="font-size:.77rem;color:#fb7185">${q.chapter||'—'}</td>
      <td><span class="q-diff ${dc[q.difficulty]||''}">${q.difficulty}</span></td>
      <td><span class="tag ${q.type==='pyq'?'tag-pyq':'tag-custom'}">${q.type||'custom'}</span></td>
      <td style="display:flex;gap:4px">
        <button class="btn btn-warning btn-sm" onclick="openEditModal('${q.id}');showPage('editor')">✏️</button>
        <button class="btn btn-danger btn-sm" onclick="adminDeleteQ('${q.id}')">🗑️</button>
      </td>
    </tr>`).join('');
}
function adminDeleteQ(id){
  if(!confirm('Delete this question?'))return;
  customQuestions=customQuestions.filter(q=>q.id!==id);
  persistUserState();
  addAdminLog('delete_q','🗑️ Deleted question id: '+id);
  showToast('🗑️ Question deleted','error');
  renderAdmQTable();
  renderQTable();
  updateHomeStats();
}

function renderAdminLogs(){
  const log=getAdminLog();
  const el=document.getElementById('admLog');
  const empty=document.getElementById('admLogEmpty');
  if(!log.length){el.innerHTML='';empty.style.display='';return;}
  empty.style.display='none';
  const dotMap={login:'ai-dot-green',add_user:'ai-dot-green',edit_user:'ai-dot-yellow',delete_user:'ai-dot-red',delete_file:'ai-dot-red',delete_q:'ai-dot-red',clear_history:'ai-dot-yellow',setting:'ai-dot-yellow'};
  el.innerHTML=log.map(l=>`
    <div class="log-item">
      <div class="ai-dot log-dot ${dotMap[l.type]||'ai-dot-yellow'}"></div>
      <div style="flex:1">${l.msg}</div>
      <div class="log-time">${l.time}</div>
    </div>`).join('');
}

function renderAdmSettings(){
  const users=getUsers();
  const students=users.filter(u=>u.role!=='admin').length;
  const lsUsed=(JSON.stringify(localStorage)).length;
  const lsKB=(lsUsed/1024).toFixed(1);
  document.getElementById('admSysInfo').innerHTML=`
    Total users: <strong>${users.length}</strong><br>
    Students: <strong>${students}</strong><br>
    Admin accounts: <strong>${users.filter(u=>u.role==='admin').length}</strong><br>
    Questions in bank: <strong>${customQuestions.length}</strong><br>
    Files uploaded: <strong>${files.length}</strong><br>
    localStorage used: <strong>~${lsKB} KB</strong><br>
    App version: <strong>StudyHub v2.0 (with Admin Panel)</strong>`;
}

function changeAdminPassword(){
  const old=document.getElementById('admOldPass').value;
  const nw=document.getElementById('admNewPass').value;
  const cf=document.getElementById('admConfPass').value;
  const msg=document.getElementById('admPassMsg');
  if(!old||!nw||!cf){msg.style.color='#f87171';msg.textContent='❌ All fields required';return;}
  if(nw.length<6){msg.style.color='#f87171';msg.textContent='❌ New password must be at least 6 characters';return;}
  if(nw!==cf){msg.style.color='#f87171';msg.textContent='❌ Passwords do not match';return;}
  if(currentUser.password!==old){msg.style.color='#f87171';msg.textContent='❌ Current password is incorrect';return;}
  const users=getUsers();
  const idx=users.findIndex(u=>u.username===currentUser.username);
  if(idx===-1)return;
  users[idx].password=nw;currentUser.password=nw;
  saveUsers(users);
  msg.style.color='#4ade80';msg.textContent='✅ Password updated successfully!';
  document.getElementById('admOldPass').value='';
  document.getElementById('admNewPass').value='';
  document.getElementById('admConfPass').value='';
  addAdminLog('setting','🔐 Admin password changed');
  showToast('🔒 Password updated!','success');
}

function exportAllData(){
  const users=getUsers();
  const allData={exportDate:new Date().toISOString(),users:users.map(u=>({...u,data:getUserData(u.username)}))};
  const blob=new Blob([JSON.stringify(allData,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='studyhub_export_'+new Date().toISOString().slice(0,10)+'.json';
  a.click();
  addAdminLog('setting','📥 Exported all data');
  showToast('📥 Data exported!','success');
}
function resetAllStudentHistory(){
  if(!confirm('This will delete ALL test history for ALL students. Are you absolutely sure?'))return;
  getUsers().filter(u=>u.role!=='admin').forEach(u=>{
    const d=getUserData(u.username);d.history=[];saveUserData(u.username,d);
  });
  addAdminLog('setting','🔄 Reset all student test histories');
  showToast('🔄 All student histories reset','info');
  renderStudentsTable();
  renderAdmOverview();
}
function deleteAllStudents(){
  if(!confirm('Delete ALL students? This cannot be undone.'))return;
  if(!confirm('FINAL CONFIRMATION: Delete all student accounts and data?'))return;
  const users=getUsers().filter(u=>u.role==='admin');
  getUsers().filter(u=>u.role!=='admin').forEach(u=>localStorage.removeItem('sh_data_'+u.username));
  saveUsers(users);
  addAdminLog('setting','🗑️ Deleted all student accounts');
  showToast('🗑️ All students deleted','error');
  renderStudentsTable();
  renderAdmOverview();
}


// ═══════════════════════════ GROUP STUDY ROOMS ═══════════════════════════
// All data stored in localStorage under 'sh_rooms' (shared across users
// on same device/browser — simulates real-time collaboration).

let activeRoomId = null;
let roomPollInterval = null;
let roomChatAutoScroll = true;

// ── Storage helpers (proxied through DB engine) ───────────────────────────────
// getRooms / saveRooms are defined in the DB ENGINE section above.

function getRoom(id) {
  const rooms = getRooms();
  return rooms[id] || null;
}

function updateRoom(id, fn) {
  const rooms = getRooms();
  if (rooms[id]) { fn(rooms[id]); saveRooms(rooms); }
}

// ── Room creation ────────────────────────────────────────────────
function createRoom() {
  const name    = document.getElementById('newRoomName').value.trim();
  const subject = document.getElementById('newRoomSubject').value;
  const topic   = document.getElementById('newRoomTopic').value.trim();
  const maxP    = parseInt(document.getElementById('newRoomMax').value) || 10;
  if (!name) { showToast('❌ Room name is required', 'error'); return; }

  const id = 'room_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
  const rooms = getRooms();
  rooms[id] = {
    id, name, subject, topic: topic || subject,
    host: currentUser.username,
    members: [currentUser.username],
    maxMembers: maxP,
    chat: [],
    notes: '',
    quiz: null,
    quizAnswers: {},
    quizScores: {},
    createdAt: Date.now(),
    lastActivity: Date.now()
  };
  saveRooms(rooms);
  showToast('🏠 Room "' + name + '" created!', 'success');
  closeNewRoomModal();
  joinRoom(id);
}

// ── Join / Leave ─────────────────────────────────────────────────
function joinRoom(id) {
  const room = getRoom(id);
  if (!room) { showToast('❌ Room not found', 'error'); return; }
  if (room.members.length >= room.maxMembers && !room.members.includes(currentUser.username)) {
    showToast('❌ Room is full', 'error'); return;
  }

  if (!room.members.includes(currentUser.username)) {
    updateRoom(id, r => {
      r.members.push(currentUser.username);
      r.lastActivity = Date.now();
      r.chat.push({ user: '🔔 System', msg: currentUser.name + ' joined the room', ts: Date.now() });
    });
  }

  activeRoomId = id;
  renderRoomList();
  openRoomView(id);
}

function leaveRoom() {
  if (!activeRoomId) return;
  updateRoom(activeRoomId, r => {
    r.members = r.members.filter(m => m !== currentUser.username);
    r.chat.push({ user: '🔔 System', msg: currentUser.name + ' left the room', ts: Date.now() });
    r.lastActivity = Date.now();
    // If host left, assign new host
    if (r.host === currentUser.username && r.members.length > 0) {
      r.host = r.members[0];
    }
  });
  stopRoomPoll();
  activeRoomId = null;
  renderRoomView(null);
  renderRoomList();
  showToast('👋 Left the room', 'info');
}

function deleteRoom(id) {
  const rooms = getRooms();
  if (!rooms[id]) return;
  if (rooms[id].host !== currentUser.username && !isAdmin()) {
    showToast('❌ Only the host can delete this room', 'error'); return;
  }
  if (id === activeRoomId) { stopRoomPoll(); activeRoomId = null; }
  delete rooms[id];
  saveRooms(rooms);
  renderRoomView(null);
  renderRoomList();
  showToast('🗑️ Room deleted', 'info');
}

// ── Chat ─────────────────────────────────────────────────────────
function sendRoomChat() {
  const inp = document.getElementById('roomChatInput');
  const msg = inp?.value.trim();
  if (!msg || !activeRoomId) return;
  updateRoom(activeRoomId, r => {
    r.chat.push({ user: currentUser.name, uid: currentUser.username, msg, ts: Date.now() });
    r.lastActivity = Date.now();
    if (r.chat.length > 200) r.chat = r.chat.slice(-200);
  });
  inp.value = '';
  renderRoomChat();
}

function renderRoomChat() {
  const room = getRoom(activeRoomId);
  if (!room) return;
  const el = document.getElementById('roomChat');
  if (!el) return;
  const wasBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 10;
  el.innerHTML = room.chat.map(c => {
    const isMine = c.uid === currentUser.username;
    const isSystem = c.user.startsWith('🔔');
    if (isSystem) return `<div class="chat-system">${c.msg}</div>`;
    const t = new Date(c.ts).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
    return `<div class="chat-msg ${isMine?'chat-mine':'chat-other'}">
      <div class="chat-meta">${isMine?'You':c.user} · ${t}</div>
      <div class="chat-bubble">${escHtml(c.msg)}</div>
    </div>`;
  }).join('');
  if (wasBottom || roomChatAutoScroll) el.scrollTop = el.scrollHeight;
}

// ── Shared Notes ─────────────────────────────────────────────────
function saveRoomNotes() {
  if (!activeRoomId) return;
  const notes = document.getElementById('roomNotes')?.value || '';
  updateRoom(activeRoomId, r => { r.notes = notes; r.lastActivity = Date.now(); });
  showToast('📝 Notes saved!', 'success');
}

// ── Quiz ─────────────────────────────────────────────────────────
function startRoomQuiz() {
  if (!activeRoomId) return;
  const room = getRoom(activeRoomId);
  if (room.host !== currentUser.username && !isAdmin()) {
    showToast('❌ Only the host can start a quiz', 'error'); return;
  }
  const subj = room.subject || 'Mathematics';
  const bank = AI_QUESTION_BANK[subj] || AI_QUESTION_BANK['Mathematics'];
  const chapters = Object.keys(bank);
  const chapter = chapters[Math.floor(Math.random() * chapters.length)];
  const pool = bank[chapter];
  const qs = pool.slice().sort(() => Math.random() - 0.5).slice(0, 5);

  updateRoom(activeRoomId, r => {
    r.quiz = { questions: qs, chapter, subject: subj, startedAt: Date.now(), active: true };
    r.quizAnswers = {};
    r.quizScores = {};
    r.chat.push({ user: '🔔 System', msg: '🧠 Quiz started! Subject: ' + subj + ' | Chapter: ' + chapter, ts: Date.now() });
    r.lastActivity = Date.now();
  });
  renderRoomQuiz();
  showToast('🧠 Quiz started!', 'success');
}

function submitQuizAnswer(qIdx, optIdx) {
  if (!activeRoomId) return;
  updateRoom(activeRoomId, r => {
    if (!r.quizAnswers[currentUser.username]) r.quizAnswers[currentUser.username] = {};
    r.quizAnswers[currentUser.username][qIdx] = optIdx;
  });
  renderRoomQuiz();
}

function endRoomQuiz() {
  if (!activeRoomId) return;
  const room = getRoom(activeRoomId);
  if (!room || !room.quiz) return;
  // Calculate scores
  const scores = {};
  room.members.forEach(uid => {
    const answers = (room.quizAnswers || {})[uid] || {};
    let correct = 0;
    room.quiz.questions.forEach((q, i) => {
      if (answers[i] === q.ans) correct++;
    });
    scores[uid] = correct;
  });
  updateRoom(activeRoomId, r => {
    r.quizScores = scores;
    r.quiz.active = false;
    const topUser = Object.entries(scores).sort((a,b) => b[1]-a[1])[0];
    const topName = topUser ? topUser[0] + ' (' + topUser[1] + '/' + r.quiz.questions.length + ')' : 'N/A';
    r.chat.push({ user: '🔔 System', msg: '🏆 Quiz ended! Top scorer: ' + topName, ts: Date.now() });
    r.lastActivity = Date.now();
  });
  renderRoomQuiz();
  renderRoomChat();
}

function renderRoomQuiz() {
  const el = document.getElementById('roomQuizArea');
  if (!el) return;
  const room = getRoom(activeRoomId);
  if (!room || !room.quiz) {
    const isHost = room && room.host === currentUser.username;
    el.innerHTML = `<div class="room-empty-state">
      <div style="font-size:2rem;margin-bottom:8px">🧩</div>
      <div style="color:var(--muted);font-size:.9rem">No quiz active.</div>
      ${isHost ? `<button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="startRoomQuiz()">🧠 Start a Quiz</button>` : '<div style="color:var(--muted);font-size:.8rem;margin-top:8px">Wait for the host to start a quiz.</div>'}
    </div>`;
    return;
  }

  const quiz = room.quiz;
  const myAnswers = (room.quizAnswers || {})[currentUser.username] || {};
  const isHost = room.host === currentUser.username;
  const answered = Object.keys(myAnswers).length;
  const total = quiz.questions.length;

  let html = `<div class="quiz-room-header">
    <span>📚 ${quiz.subject} — ${quiz.chapter}</span>
    <span style="color:var(--muted);font-size:.8rem">${answered}/${total} answered</span>
    ${isHost && quiz.active ? `<button class="btn btn-warning btn-sm" onclick="endRoomQuiz()">🏁 End Quiz</button>` : ''}
  </div>`;

  if (!quiz.active && room.quizScores && Object.keys(room.quizScores).length) {
    // Show leaderboard
    const sorted = Object.entries(room.quizScores).sort((a,b) => b[1]-a[1]);
    html += `<div class="quiz-leaderboard">
      <div class="section-title" style="margin-bottom:10px">🏆 Leaderboard</div>
      ${sorted.map(([uid, score], i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i+1}.`;
        const isMe = uid === currentUser.username;
        return `<div class="lb-row ${isMe?'lb-me':''}">
          <span>${medal} ${uid}</span>
          <span style="font-weight:700;color:var(--success)">${score}/${total}</span>
        </div>`;
      }).join('')}
      ${isHost ? `<button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="startRoomQuiz()">🔄 New Quiz</button>` : ''}
    </div>`;
  } else if (quiz.active) {
    // Show questions
    html += quiz.questions.map((q, i) => {
      const chosen = myAnswers[i];
      const answered = chosen !== undefined;
      const correct = q.ans;
      const showResult = !quiz.active;
      return `<div class="quiz-room-q ${answered?'q-answered':''}">
        <div class="quiz-room-q-num">Q${i+1} <span class="diff-badge diff-${q.diff}">${q.diff}</span></div>
        <div class="quiz-room-q-text">${q.q}</div>
        <div class="quiz-room-opts">
          ${q.opts.map((opt, oi) => {
            let cls = 'quiz-room-opt';
            if (chosen === oi) cls += ' opt-chosen';
            return `<button class="${cls}" onclick="submitQuizAnswer(${i},${oi})" ${answered?'disabled':''}>${String.fromCharCode(65+oi)}. ${opt}</button>`;
          }).join('')}
        </div>
        ${answered ? `<div style="color:var(--success);font-size:.8rem;margin-top:4px">✅ Answer submitted</div>` : ''}
      </div>`;
    }).join('');
  }

  el.innerHTML = html;
}

// ── Room list rendering ──────────────────────────────────────────
function renderRoomList() {
  const el = document.getElementById('roomList');
  if (!el) return;
  const rooms = getRooms();
  // Clean up old rooms (>4 hours)
  const cutoff = Date.now() - 4 * 60 * 60 * 1000;
  let changed = false;
  Object.keys(rooms).forEach(id => {
    if (rooms[id].lastActivity < cutoff && rooms[id].members.length === 0) {
      delete rooms[id]; changed = true;
    }
  });
  if (changed) saveRooms(rooms);

  const list = Object.values(rooms).sort((a,b) => b.lastActivity - a.lastActivity);
  if (!list.length) {
    el.innerHTML = `<div class="room-empty-state"><div style="font-size:2.5rem">🏠</div><div style="margin-top:8px;color:var(--muted)">No study rooms yet. Create one!</div></div>`;
    return;
  }

  el.innerHTML = list.map(r => {
    const isMine = r.members.includes(currentUser.username);
    const isActive = r.id === activeRoomId;
    const full = r.members.length >= r.maxMembers;
    const timeAgo = getTimeAgo(r.lastActivity);
    return `<div class="room-card ${isActive?'room-card-active':''}">
      <div class="room-card-top">
        <div>
          <div class="room-card-name">${escHtml(r.name)}</div>
          <div class="room-card-meta">📚 ${r.subject} · 👥 ${r.members.length}/${r.maxMembers} · ${timeAgo}</div>
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0;align-items:center">
          ${isMine ? `<span style="font-size:.75rem;background:rgba(34,197,94,.2);color:#4ade80;padding:3px 9px;border-radius:20px">Joined</span>` : ''}
          ${full && !isMine ? `<span style="font-size:.75rem;color:var(--muted)">Full</span>` :
            !isMine ? `<button class="btn btn-primary btn-sm" onclick="joinRoom('${r.id}')">Join</button>` :
            !isActive ? `<button class="btn btn-secondary btn-sm" onclick="joinRoom('${r.id}')">Open</button>` : ''}
          ${(r.host === currentUser.username || isAdmin()) ? `<button class="btn btn-danger btn-sm" onclick="deleteRoom('${r.id}')">🗑️</button>` : ''}
        </div>
      </div>
      ${r.topic ? `<div style="font-size:.8rem;color:var(--muted);margin-top:4px">📌 ${escHtml(r.topic)}</div>` : ''}
    </div>`;
  }).join('');
}

// ── Room view ────────────────────────────────────────────────────
function openRoomView(id) {
  renderRoomView(id);
  startRoomPoll();
}

function renderRoomView(id) {
  const el = document.getElementById('roomViewArea');
  if (!el) return;
  if (!id) {
    el.innerHTML = `<div class="room-empty-state" style="padding:60px 20px">
      <div style="font-size:3rem">👥</div>
      <div style="margin-top:12px;color:var(--muted)">Join or create a room to get started</div>
    </div>`;
    return;
  }
  const room = getRoom(id);
  if (!room) return;
  const isHost = room.host === currentUser.username;

  el.innerHTML = `
    <div class="room-view-header">
      <div>
        <div style="font-size:1.1rem;font-weight:700">${escHtml(room.name)}</div>
        <div style="font-size:.8rem;color:var(--muted)">📚 ${room.subject} · 👥 ${room.members.join(', ')}</div>
      </div>
      <div style="display:flex;gap:8px;flex-shrink:0">
        ${isHost ? `<button class="btn btn-primary btn-sm" onclick="startRoomQuiz()">🧠 Quiz</button>` : ''}
        <button class="btn btn-danger btn-sm" onclick="leaveRoom()">🚪 Leave</button>
      </div>
    </div>

    <div class="room-tabs">
      <button class="room-tab active" id="rtab-chat" onclick="switchRoomTab('chat')">💬 Chat</button>
      <button class="room-tab" id="rtab-notes" onclick="switchRoomTab('notes')">📝 Notes</button>
      <button class="room-tab" id="rtab-quiz" onclick="switchRoomTab('quiz')">🧩 Quiz</button>
    </div>

    <div id="room-panel-chat" class="room-panel">
      <div class="room-chat-wrap">
        <div id="roomChat" class="room-chat-log"></div>
        <div class="room-chat-input-row">
          <input id="roomChatInput" class="form-input" placeholder="Type a message…" onkeydown="if(event.key==='Enter')sendRoomChat()" style="flex:1;margin:0">
          <button class="btn btn-primary btn-sm" onclick="sendRoomChat()">Send</button>
        </div>
      </div>
    </div>

    <div id="room-panel-notes" class="room-panel" style="display:none">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <span style="font-size:.85rem;color:var(--muted)">Shared notes — visible to all room members</span>
        <button class="btn btn-success btn-sm" onclick="saveRoomNotes()">💾 Save</button>
      </div>
      <textarea id="roomNotes" class="room-notes-area" placeholder="Write shared notes here… everyone can see them.">${escHtml(room.notes || '')}</textarea>
    </div>

    <div id="room-panel-quiz" class="room-panel" style="display:none">
      <div id="roomQuizArea"></div>
    </div>
  `;

  renderRoomChat();
  renderRoomQuiz();
}

function switchRoomTab(tab) {
  ['chat','notes','quiz'].forEach(t => {
    document.getElementById('room-panel-' + t).style.display = t === tab ? '' : 'none';
    document.getElementById('rtab-' + t)?.classList.toggle('active', t === tab);
  });
  if (tab === 'quiz') renderRoomQuiz();
  if (tab === 'chat') renderRoomChat();
  if (tab === 'notes') {
    const room = getRoom(activeRoomId);
    if (room) document.getElementById('roomNotes').value = room.notes || '';
  }
}

// ── Poll for updates (simulates real-time) ───────────────────────
function startRoomPoll() {
  stopRoomPoll();
  roomPollInterval = setInterval(() => {
    if (!activeRoomId) return;
    renderRoomChat();
    renderRoomQuiz();
    // Update members list in header
    const room = getRoom(activeRoomId);
    if (room) {
      const hdr = document.querySelector('.room-view-header div div:last-child');
      if (hdr) hdr.textContent = '📚 ' + room.subject + ' · 👥 ' + room.members.join(', ');
    }
    renderRoomList();
  }, 2000);
}

function stopRoomPoll() {
  if (roomPollInterval) { clearInterval(roomPollInterval); roomPollInterval = null; }
}

// ── New room modal ────────────────────────────────────────────────
function openNewRoomModal() {
  document.getElementById('newRoomModal').classList.add('open');
  // Populate subject options
  const sel = document.getElementById('newRoomSubject');
  sel.innerHTML = Object.keys(SUBJECTS_CHAPTERS).map(s => `<option value="${s}">${s}</option>`).join('');
}
function closeNewRoomModal() {
  document.getElementById('newRoomModal').classList.remove('open');
  document.getElementById('newRoomName').value = '';
  document.getElementById('newRoomTopic').value = '';
}

// ── Page init ────────────────────────────────────────────────────
function initRooms() {
  renderRoomList();
  renderRoomView(activeRoomId);
  if (activeRoomId) startRoomPoll();
}

// ── Utilities ────────────────────────────────────────────────────
function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function getTimeAgo(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return Math.floor(diff/60000) + 'm ago';
  return Math.floor(diff/3600000) + 'h ago';
}


// ═══════════════════════════════════════════════════════════════════════════════
// AUTH — fully async, API-backed
// ═══════════════════════════════════════════════════════════════════════════════

function switchAuthTab(t) {
  document.querySelectorAll('.auth-tab').forEach((x, i) =>
    x.classList.toggle('active', (i === 0 && t === 'login') || (i === 1 && t === 'signup'))
  );
  document.getElementById('loginForm').style.display  = t === 'login'  ? '' : 'none';
  document.getElementById('signupForm').style.display = t === 'signup' ? '' : 'none';
  document.getElementById('authError').textContent    = '';
}

function isAdmin() { return currentUser && currentUser.role === 'admin'; }

// ── setAuthLoading helper ─────────────────────────────────────────────────────
function setAuthLoading(on) {
  document.querySelectorAll('#loginForm button, #signupForm button').forEach(b => {
    b.disabled = on;
    if (on) { b.dataset.orig = b.textContent; b.textContent = '⏳ Connecting…'; }
    else if (b.dataset.orig) b.textContent = b.dataset.orig;
  });
}

// ── Login via Firebase Auth ───────────────────────────────────────────────────
async function doLogin() {
  const userVal = document.getElementById('loginUser').value.trim();
  const pass    = document.getElementById('loginPass').value;
  const errEl   = document.getElementById('authError');
  if (!userVal || !pass) { errEl.textContent = '❌ Please enter your email/username and password'; return; }

  setAuthLoading(true);
  errEl.textContent = '';

  try {
    // Determine if email or username was entered
    let email = userVal.includes('@') ? userVal : null;

    if (!email) {
      // Username login: look up email from localStorage users
      
      const allKeys = Object.keys(localStorage).filter(k => k.startsWith('sh_users_'));
      let found = null;
      for (const k of allKeys) {
        try {
          const u = JSON.parse(localStorage.getItem(k));
          if (u && u.username && u.username.toLowerCase() === userVal.toLowerCase()) { found = u; break; }
        } catch(e) {}
      }
      
      if (!found) { errEl.textContent = '❌ Username not found.'; setAuthLoading(false); return; }
      email = found.email;
    }

    
    const cred = await window._fb.signIn(email, pass);
    

    // onAuthStateChanged will call enterApp automatically
    showToast('✅ Welcome back!', 'success');
  } catch(e) {
    
    setAuthLoading(false);
    const code = e.code || '';
    if (code === 'auth/user-not-found' || code === 'auth/invalid-credential')
      errEl.textContent = '❌ Account not found.';
    else if (code === 'auth/wrong-password' || code === 'auth/invalid-login-credentials')
      errEl.textContent = '❌ Incorrect password.';
    else if (code === 'auth/too-many-requests')
      errEl.textContent = '❌ Too many attempts. Try again later.';
    else
      errEl.textContent = '❌ ' + (e.message || 'Login failed.');
  }
}

// ── Signup via Firebase Auth ──────────────────────────────────────────────────
async function doSignup() {
  const name  = document.getElementById('signName').value.trim();
  const user  = document.getElementById('signUser').value.trim().toLowerCase();
  const cls   = document.getElementById('signClass').value.trim();
  const email = document.getElementById('signEmail').value.trim();
  const pass  = document.getElementById('signPass').value;
  const errEl = document.getElementById('authError');

  if (!name || !user || !email || !pass) { errEl.textContent = '❌ All fields required'; return; }
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(user)) { errEl.textContent = '❌ Username: 3–20 chars, letters/numbers/_ only'; return; }
  if (pass.length < 6) { errEl.textContent = '❌ Password must be at least 6 characters'; return; }

  setAuthLoading(true);
  errEl.textContent = '';

  try {
    // Check username uniqueness in localStorage (skip demo users)
    const allKeys = Object.keys(localStorage).filter(k => k.startsWith('sh_users_'));
    const usernameTaken = allKeys.some(k => {
      try {
        const u = JSON.parse(localStorage.getItem(k));
        // Skip demo users (they have demo uid prefix)
        if (u && u.uid && u.uid.startsWith('demo')) return false;
        return u && u.username && u.username.toLowerCase() === user.toLowerCase();
      } catch(e) { return false; }
    });
    if (usernameTaken) {
      setAuthLoading(false);
      errEl.textContent = '❌ Username is already taken. Try another one.'; return;
    }

    // Create Firebase Auth account
    showDbStatus('🔐 Creating account…');
    const cred = await window._fb.createUser(email, pass);
    const uid  = cred.user.uid;

    // Update display name
    await window._fb.updateProfile(cred.user, { displayName: name });

    // Save user profile to Firestore
    const role = 'student'; // default role, admin sets via admin panel
    const profile = { uid, name, username: user, email, classSection: cls || '10', role, createdAt: Date.now() };
    await window._fb.setDoc(window._fb.userDoc(uid), profile);

    // Seed empty user data
    await window._fb.setDoc(window._fb.dataDoc(uid), {
      files: [], questions: [], history: []
    });

    
    showToast('🎉 Account created! Welcome ' + name + '!', 'success');
    addAdminLog('signup', '🆕 New account: ' + name + ' (' + user + ')');
    // onAuthStateChanged will call enterApp
  } catch(e) {
    
    setAuthLoading(false);
    const code = e.code || '';
    if (code === 'auth/email-already-in-use')
      errEl.textContent = '❌ Email already registered.';
    else if (code === 'auth/invalid-email')
      errEl.textContent = '❌ Invalid email address.';
    else if (code === 'auth/weak-password')
      errEl.textContent = '❌ Password too weak.';
    else
      errEl.textContent = '❌ ' + (e.message || 'Signup failed.');
  }
}

// ── Enter App (called after Firebase auth state confirmed) ────────────────────
function enterApp() {
  loadUserState();
  document.getElementById('authScreen').style.display    = 'none';
  document.getElementById('appShell').style.display      = '';
  document.getElementById('mainNav').style.display       = 'flex';
  document.getElementById('mainContent').style.display   = '';
  // Update UI with user info
  const initial = (currentUser.name||'?')[0].toUpperCase();
  const navAv = document.getElementById('navAvatar');
  const topAv = document.getElementById('topAvatar');
  if(navAv) navAv.textContent = initial;
  if(topAv) topAv.textContent = initial;
  document.getElementById('navName').textContent  = currentUser.name;
  document.getElementById('navRole').textContent  = isAdmin() ? '@admin' : '@' + currentUser.username;
  const crown = document.getElementById('adminCrown');
  if(crown) crown.style.display = isAdmin() ? '' : 'none';
  const edTab  = document.getElementById('editorTab');
  const admTab = document.getElementById('adminTab');
  if(edTab)  edTab.style.display  = isAdmin() ? 'flex' : 'none';
  if(admTab) admTab.style.display = isAdmin() ? 'flex' : 'none';
  const greet = document.getElementById('greetName');
  if(greet) greet.textContent = (currentUser.name||'Student').split(' ')[0];
  const dashHello = document.getElementById('dashHelloName');
  if(dashHello) dashHello.textContent = (currentUser.name||'').toUpperCase();
  buildSubjCheckboxes(); buildPYQTabs(); updateHomeStats();
  updateModalChapter(); updateAIChapters();
  renderFiles(); renderQTable(); renderHistory();
  if(isAdmin() && typeof updateCldUI === 'function') updateCldUI();
  showPage('home');
  updateDailyStreak();
  updateTopAvatar();
}

// ── Logout via Firebase Auth ──────────────────────────────────────────────────
async function doLogout() {
  try {
    if (_fbReady && currentUser) await persistUserState();
    await window._fb.signOut();
  } catch(e) {}
  currentUser = null;
  if(document.getElementById('loginUser')) document.getElementById('loginUser').value = '';
  if(document.getElementById('loginPass')) document.getElementById('loginPass').value = '';
  if(document.getElementById('authError')) document.getElementById('authError').textContent = '';
  document.getElementById('authScreen').style.display = 'flex';
  document.getElementById('appShell').style.display   = 'none';
  showToast('👋 Logged out', 'info');
}

// ── Forgot Password ───────────────────────────────────────────────────────────
async function doForgotPassword() {
  const email = document.getElementById('loginUser').value.trim();
  if (!email || !email.includes('@')) {
    showToast('❌ Enter your email address first, then click Forgot Password', 'error');
    return;
  }
  try {
    await window._fb.resetPassword(email);
    showToast('📧 Password reset email sent! Check your inbox.', 'success');
  } catch(e) {
    showToast('❌ ' + (e.message || 'Could not send reset email'), 'error');
  }
}

// ── Google Login ──────────────────────────────────────────────────────────────
async function doGoogleLogin() {
  try {
    const result = await window._fb.googleSignIn();
    const fbUser = result.user;
    // Check if profile exists
    let profile = await fbGetUserProfile(fbUser.uid);
    if (!profile) {
      profile = {
        uid: fbUser.uid,
        name: fbUser.displayName || 'User',
        username: fbUser.email.split('@')[0],
        email: fbUser.email,
        role: 'student',
        classSection: '10',
        joinedAt: new Date().toISOString(),
        avatar: fbUser.photoURL || '',
      };
      await fbSaveUserProfile(fbUser.uid, profile);
    }
    showToast('✅ Signed in with Google!', 'success');
  } catch(e) {
    if (e.code !== 'auth/popup-closed-by-user') {
      showToast('❌ Google sign-in failed: ' + (e.message || ''), 'error');
    }
  }
}



// ── Boot: init Firebase, then watch auth state ────────────────────────────────

// ══════════════════════════════════════════════════════════════════════════════
// ── ANIMATIONS & UI POLISH ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════

// Animated counter
function animateCounter(el, target, duration = 1000) {
  if (!el) return;
  const start = parseInt(el.textContent) || 0;
  const range = target - start;
  const startTime = performance.now();
  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + range * ease);
    el.classList.add('updated');
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

// Show skeleton loaders
function showSkeletons(containerId, count = 3, type = 'card') {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = Array.from({length: count}, () =>
    `<div class="skeleton skeleton-${type}"></div>`
  ).join('');
}

// Page transition
function navigateWithTransition(pageFn) {
  const main = document.getElementById('mainContent');
  if (main) {
    main.style.opacity = '0';
    main.style.transform = 'translateY(10px)';
    setTimeout(() => {
      pageFn();
      main.style.transition = 'opacity .3s ease, transform .3s ease';
      main.style.opacity = '1';
      main.style.transform = 'translateY(0)';
    }, 120);
  } else { pageFn(); }
}

// ── IMAGE COMPRESSION ──────────────────────────────────────────────────────
function compressImage(file, maxWidth = 1200, quality = 0.82) {
  return new Promise((resolve) => {
    if (!file.type.startsWith('image/')) { resolve(file); return; }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let { width, height } = img;
      if (width <= maxWidth) { resolve(file); return; }
      const ratio = maxWidth / width;
      width = maxWidth; height = Math.round(height * ratio);
      const canvas = document.createElement('canvas');
      canvas.width = width; canvas.height = height;
      canvas.getContext('2d').drawImage(img, 0, 0, width, height);
      canvas.toBlob(blob => {
        const compressed = new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() });
        console.log(`Compressed: ${(file.size/1024).toFixed(0)}KB → ${(compressed.size/1024).toFixed(0)}KB`);
        resolve(compressed);
      }, 'image/jpeg', quality);
    };
    img.src = url;
  });
}

// ── PDF PREVIEW MODAL ──────────────────────────────────────────────────────
function openPdfPreview(url, name) {
  const existing = document.getElementById('pdfPreviewModal');
  if (existing) existing.remove();
  const modal = document.createElement('div');
  modal.id = 'pdfPreviewModal';
  modal.className = 'pdf-preview-modal';
  modal.innerHTML = `
    <div class="pdf-preview-inner">
      <div class="pdf-preview-header">
        <h3>📄 ${name || 'Document Preview'}</h3>
        <div style="display:flex;gap:8px;">
          <a href="${url}" target="_blank" style="background:rgba(124,58,237,.8);border:none;color:#fff;border-radius:8px;padding:6px 14px;cursor:pointer;font-size:13px;text-decoration:none;">⬇ Download</a>
          <button onclick="document.getElementById('pdfPreviewModal').remove()">✕ Close</button>
        </div>
      </div>
      <iframe class="pdf-preview-frame" src="${url}" title="${name}"></iframe>
    </div>`;
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  document.body.appendChild(modal);
}

// ── DRAG & DROP UPLOAD with Firebase Storage ───────────────────────────────
function initDropZone(zoneId, onFileSelected) {
  const zone = document.getElementById(zoneId);
  if (!zone) return;
  ['dragenter','dragover'].forEach(ev => zone.addEventListener(ev, e => {
    e.preventDefault(); zone.classList.add('drag-over');
  }));
  ['dragleave','drop'].forEach(ev => zone.addEventListener(ev, e => {
    e.preventDefault(); zone.classList.remove('drag-over');
  }));
  zone.addEventListener('drop', e => {
    const files = e.dataTransfer.files;
    if (files.length) onFileSelected(files[0]);
  });
  const input = zone.querySelector('input[type=file]');
  if (input) input.addEventListener('change', e => {
    if (e.target.files.length) onFileSelected(e.target.files[0]);
  });
}

// Upload file to Firebase Storage with progress bar
async function uploadToFirebaseStorage(file, path, progressBarId, statusId) {
  const progressWrap = document.getElementById(progressBarId + '-wrap');
  const progressBar  = document.getElementById(progressBarId);
  const statusEl     = document.getElementById(statusId);

  if (progressWrap) progressWrap.classList.add('active');
  if (statusEl) statusEl.textContent = 'Uploading...';

  // Compress if image
  const finalFile = await compressImage(file);

  try {
    const downloadURL = await window._fb.uploadFile(path, finalFile, (pct) => {
      if (progressBar) progressBar.style.width = pct + '%';
      if (statusEl) statusEl.textContent = `Uploading... ${pct}%`;
    });
    if (progressBar) progressBar.style.width = '100%';
    if (statusEl) statusEl.textContent = '✅ Upload complete!';
    setTimeout(() => {
      if (progressWrap) progressWrap.classList.remove('active');
      if (statusEl) statusEl.textContent = '';
    }, 2500);
    return downloadURL;
  } catch (err) {
    if (statusEl) statusEl.textContent = '❌ Upload failed: ' + err.message;
    if (progressWrap) progressWrap.classList.remove('active');
    throw err;
  }
}


// ══════════════════════════════════════════════════════════════════════════════
// ── AI TUTOR PAGE ─────────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════

function switchAITab(tab) {
  ['tutor','doubt','summary'].forEach(t => {
    document.getElementById('panel-' + t).style.display = t === tab ? '' : 'none';
    const btn = document.getElementById('tab-' + t);
    if (btn) {
      btn.style.background = t === tab ? 'linear-gradient(135deg,#7c3aed,#06b6d4)' : '';
      btn.style.border = t === tab ? 'none' : '';
      btn.style.color = t === tab ? '#fff' : '';
    }
  });
}

function quickAsk(q, subj) {
  document.getElementById('tutorQuestion').value = q;
  document.getElementById('tutorSubject').value = subj;
  sendTutorQuestion();
}

function addChatBubble(container, text, isUser) {
  const div = document.createElement('div');
  div.style.cssText = `display:flex;gap:10px;align-items:flex-start;${isUser ? 'flex-direction:row-reverse;' : ''}`;
  const avatar = document.createElement('div');
  avatar.style.cssText = `min-width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;background:${isUser ? 'rgba(124,58,237,.2)' : 'rgba(6,182,212,.15)'};`;
  avatar.textContent = isUser ? '👤' : '🤖';
  const bubble = document.createElement('div');
  bubble.style.cssText = `background:${isUser ? 'rgba(124,58,237,.15)' : 'rgba(255,255,255,.05)'};border:1px solid ${isUser ? 'rgba(124,58,237,.3)' : 'rgba(255,255,255,.08)'};border-radius:14px;padding:12px 16px;font-size:14px;line-height:1.6;max-width:85%;white-space:pre-wrap;`;
  bubble.textContent = text;
  div.appendChild(avatar);
  div.appendChild(bubble);
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return bubble;
}

function addLoadingBubble(container) {
  const div = document.createElement('div');
  div.id = 'ai-loading-bubble';
  div.style.cssText = 'display:flex;gap:10px;align-items:center;';
  div.innerHTML = `<div style="min-width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;background:rgba(6,182,212,.15);">🤖</div>
    <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:12px 16px;font-size:14px;color:#64748b;">
      <span style="animation:pulse 1s infinite;">Thinking</span> <span id="dots">...</span>
    </div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  // Animate dots
  let d = 0;
  div._interval = setInterval(() => { 
    const dots = div.querySelector('#dots');
    if (dots) dots.textContent = ['...','.. ','.'  ][d++ % 3];
  }, 400);
  return div;
}

async function sendTutorQuestion() {
  const q = document.getElementById('tutorQuestion').value.trim();
  const subj = document.getElementById('tutorSubject').value;
  if (!q) { showToast('❌ Please type a question first', 'error'); return; }

  const chat = document.getElementById('tutorChat');
  addChatBubble(chat, q, true);
  document.getElementById('tutorQuestion').value = '';

  const loader = addLoadingBubble(chat);
  try {
    const answer = await askAITutor(q, subj);
    clearInterval(loader._interval);
    loader.remove();
    addChatBubble(chat, answer, false);
  } catch(err) {
    clearInterval(loader._interval);
    loader.remove();
    addChatBubble(chat, '❌ Error: ' + err.message, false);
  }
}

async function sendDoubt() {
  const doubt = document.getElementById('doubtText').value.trim();
  if (!doubt) { showToast('❌ Please describe your doubt', 'error'); return; }

  const resultEl = document.getElementById('doubtAnswer');
  resultEl.innerHTML = `<div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px;color:#64748b;font-size:14px;">🤖 Solving your doubt...</div>`;

  try {
    const answer = await solveDoubt(doubt);
    resultEl.innerHTML = `
      <div style="background:rgba(6,182,212,.08);border:1px solid rgba(6,182,212,.2);border-radius:16px;padding:20px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
          <span style="font-size:20px;">🤖</span>
          <span style="font-size:13px;font-weight:600;color:#06b6d4;">Gemini AI Answer</span>
        </div>
        <p style="font-size:14px;line-height:1.7;white-space:pre-wrap;margin:0;">${answer}</p>
      </div>`;
  } catch(err) {
    resultEl.innerHTML = `<div style="color:#ef4444;padding:12px;">❌ ${err.message}</div>`;
  }
}

async function getChapterSummary() {
  const subj = document.getElementById('summarySubject').value;
  const chapter = document.getElementById('summaryChapter').value;
  const resultEl = document.getElementById('summaryResult');

  resultEl.innerHTML = `<div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px;color:#64748b;font-size:14px;">📖 Generating summary for ${chapter}...</div>`;

  try {
    const summary = await summarizeChapter(subj, chapter);
    resultEl.innerHTML = `
      <div style="background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);border-radius:16px;padding:20px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">
          <span style="font-size:20px;">📖</span>
          <div>
            <p style="margin:0;font-weight:600;font-size:15px;">${chapter}</p>
            <p style="margin:0;font-size:12px;color:#8b5cf6;">${subj} · AI Summary</p>
          </div>
        </div>
        <p style="font-size:14px;line-height:1.7;white-space:pre-wrap;margin:0;">${summary}</p>
        <button onclick="navigator.clipboard.writeText(document.querySelector('#summaryResult p').textContent).then(()=>showToast('Copied!','success'))" class="btn" style="margin-top:12px;font-size:12px;">📋 Copy Summary</button>
      </div>`;
  } catch(err) {
    resultEl.innerHTML = `<div style="color:#ef4444;padding:12px;">❌ ${err.message}</div>`;
  }
}


// ══════════════════════════════════════════════════════════════════════════════
// ── REAL XP & LEVEL SYSTEM ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════

const XP_LEVELS = [
  { level:1,  name:'Beginner',     xpRequired:0    },
  { level:2,  name:'Explorer',     xpRequired:100  },
  { level:3,  name:'Learner',      xpRequired:250  },
  { level:4,  name:'Scholar',      xpRequired:500  },
  { level:5,  name:'Achiever',     xpRequired:900  },
  { level:6,  name:'Expert',       xpRequired:1400 },
  { level:7,  name:'Master',       xpRequired:2000 },
  { level:8,  name:'Champion',     xpRequired:2800 },
  { level:9,  name:'Legend',       xpRequired:3800 },
  { level:10, name:'Grand Master', xpRequired:5000 },
];

const XP_REWARDS = {
  quiz_complete:  10,
  quiz_perfect:   50,
  quiz_good:      25,
  daily_login:    20,
  upload_file:    15,
  streak_7:       100,
  streak_30:      500,
  first_quiz:     30,
};

const BADGES = [
  { id:'first_quiz',  icon:'🎯', name:'First Quiz',     desc:'Completed your first quiz',    condition: u => u.quizCount >= 1 },
  { id:'quiz_5',      icon:'📚', name:'Quiz Addict',    desc:'Completed 5 quizzes',          condition: u => u.quizCount >= 5 },
  { id:'quiz_20',     icon:'🏆', name:'Quiz Champion',  desc:'Completed 20 quizzes',         condition: u => u.quizCount >= 20 },
  { id:'perfect',     icon:'💯', name:'Perfectionist',  desc:'Scored 100% on a quiz',        condition: u => u.hasPerfectScore },
  { id:'streak_7',    icon:'🔥', name:'Week Warrior',   desc:'7 day login streak',           condition: u => u.streak >= 7 },
  { id:'streak_30',   icon:'⚡', name:'Monthly Hero',   desc:'30 day login streak',          condition: u => u.streak >= 30 },
  { id:'upload_5',    icon:'📂', name:'File Master',    desc:'Uploaded 5 files',             condition: u => u.filesUploaded >= 5 },
  { id:'level_5',     icon:'🌟', name:'Rising Star',    desc:'Reached level 5',              condition: u => u.level >= 5 },
  { id:'level_10',    icon:'👑', name:'Grand Scholar',  desc:'Reached max level',            condition: u => u.level >= 10 },
  { id:'score_90',    icon:'🎓', name:'Top Scorer',     desc:'Average score above 90%',      condition: u => u.avgScore >= 90 },
];

function getLevelFromXP(xp) {
  let current = XP_LEVELS[0];
  for (const lvl of XP_LEVELS) {
    if (xp >= lvl.xpRequired) current = lvl;
    else break;
  }
  return current;
}

function getNextLevel(xp) {
  for (let i = 0; i < XP_LEVELS.length - 1; i++) {
    if (xp < XP_LEVELS[i+1].xpRequired) return XP_LEVELS[i+1];
  }
  return null;
}

function getXPStats() {
  if (!currentUser) return { xp:0, level:1, levelName:'Beginner', progress:0, streak:0 };
  const ud = getUserData(currentUser.uid);
  const xp = ud.xp || 0;
  const streak = ud.streak || 0;
  const lvl = getLevelFromXP(xp);
  const nextLvl = getNextLevel(xp);
  const progress = nextLvl
    ? Math.round(((xp - lvl.xpRequired) / (nextLvl.xpRequired - lvl.xpRequired)) * 100)
    : 100;
  return { xp, level: lvl.level, levelName: lvl.name, progress, nextLvl, streak };
}

async function earnXP(reason, customAmount) {
  if (!currentUser) return;
  const amount = customAmount || XP_REWARDS[reason] || 10;
  const ud = getUserData(currentUser.uid);
  const oldXP = ud.xp || 0;
  const newXP = oldXP + amount;
  const oldLevel = getLevelFromXP(oldXP).level;
  const newLevel = getLevelFromXP(newXP).level;

  ud.xp = newXP;
  ud.xpLog = ud.xpLog || [];
  ud.xpLog.unshift({ reason, amount, ts: Date.now() });
  if (ud.xpLog.length > 50) ud.xpLog = ud.xpLog.slice(0, 50);

  saveUserData(currentUser.uid, ud);
  debouncePersist();

  showToast(`+${amount} XP — ${reason.replace(/_/g,' ')}! 🌟`, 'success', 2000);

  if (newLevel > oldLevel) {
    const lvlName = getLevelFromXP(newXP).name;
    setTimeout(() => showToast(`🎉 Level Up! You are now Level ${newLevel} — ${lvlName}!`, 'success', 4000), 500);
  }

  await checkAndAwardBadges();
  if (document.getElementById('profile')?.classList.contains('active')) renderProfilePage();
}

async function checkAndAwardBadges() {
  if (!currentUser) return;
  const ud = getUserData(currentUser.uid);
  const history = testHistory || [];
  const stats = {
    quizCount: history.length,
    hasPerfectScore: history.some(h => h.pct >= 100),
    streak: ud.streak || 0,
    filesUploaded: files.length,
    level: getLevelFromXP(ud.xp || 0).level,
    avgScore: history.length ? Math.round(history.reduce((a,h) => a + (h.pct||0), 0) / history.length) : 0,
  };
  ud.badges = ud.badges || [];
  let newBadge = false;
  for (const badge of BADGES) {
    if (!ud.badges.includes(badge.id) && badge.condition(stats)) {
      ud.badges.push(badge.id);
      newBadge = true;
      setTimeout(() => showToast(`🏅 Badge Earned: ${badge.icon} ${badge.name}!`, 'success', 4000), 800);
    }
  }
  if (newBadge) { saveUserData(currentUser.uid, ud); debouncePersist(); }
}

function updateDailyStreak() {
  if (!currentUser) return;
  const ud = getUserData(currentUser.uid);
  const today = new Date().toDateString();
  const lastLogin = ud.lastLoginDate;
  if (lastLogin === today) return;
  const yesterday = new Date(Date.now() - 86400000).toDateString();
  if (lastLogin === yesterday) {
    ud.streak = (ud.streak || 0) + 1;
  } else {
    ud.streak = 1;
  }
  ud.lastLoginDate = today;
  if (!lastLogin) earnXP('daily_login');
  else if (lastLogin !== today) earnXP('daily_login');
  if (ud.streak === 7)  earnXP('streak_7');
  if (ud.streak === 30) earnXP('streak_30');
  saveUserData(currentUser.uid, ud);
}

// ── Profile Page Renderer ─────────────────────────────────────────────────────
function renderProfilePage() {
  if (!currentUser) return;
  const ud = getUserData(currentUser.uid);
  const { xp, level, levelName, progress, nextLvl, streak } = getXPStats();
  const history = testHistory || [];

  // Avatar
  const avatarBig = document.getElementById('profileAvatarBig');
  if (avatarBig) {
    if (ud.avatarUrl) {
      avatarBig.innerHTML = `<img src="${ud.avatarUrl}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } else {
      avatarBig.textContent = (currentUser.name || 'U')[0].toUpperCase();
    }
  }

  // Basic info
  const setEl = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  setEl('profileName', currentUser.name || 'Student');
  setEl('profileUsername', '@' + (currentUser.username || ''));
  setEl('profileRoleBadge', currentUser.role === 'admin' ? '👑 Admin' : '🎓 Student');
  setEl('profileClassBadge', 'Class ' + (currentUser.classSection || '10'));

  // XP & Level
  setEl('profileLevelNum', level);
  setEl('profileLevelName', levelName);
  setEl('profileTotalXP', xp.toLocaleString());
  setEl('profileXPLabel', xp + ' XP');
  setEl('profileXPNext', nextLvl ? (nextLvl.xpRequired - xp) + ' XP to Level ' + nextLvl.level : 'MAX LEVEL! 👑');
  const xpBar = document.getElementById('profileXPBar');
  if (xpBar) setTimeout(() => xpBar.style.width = progress + '%', 100);

  // Stats
  setEl('profileQuizCount', history.length);
  setEl('profileStreak', streak + (streak >= 7 ? ' 🔥' : ''));
  setEl('profileFilesCount', files.length);
  const avg = history.length ? Math.round(history.reduce((a,h) => a+(h.pct||0),0)/history.length) : 0;
  setEl('profileAvgScore', avg + '%');

  // Badges
  const badgeContainer = document.getElementById('profileBadges');
  if (badgeContainer) {
    const earned = (ud.badges || []);
    if (earned.length === 0) {
      badgeContainer.innerHTML = '<p style="color:rgba(255,255,255,.4);font-size:13px;">Complete quizzes to earn badges!</p>';
    } else {
      badgeContainer.innerHTML = earned.map(id => {
        const b = BADGES.find(x => x.id === id);
        return b ? `<div style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:10px 14px;display:flex;align-items:center;gap:8px;">
          <span style="font-size:1.4rem;">${b.icon}</span>
          <div><p style="margin:0;font-size:13px;font-weight:600;">${b.name}</p><p style="margin:0;font-size:11px;color:rgba(255,255,255,.5);">${b.desc}</p></div>
        </div>` : '';
      }).join('');
    }
  }

  // Recent Activity
  const actEl = document.getElementById('profileActivity');
  if (actEl) {
    const recent = (history || []).slice(0, 5);
    if (recent.length === 0) {
      actEl.innerHTML = '<p style="color:rgba(255,255,255,.4);font-size:13px;">No activity yet. Take a quiz to get started!</p>';
    } else {
      actEl.innerHTML = recent.map(h => `
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:rgba(255,255,255,.04);border-radius:10px;">
          <div><p style="margin:0;font-size:13px;font-weight:500;">${h.subject || 'Quiz'}</p>
          <p style="margin:0;font-size:11px;color:rgba(255,255,255,.4);">${new Date(h.date||Date.now()).toLocaleDateString()}</p></div>
          <span style="font-size:15px;font-weight:700;color:${(h.pct||0)>=80?'#22c55e':(h.pct||0)>=50?'#f59e0b':'#f87171'}">${Math.round(h.pct||0)}%</span>
        </div>`).join('');
    }
  }
}

// ── Edit Profile ──────────────────────────────────────────────────────────────
function openEditProfileModal() {
  if (!currentUser) return;
  document.getElementById('editProfileName').value = currentUser.name || '';
  document.getElementById('editProfileClass').value = currentUser.classSection || '';
  const ud = getUserData(currentUser.uid);
  document.getElementById('editProfileBio').value = ud.bio || '';
  document.getElementById('editProfilePass').value = '';
  document.getElementById('editProfileMsg').style.display = 'none';
  document.getElementById('editProfileModal').style.display = 'flex';
  document.getElementById('editProfileModal').style.cssText += ';position:fixed;inset:0;z-index:9999;align-items:center;justify-content:center;background:rgba(0,0,0,.7);';
}

async function saveProfileEdits() {
  const name = document.getElementById('editProfileName').value.trim();
  const cls  = document.getElementById('editProfileClass').value.trim();
  const bio  = document.getElementById('editProfileBio').value.trim();
  const pass = document.getElementById('editProfilePass').value;
  const msg  = document.getElementById('editProfileMsg');

  if (!name) { msg.textContent = '❌ Name cannot be empty'; msg.style.display='block'; return; }

  currentUser.name = name;
  currentUser.classSection = cls || currentUser.classSection;

  const ud = getUserData(currentUser.uid);
  ud.bio = bio;
  saveUserData(currentUser.uid, ud);

  // Update Firebase Auth display name
  try {
    const fbUser = window._fb.currentFbUser();
    if (fbUser) await window._fb.updateProfile(fbUser, { displayName: name });
    // Save to Firestore
    await fbSaveUserProfile(currentUser.uid, { name, classSection: cls, bio });
  } catch(e) { console.warn('Profile save error:', e); }

  // Update password if provided
  if (pass) {
    try {
      const { updatePassword } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js');
      await updatePassword(window._fb.currentFbUser(), pass);
      showToast('🔑 Password updated!', 'success');
    } catch(e) {
      msg.textContent = '❌ Password error: ' + e.message;
      msg.style.display = 'block'; return;
    }
  }

  // Update UI
  debouncePersist();
  updateTopAvatar();
  document.getElementById('editProfileModal').style.display = 'none';
  renderProfilePage();
  showToast('✅ Profile updated!', 'success');
}

async function uploadAvatar(file) {
  if (!file || !currentUser) return;
  try {
    const compressed = await compressImage(file, 400, 0.85);
    let avatarUrl;
    if (isCldEnabled()) {
      const cfg = getCldConfig();
      const fd = new FormData();
      fd.append('file', compressed);
      fd.append('upload_preset', cfg.uploadPreset);
      fd.append('folder', 'studyhub/avatars');
      const res = await fetch(`https://api.cloudinary.com/v1_1/${cfg.cloudName}/image/upload`, { method:'POST', body:fd });
      const data = await res.json();
      avatarUrl = data.secure_url;
    } else {
      avatarUrl = await new Promise(resolve => {
        const r = new FileReader(); r.onload = e => resolve(e.target.result); r.readAsDataURL(compressed);
      });
    }
    const ud = getUserData(currentUser.uid);
    ud.avatarUrl = avatarUrl;
    saveUserData(currentUser.uid, ud);
    await fbSaveUserProfile(currentUser.uid, { avatarUrl });
    updateTopAvatar();
    renderProfilePage();
    showToast('✅ Avatar updated!', 'success');
  } catch(e) {
    showToast('❌ Avatar upload failed', 'error');
  }
}

function updateTopAvatar() {
  if (!currentUser) return;
  const ud = getUserData(currentUser.uid);
  const initials = (currentUser.name || 'U')[0].toUpperCase();
  ['topAvatar', 'navAvatar'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (ud.avatarUrl) {
      el.innerHTML = `<img src="${ud.avatarUrl}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } else {
      el.textContent = initials;
    }
  });
}

async function bootApp() {
  updateAIChapters();
  injectDemoDataIfEmpty();
  // Init drag & drop on upload page
  setTimeout(() => {
    initDropZone('mainDropZone', (file) => handleFiles([file]));
  }, 500);
  const hint = document.querySelector('.auth-hint');
  if(hint) hint.textContent = 'Admin login: rahulmehersahala@gmail.com · rahul78488';

  try {
    await initFirebase();

    // Watch Firebase auth state — fires immediately if already signed in
    window._fb.onAuthStateChanged(async (fbUser) => {
      if (fbUser) {
        // User is signed in — load their profile from Firestore
        
        try {
          let profile = await fbGetUserProfile(fbUser.uid);
          if (!profile) {
            // Profile doesn't exist yet — create it (edge case: user deleted doc)
            profile = {
              uid: fbUser.uid, name: fbUser.displayName || 'User',
              username: fbUser.email.split('@')[0], email: fbUser.email,
              role: 'student', // will be overridden by profile role from storage
              classSection: '10', createdAt: Date.now()
            };
            await fbSaveUserProfile(fbUser.uid, profile);
          }
          currentUser = {
            uid: fbUser.uid, username: profile.username,
            name: profile.name, email: profile.email,
            classSection: profile.classSection, role: profile.role
          };
          // Load user data (files, questions, history)
          const userData = await fbGetUserData(fbUser.uid);
          _cache.userData[fbUser.uid] = userData;
          // Load all rooms
          await fbGetRooms();
          
          setAuthLoading(false);
          enterApp();
        } catch(e) {
          
          console.error('Profile load error:', e);
          showToast('⚠️ Error loading profile', 'error');
        }
      } else {
        // Not signed in — show auth screen
        currentUser = null;
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('appShell').style.display   = 'none';
        setAuthLoading(false);
      }
    });
  } catch(e) {
    // Firebase init failed — show config error
    if(hint) hint.textContent = '⚠️ Firebase not configured — see setup guide';
    console.error('Firebase init error:', e);
    showFirebaseSetupModal();
  }
}

// ── Firebase Setup Guide Modal ────────────────────────────────────────────────
function showFirebaseSetupModal() {
  const existing = document.getElementById('fbSetupModal');
  if(existing) { existing.style.display = 'flex'; return; }
  const modal = document.createElement('div');
  modal.id = 'fbSetupModal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:2000;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(6px)';
  modal.innerHTML = `
    <div style="background:#161b27;border:1px solid rgba(124,58,237,.4);border-radius:20px;padding:32px;max-width:560px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,.8)">
      <div style="text-align:center;margin-bottom:24px">
        <div style="font-size:2.5rem;margin-bottom:10px">🔥</div>
        <h2 style="font-family:'Sora',sans-serif;font-size:1.4rem;font-weight:800;color:#fff;margin-bottom:6px">Firebase Setup Required</h2>
        <p style="color:#9aa0b4;font-size:.9rem">Connect StudyHub to Firebase to enable real accounts, cloud sync, and live rooms.</p>
      </div>
      <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:24px">
        ${[
          ['1','Create Firebase Project','Go to <a href="https://console.firebase.google.com" target="_blank" style="color:#8b5cf6">console.firebase.google.com</a> → Add project → name it <strong>studyhub-class10</strong>'],
          ['2','Enable Authentication','Firebase Console → Authentication → Sign-in method → Enable <strong>Email/Password</strong>'],
          ['3','Enable Firestore','Firebase Console → Firestore Database → Create database → Start in <strong>test mode</strong>'],
          ['4','Get Config','Project Settings → Your apps → Add Web App → Copy the <strong>firebaseConfig</strong> object'],
          ['5','Paste Config','In this HTML file, replace the <code style="background:rgba(124,58,237,.15);padding:2px 6px;border-radius:4px;font-size:.82rem">FIREBASE_CONFIG</code> object near line 2030 with your config'],
          ['6','Deploy (optional)','Run <code style="background:rgba(124,58,237,.15);padding:2px 6px;border-radius:4px;font-size:.82rem">firebase deploy</code> to host on Firebase Hosting']
        ].map(([n,title,desc]) => `
          <div style="display:flex;gap:14px;padding:14px;background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.18);border-radius:12px;align-items:flex-start">
            <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.82rem;font-weight:800;flex-shrink:0">${n}</div>
            <div>
              <div style="font-weight:700;color:#e8eaf6;margin-bottom:3px">${title}</div>
              <div style="font-size:.82rem;color:#9aa0b4;line-height:1.5">${desc}</div>
            </div>
          </div>`).join('')}
      </div>
      <div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);border-radius:12px;padding:14px;margin-bottom:20px">
        <div style="font-size:.82rem;font-weight:700;color:#4ade80;margin-bottom:6px">📋 Firestore Security Rules</div>
        <pre style="font-size:.75rem;color:#9aa0b4;margin:0;line-height:1.5;overflow-x:auto">rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /users/{uid} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == uid;
    }
    match /userData/{uid} {
      allow read, write: if request.auth.uid == uid;
    }
    match /rooms/{rid} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    match /adminLog/{lid} {
      allow read, write: if request.auth != null;
    }
  }
}</pre>
      </div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <a href="https://console.firebase.google.com" target="_blank" class="btn btn-primary" style="text-decoration:none">🔥 Open Firebase Console</a>
        <a href="https://firebase.google.com/docs/hosting" target="_blank" class="btn btn-secondary" style="text-decoration:none">📖 Hosting Docs</a>
        <button class="btn btn-secondary" onclick="document.getElementById('fbSetupModal').style.display='none'">✕ Close</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}


// ═══════════════════════════════════════════════════════════════════════════════
// MOBILE NAV
// ═══════════════════════════════════════════════════════════════════════════════
function toggleMobileNav(){
  const nav=document.getElementById('mainNav');
  const overlay=document.getElementById('navOverlay');
  const open=nav.classList.toggle('mobile-open');
  overlay.classList.toggle('open',open);
}
function closeMobileNav(){
  document.getElementById('mainNav').classList.remove('mobile-open');
  document.getElementById('navOverlay').classList.remove('open');
}
// Close nav on page switch (mobile)

// ═══════════════════════════════════════════════════════════════════════════════
// AI QUIZ GENERATOR PAGE
// ═══════════════════════════════════════════════════════════════════════════════
let quizGenQuestions = [], quizGenIdx = 0, quizGenAnswers = {}, quizGenActive = false;

function initAIQuizPage() {
  const subj = document.getElementById('aqgSubject');
  const chap = document.getElementById('aqgChapter');
  const keyEl = document.getElementById('aqgApiKey');
  if (!subj) return;
  // Use hardcoded key — hide the input field if present
  if (keyEl) {
    keyEl.value = GEMINI_API_KEY;
    const keyRow = keyEl.closest('.form-group') || keyEl.parentElement;
    if (keyRow) keyRow.style.display = 'none';
  }
  subj.innerHTML = Object.keys(SUBJECTS_CHAPTERS).map(s=>`<option>${s}</option>`).join('');
  subj.onchange = () => {
    const chs = SUBJECTS_CHAPTERS[subj.value] || [];
    chap.innerHTML = `<option value="">All Chapters</option>` + chs.map(c=>`<option>${c}</option>`).join('');
  };
  subj.onchange();
}

async function generateAIQuiz() {
  const subj = document.getElementById('aqgSubject').value;
  const chap = document.getElementById('aqgChapter').value || 'any chapter';
  const diff = document.getElementById('aqgDiff').value;
  const cnt  = parseInt(document.getElementById('aqgCount').value) || 5;

  const keyInput = document.getElementById('aqgApiKey');
  // Key handled server-side via proxy
  if (keyInput) keyInput.closest && keyInput.closest('.form-group') && (keyInput.closest('.form-group').style.display='none');

  document.getElementById('aqgSetup').style.display    = 'none';
  document.getElementById('aqgLoading').style.display  = '';
  document.getElementById('aqgQuiz').style.display     = 'none';
  document.getElementById('aqgResult').style.display   = 'none';

  const diffText = diff === 'mixed' ? 'a mix of easy, medium, and hard' : diff;
  const prompt = `You are a Class 10 CBSE exam expert. Generate exactly ${cnt} multiple-choice questions for subject "${subj}", chapter "${chap}". Difficulty: ${diffText}.
Return ONLY a valid JSON array (no markdown, no backticks):
[{"question":"...","options":["A","B","C","D"],"answer":0,"difficulty":"easy","explanation":"..."}]
Rules: answer is 0-based index, all 4 options distinct, CBSE Class 10 syllabus only.`;

  try {
    const res = await fetch(GEMINI_URL,{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.7,maxOutputTokens:4096}})
    });
    if (!res.ok) throw new Error(`API Error ${res.status}`);
    const data = await res.json();
    const raw  = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const cleaned = raw.replace(/```json[\s\S]*?```|```[\s\S]*?```/g,'').trim();
    const match = cleaned.match(/\[[\s\S]*\]/);
    if (!match) throw new Error('Unexpected format');
    const parsed = JSON.parse(match[0]);
    if (!Array.isArray(parsed) || !parsed.length) throw new Error('No questions returned');
    quizGenQuestions = parsed.map((q,i)=>({...q, id:i}));
    quizGenIdx = 0; quizGenAnswers = {}; quizGenActive = true;
    document.getElementById('aqgLoading').style.display = 'none';
    renderAIQuiz();
    showToast(`✨ ${quizGenQuestions.length} questions generated!`,'ai');
  } catch(e) {
    document.getElementById('aqgLoading').style.display  = 'none';
    document.getElementById('aqgSetup').style.display    = '';
    showToast('❌ ' + e.message,'error');
  }
}

function renderAIQuiz() {
  const area = document.getElementById('aqgQuiz');
  area.style.display = '';
  const q = quizGenQuestions[quizGenIdx];
  if (!q) { finishAIQuiz(); return; }
  const chosen = quizGenAnswers[quizGenIdx];
  const total  = quizGenQuestions.length;
  const pct    = Math.round((quizGenIdx / total) * 100);

  area.innerHTML = `
    <div style="margin-bottom:18px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:6px">
        <span style="font-size:.8rem;color:var(--muted);font-weight:600">Question ${quizGenIdx+1} of ${total}</span>
        <span style="font-size:.75rem;padding:3px 10px;border-radius:20px;background:rgba(139,92,246,.15);color:#c084fc">${q.difficulty||'medium'}</span>
      </div>
      <div style="height:5px;background:var(--border);border-radius:20px;overflow:hidden;margin-bottom:16px">
        <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,#8b5cf6,#ec4899);border-radius:20px;transition:width .4s"></div>
      </div>
      <div style="font-size:1.05rem;font-weight:700;color:var(--text);line-height:1.5;margin-bottom:18px">${q.question}</div>
      <div style="display:flex;flex-direction:column;gap:9px">
        ${(q.options||[]).map((opt,i)=>{
          let bg='var(--surface2)'; let border='var(--border)'; let color='var(--text)';
          if(chosen!==undefined){
            if(i===q.answer){bg='rgba(16,185,129,.12)';border='#2ea043';color='#34d399';}
            else if(i===chosen&&i!==q.answer){bg='rgba(244,63,94,.1)';border='#da3633';color='#f87171';}
          }
          const icon = chosen!==undefined ? (i===q.answer?'✅ ':i===chosen?'❌ ':' ') : '';
          return `<button onclick="aqgAnswer(${i})" ${chosen!==undefined?'disabled':''} style="text-align:left;padding:12px 16px;border-radius:10px;border:1px solid ${border};background:${bg};color:${color};cursor:${chosen!==undefined?'default':'pointer'};font-size:.9rem;font-family:'Inter',sans-serif;transition:.15s">${icon}<strong>${'ABCD'[i]}.</strong> ${opt}</button>`;
        }).join('')}
      </div>
      ${chosen!==undefined ? `
        <div style="margin-top:14px;background:rgba(139,92,246,.1);border:1px solid rgba(139,92,246,.25);border-radius:10px;padding:12px 14px;font-size:.85rem;color:#c4b5fd">
          💡 <strong>Explanation:</strong> ${q.explanation||'See above.'}
        </div>
        <div style="margin-top:14px;text-align:right">
          <button onclick="aqgNext()" class="btn btn-primary">${quizGenIdx+1<total?'Next Question →':'See Results 🏆'}</button>
        </div>
      ` : ''}
    </div>
  `;
}

function aqgAnswer(optIdx) {
  if (quizGenAnswers[quizGenIdx] !== undefined) return;
  quizGenAnswers[quizGenIdx] = optIdx;
  renderAIQuiz();
}
function aqgNext() {
  quizGenIdx++;
  if (quizGenIdx >= quizGenQuestions.length) { finishAIQuiz(); return; }
  renderAIQuiz();
}
function finishAIQuiz() {
  document.getElementById('aqgQuiz').style.display = 'none';
  const correct = quizGenQuestions.filter((q,i) => quizGenAnswers[i] === q.answer).length;
  const total   = quizGenQuestions.length;
  const pct     = Math.round((correct/total)*100);
  const grade   = pct>=80?'🏆 Excellent!':pct>=60?'👍 Good!':pct>=40?'📚 Keep Practising':'💪 Try Again';
  const result  = document.getElementById('aqgResult');
  result.style.display = '';
  result.innerHTML = `
    <div style="text-align:center;padding:32px 20px">
      <div style="font-size:3rem;margin-bottom:10px">${grade.split(' ')[0]}</div>
      <h2 style="font-size:1.6rem;font-weight:800;margin-bottom:6px">${pct}%</h2>
      <p style="color:var(--muted);margin-bottom:6px">${correct} out of ${total} correct</p>
      <p style="font-size:1rem;font-weight:600;color:#c084fc;margin-bottom:24px">${grade.split(' ').slice(1).join(' ')}</p>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="document.getElementById('aqgSetup').style.display='';document.getElementById('aqgResult').style.display='none'">🔄 New Quiz</button>
        <button class="btn btn-secondary" onclick="reviewAIQuiz()">📋 Review Answers</button>
      </div>
    </div>
    <div id="aqgReview" style="display:none;margin-top:16px"></div>
  `;
}
function reviewAIQuiz() {
  const rev = document.getElementById('aqgReview');
  rev.style.display = rev.style.display==='none'?'':'none';
  if (rev.innerHTML) return;
  rev.innerHTML = quizGenQuestions.map((q,i)=>{
    const ua = quizGenAnswers[i];
    const ok = ua === q.answer;
    return `<div style="background:var(--surface2);border:1px solid ${ok?'rgba(16,185,129,.3)':'rgba(244,63,94,.3)'};border-radius:10px;padding:14px;margin-bottom:10px">
      <div style="font-size:.75rem;color:var(--muted);margin-bottom:4px">Q${i+1} · ${ok?'<span style="color:#34d399">✅ Correct</span>':'<span style="color:#f87171">❌ Wrong</span>'}</div>
      <div style="font-weight:600;margin-bottom:8px">${q.question}</div>
      <div style="font-size:.84rem;color:#34d399">✅ ${q.options[q.answer]}</div>
      ${!ok&&ua!==undefined?`<div style="font-size:.84rem;color:#f87171">Your answer: ${q.options[ua]}</div>`:''}
      ${q.explanation?`<div style="font-size:.78rem;color:var(--muted);margin-top:6px">💡 ${q.explanation}</div>`:''}
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMING SOON FEATURES UPDATE
// ═══════════════════════════════════════════════════════════════════════════════
function renderComingSoonStatus() {
  const el = document.getElementById('comingSoonStatus');
  if (!el) return;
  const features = [
    { icon:'🌐', name:'Live Cloud Hosting', desc:'Deploy on Vercel/Netlify — zero-setup URL sharing', status:'planned', color:'#f59e0b' },
    { icon:'🔌', name:'Backend REST API', desc:'Node.js + Express backend for real-time data sync', status:'planned', color:'#6366f1' },
    { icon:'⚡', name:'WebSocket Multiplayer', desc:'True real-time rooms powered by Socket.io', status:'planned', color:'#06b6d4' },
    { icon:'🧠', name:'AI Quiz Generator (Live)', desc:'Already live! Generate quizzes with Gemini Pro', status:'live', color:'#10b981' },
    { icon:'📱', name:'Mobile Responsive', desc:'Optimised for phones and tablets', status:'live', color:'#10b981' },
    { icon:'🔐', name:'OAuth Login', desc:'Sign in with Google / GitHub accounts', status:'planned', color:'#f59e0b' },
    { icon:'📊', name:'Analytics Dashboard', desc:'Class-wide stats, leaderboards, teacher view', status:'planned', color:'#f59e0b' },
  ];
  el.innerHTML = features.map(f=>`
    <div style="display:flex;align-items:center;gap:14px;padding:13px 16px;background:var(--surface2);border:1px solid var(--border);border-radius:12px;margin-bottom:9px;transition:.15s" onmouseenter="this.style.borderColor='${f.color}40'" onmouseleave="this.style.borderColor='var(--border)'">
      <span style="font-size:1.5rem;flex-shrink:0">${f.icon}</span>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:.9rem;margin-bottom:2px">${f.name}</div>
        <div style="font-size:.78rem;color:var(--muted)">${f.desc}</div>
      </div>
      <span style="font-size:.72rem;font-weight:700;padding:3px 10px;border-radius:20px;white-space:nowrap;background:${f.status==='live'?'rgba(16,185,129,.15)':'rgba(245,158,11,.12)'};color:${f.status==='live'?'#34d399':'#fbbf24'};border:1px solid ${f.status==='live'?'rgba(16,185,129,.25)':'rgba(245,158,11,.2)'}">
        ${f.status==='live'?'✅ Live':'🔜 Planned'}
      </span>
    </div>`).join('');
}

// [showPage patching handled in patch script]
