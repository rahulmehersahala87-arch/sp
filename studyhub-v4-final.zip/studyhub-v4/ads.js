// ═══════════════════════════════════════════════════════════════════════
//  StudyHub — Ads Manager
//  Rules:
//  ✅ Show ads  → logged-in FREE user (no active premium plan)
//  ❌ Hide ads  → Premium user (Silver / Gold / Diamond)
//  ❌ Hide ads  → Not logged in (no local user session)
// ═══════════════════════════════════════════════════════════════════════

function getLocalPremiumPlan() {
  try {
    const v = localStorage.getItem('sh_premium_status');
    if (!v) return null;
    const parsed = JSON.parse(v);
    return (parsed && parsed.plan) ? parsed.plan : null;
  } catch { return null; }
}

function isLoggedInLocally() {
  try {
    // app.js stores current user info in localStorage
    const u = localStorage.getItem('sh_current_user_profile')
           || localStorage.getItem('sh_userData')
           || localStorage.getItem('sh_user');
    return !!u;
  } catch { return false; }
}

function shouldShowAds() {
  const loggedIn  = isLoggedInLocally();
  const isPremium = !!getLocalPremiumPlan();

  // Only show ads if: logged in AND not premium
  return loggedIn && !isPremium;
}

function showAllAds() {
  document.querySelectorAll('.sh-ad-banner, .sh-ad-footer, .sh-ad-inline').forEach(el => {
    el.style.display = '';
  });
  // Push AdSense units (safe — ignores already-pushed units)
  try {
    document.querySelectorAll('.adsbygoogle:not([data-ad-status])').forEach(() => {
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
    });
  } catch(e) {}
}

function hideAllAds() {
  document.querySelectorAll('.sh-ad-banner, .sh-ad-footer, .sh-ad-inline').forEach(el => {
    el.style.display = 'none';
  });
}

function initAds() {
  if (shouldShowAds()) {
    showAllAds();
  } else {
    hideAllAds();
  }
}

// ── Re-check when user logs in or premium is activated ────────────────
// Poll every 2s for auth/premium state changes
let _adsPollCount = 0;
const _adsPoll = setInterval(() => {
  _adsPollCount++;
  initAds();
  if (_adsPollCount > 30) clearInterval(_adsPoll); // stop after 60s
}, 2000);

// Hide immediately when premium is activated
window.addEventListener('premiumActivated', hideAllAds);

// Patch applyPremiumBenefits to hide ads instantly on upgrade
window.addEventListener('load', function() {
  const orig = window.applyPremiumBenefits;
  if (typeof orig === 'function') {
    window.applyPremiumBenefits = function(planId) {
      orig.call(this, planId);
      hideAllAds(); // instant hide
    };
  }
});

// Initial call
if (document.readyState !== 'loading') {
  initAds();
} else {
  document.addEventListener('DOMContentLoaded', initAds);
}

// Expose for external use
window.hideAllAds = hideAllAds;
window.showAllAds = showAllAds;
window.initAds    = initAds;
