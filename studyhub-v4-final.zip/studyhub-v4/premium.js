// ═══════════════════════════════════════════════════════════════════════
//  StudyHub — Paid Rank Promotion System
//  Flow: Student picks plan → sees UPI QR → uploads screenshot →
//        Razorpay webhook (or admin) auto-confirms → rank upgraded
// ═══════════════════════════════════════════════════════════════════════

// ── Plan definitions ─────────────────────────────────────────────────
const PREMIUM_PLANS = [
  {
    id: 'silver',
    name: 'Silver Scholar',
    badge: '🥈',
    color: '#94a3b8',
    gradient: 'linear-gradient(135deg,#64748b,#94a3b8)',
    price: 49,
    xpBonus: 500,
    perks: [
      'Silver badge on profile & leaderboard',
      '+500 XP instant boost',
      'Access to Premium Notes library',
      'Ad-free experience',
    ],
    popular: false,
  },
  {
    id: 'gold',
    name: 'Gold Champion',
    badge: '🥇',
    color: '#f59e0b',
    gradient: 'linear-gradient(135deg,#d97706,#f59e0b)',
    price: 99,
    xpBonus: 1500,
    perks: [
      'Gold badge on profile & leaderboard',
      '+1500 XP instant boost',
      'Access to Premium Notes library',
      'Priority AI Tutor responses',
      'Ad-free experience',
      'Weekly performance report',
    ],
    popular: true,
  },
  {
    id: 'diamond',
    name: 'Diamond Elite',
    badge: '💎',
    color: '#22d3ee',
    gradient: 'linear-gradient(135deg,#0891b2,#22d3ee)',
    price: 199,
    xpBonus: 5000,
    perks: [
      'Diamond badge on profile & leaderboard',
      '+5000 XP instant boost',
      'Full Premium Notes library',
      'Unlimited AI Tutor chats',
      'Ad-free experience',
      'Custom profile frame',
      'Early access to new features',
      'Direct admin support',
    ],
    popular: false,
  },
];

// ── Admin UPI config (set by admin in settings) ───────────────────────
// ── Hard-coded UPI defaults (never null) ─────────────────────────────
const DEFAULT_UPI_ID   = '7848818648@fam';
const DEFAULT_UPI_NAME = 'studyhub';
const DEFAULT_UPI_NOTE = 'StudyHub Premium Upgrade';

function getUpiConfig() {
  try {
    const id   = (typeof LS !== 'undefined' && LS.get('admin_upi_id',   null)) || DEFAULT_UPI_ID;
    const name = (typeof LS !== 'undefined' && LS.get('admin_upi_name', null)) || DEFAULT_UPI_NAME;
    const note = (typeof LS !== 'undefined' && LS.get('admin_upi_note', null)) || DEFAULT_UPI_NOTE;
    return { upiId: id || DEFAULT_UPI_ID, name: name || DEFAULT_UPI_NAME, qrNote: note || DEFAULT_UPI_NOTE };
  } catch {
    return { upiId: DEFAULT_UPI_ID, name: DEFAULT_UPI_NAME, qrNote: DEFAULT_UPI_NOTE };
  }
}

// ── Premium state helpers ─────────────────────────────────────────────
function getPremiumStatus() {
  try { return LS.get('premium_status', null) || { plan: null, since: null, xpGranted: false }; } catch { return { plan: null, since: null, xpGranted: false }; }
}

function isPremium() {
  try { const s = getPremiumStatus(); return !!(s && s.plan); } catch { return false; }
}

function getCurrentPlan() {
  try { const s = getPremiumStatus(); const id = s && s.plan; return id ? (PREMIUM_PLANS.find(p => p.id === id) || null) : null; } catch { return null; }
}

// ── Pending payment requests ──────────────────────────────────────────
function getPendingPayments() {
  return LS.get('pending_payments', []);
}

function savePendingPayment(req) {
  const list = getPendingPayments();
  list.unshift(req);
  LS.set('pending_payments', list.slice(0, 50));
}

// ── Apply premium benefits ────────────────────────────────────────────
function applyPremiumBenefits(planId) {
  const plan = PREMIUM_PLANS.find(p => p.id === planId);
  if (!plan) return;

  // 1. Save status
  LS.set('premium_status', { plan: planId, since: Date.now(), xpGranted: true });

  // 2. XP boost
  const profile = LS.get('current_user_profile', {});
  profile.xp = (profile.xp || 0) + plan.xpBonus;
  LS.set('current_user_profile', profile);

  // 3. Notification
  if (window.addNotification) {
    addNotification('🎉', `${plan.badge} ${plan.name} Activated!`,
      `Welcome to ${plan.name}! You received +${plan.xpBonus.toLocaleString()} XP and unlocked all premium perks.`, 'success');
  }

  // 4. Update UI
  updatePremiumBadgeUI();

  // 5. Fire event so ads.js hides ads instantly
  window.dispatchEvent(new Event('premiumActivated'));

  if (window.showToast) showToast(`${plan.badge} ${plan.name} activated! +${plan.xpBonus.toLocaleString()} XP`, 'success');
}

// ── Simulate Razorpay webhook (for UPI manual flow) ───────────────────
// In production: your server receives Razorpay webhook → updates Firestore
// Here: we verify payment ID pattern and auto-approve after a short delay
function simulateWebhookVerification(paymentRef, planId, onSuccess, onFail) {
  // In a real deployment, POST to your backend:
  // fetch('/api/verify-payment', { method:'POST', body: JSON.stringify({paymentRef, planId}) })
  // For now: auto-approve if reference looks valid (12+ chars)
  setTimeout(() => {
    if (paymentRef && paymentRef.trim().length >= 8) {
      onSuccess();
    } else {
      onFail('Invalid payment reference. Please enter your UTR/transaction ID.');
    }
  }, 2000);
}

// ═══════════════════ PREMIUM PAGE ════════════════════════════════════
function renderPremiumPage() {
  const page = document.getElementById('premium');
  if (!page) return;
  // Guard: LS must be available (defined in app.js)
  if (typeof LS === 'undefined') { setTimeout(renderPremiumPage, 100); return; }

  let status, activePlan;
  try { status = getPremiumStatus(); activePlan = getCurrentPlan(); }
  catch(e) { status = { plan: null }; activePlan = null; }

  if (activePlan) {
    renderPremiumActivePage(activePlan);
    return;
  }

  page.innerHTML = `
    <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#f59e0b">💎 PREMIUM</div>
    <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin-bottom:6px">Upgrade Your <span style="background:linear-gradient(135deg,#f59e0b,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Rank</span></h1>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:28px">Unlock premium badges, XP boosts, and exclusive study materials. One-time payment via UPI.</p>

    <!-- Plans grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-bottom:28px" id="plansGrid">
      ${PREMIUM_PLANS.map(plan => `
        <div class="plan-card ${plan.popular ? 'plan-popular' : ''}" id="plan-${plan.id}" onclick="selectPlan('${plan.id}')">
          ${plan.popular ? '<div class="plan-popular-badge">⭐ Most Popular</div>' : ''}
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
            <div style="width:52px;height:52px;border-radius:14px;background:${plan.gradient};display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">${plan.badge}</div>
            <div>
              <div style="font-weight:800;font-size:1.05rem;color:#e2e8f0">${plan.name}</div>
              <div style="font-size:.8rem;color:${plan.color};font-weight:600">+${plan.xpBonus.toLocaleString()} XP Boost</div>
            </div>
          </div>
          <div style="font-size:2.2rem;font-weight:900;color:#e2e8f0;margin-bottom:4px">₹${plan.price}</div>
          <div style="font-size:.75rem;color:#64748b;margin-bottom:18px">One-time payment</div>
          <div style="display:flex;flex-direction:column;gap:7px;margin-bottom:20px">
            ${plan.perks.map(p => `
              <div style="display:flex;align-items:flex-start;gap:8px;font-size:.83rem;color:#94a3b8">
                <span style="color:#22c55e;flex-shrink:0;margin-top:1px">✓</span>
                <span>${p}</span>
              </div>
            `).join('')}
          </div>
          <button class="plan-btn" style="background:${plan.gradient}" onclick="event.stopPropagation();openPaymentModal('${plan.id}')">
            ${plan.badge} Get ${plan.name}
          </button>
        </div>
      `).join('')}
    </div>

    <!-- Trust badges -->
    <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-bottom:24px">
      ${['🔒 Secure UPI Payment','⚡ Instant Activation','💬 24h Support','♾️ Lifetime Access'].map(b => `
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:99px;padding:7px 16px;font-size:.78rem;color:#94a3b8">${b}</div>
      `).join('')}
    </div>

    <!-- FAQ -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:24px;max-width:600px">
      <div style="font-weight:700;margin-bottom:14px">❓ Frequently Asked Questions</div>
      ${[
        ['Is this a one-time payment?', 'Yes! Pay once, enjoy premium benefits forever. No subscriptions.'],
        ['How fast is activation?', 'Automatic within 60 seconds of payment via UPI.'],
        ['What is UTR number?', 'UTR (Unique Transaction Reference) is shown in your UPI app after payment. It\'s typically 12 digits.'],
        ['Can I upgrade later?', 'Yes! You can upgrade from Silver → Gold → Diamond anytime, paying only the difference.'],
        ['Refund policy?', 'Contact admin within 24 hours of payment if there\'s any issue.'],
      ].map(([q, a]) => `
        <div style="margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.06);last-child:border-none">
          <div style="font-weight:600;font-size:.88rem;color:#e2e8f0;margin-bottom:4px">${q}</div>
          <div style="font-size:.82rem;color:#64748b;line-height:1.5">${a}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function renderPremiumActivePage(plan) {
  const page = document.getElementById('premium');
  const status = getPremiumStatus();
  const since = status.since ? new Date(status.since).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' }) : 'N/A';
  const planOrder = ['silver','gold','diamond'];
  const currentIdx = planOrder.indexOf(plan.id);
  const upgradePlans = PREMIUM_PLANS.filter(p => planOrder.indexOf(p.id) > currentIdx);

  page.innerHTML = `
    <div style="margin-bottom:6px;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#f59e0b">💎 PREMIUM</div>
    <h1 style="font-size:2rem;font-weight:800;color:#e2e8f0;margin-bottom:20px">My <span style="background:linear-gradient(135deg,#f59e0b,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Premium</span></h1>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:24px">
      <!-- Current plan card -->
      <div style="background:${plan.gradient};border-radius:22px;padding:24px;position:relative;overflow:hidden">
        <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(0,0,0,.2),rgba(0,0,0,.05))"></div>
        <div style="position:relative">
          <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,.7);margin-bottom:12px">✅ CURRENT PLAN</div>
          <div style="font-size:3rem;margin-bottom:8px">${plan.badge}</div>
          <div style="font-size:1.3rem;font-weight:900;color:#fff;margin-bottom:4px">${plan.name}</div>
          <div style="font-size:.82rem;color:rgba(255,255,255,.75)">Active since ${since}</div>
          <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px">
            ${plan.perks.map(p => `<div style="font-size:.78rem;color:rgba(255,255,255,.85);display:flex;gap:6px"><span>✓</span><span>${p}</span></div>`).join('')}
          </div>
        </div>
      </div>

      <!-- Perks summary -->
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:22px;padding:24px">
        <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#22c55e;margin-bottom:14px">🎁 YOUR BENEFITS</div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;padding:10px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:10px">
          <span style="font-size:1.5rem">⚡</span>
          <div>
            <div style="font-weight:700;color:#fbbf24">+${plan.xpBonus.toLocaleString()} XP Boost</div>
            <div style="font-size:.75rem;color:#64748b">Added to your account</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;padding:10px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:10px">
          <span style="font-size:1.5rem">📚</span>
          <div>
            <div style="font-weight:700;color:#86efac">Premium Notes Unlocked</div>
            <div style="font-size:.75rem;color:#64748b">Access exclusive study materials</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(6,182,212,.08);border:1px solid rgba(6,182,212,.2);border-radius:10px">
          <span style="font-size:1.5rem">🚫</span>
          <div>
            <div style="font-weight:700;color:#67e8f9">Ad-Free Experience</div>
            <div style="font-size:.75rem;color:#64748b">Clean, distraction-free studying</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Upgrade plans (show plans above current) -->
    ${upgradePlans.length > 0 ? `
      <div style="margin-bottom:10px;font-weight:700;font-size:1rem;color:#e2e8f0">⬆️ Upgrade Your Rank</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:14px;margin-bottom:24px">
        ${upgradePlans.map(up => `
          <div class="plan-card ${up.popular ? 'plan-popular' : ''}" style="position:relative">
            ${up.popular ? '<div class="plan-popular-badge">⭐ Most Popular</div>' : ''}
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
              <div style="width:46px;height:46px;border-radius:12px;background:${up.gradient};display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0">${up.badge}</div>
              <div>
                <div style="font-weight:800;font-size:1rem;color:#e2e8f0">${up.name}</div>
                <div style="font-size:.78rem;color:${up.color};font-weight:600">+${up.xpBonus.toLocaleString()} XP</div>
              </div>
            </div>
            <div style="font-size:1.8rem;font-weight:900;color:#e2e8f0;margin-bottom:3px">₹${up.price}</div>
            <div style="font-size:.73rem;color:#64748b;margin-bottom:14px">One-time · Lifetime access</div>
            <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:16px">
              ${up.perks.map(p => `<div style="font-size:.8rem;color:#94a3b8;display:flex;gap:7px"><span style="color:#22c55e">✓</span><span>${p}</span></div>`).join('')}
            </div>
            <button class="plan-btn" style="background:${up.gradient}" onclick="openPaymentModal('${up.id}')">
              ${up.badge} Upgrade to ${up.name}
            </button>
          </div>
        `).join('')}
      </div>
    ` : `
      <div style="background:rgba(34,211,238,.06);border:1px solid rgba(34,211,238,.2);border-radius:16px;padding:20px;text-align:center;color:#22d3ee;font-weight:700;font-size:1.05rem">
        💎 You're on Diamond Elite — the highest tier! Nothing to upgrade.
      </div>
    `}
  `;
}

// ═══════════════════ PAYMENT MODAL ═══════════════════════════════════
let _currentPayPlan = null;
let _payStep = 1; // 1=QR, 2=verify, 3=success

function openPaymentModal(planId) {
  _currentPayPlan = PREMIUM_PLANS.find(p => p.id === planId);
  if (!_currentPayPlan) return;
  _payStep = 1;
  const modal = document.getElementById('paymentModal');
  if (modal) { modal.classList.add('open'); renderPaymentStep(); }
}

function closePaymentModal() {
  const modal = document.getElementById('paymentModal');
  if (modal) modal.classList.remove('open');
  _payStep = 1;
}

function renderPaymentStep() {
  const body = document.getElementById('paymentModalBody');
  if (!body || !_currentPayPlan) return;
  const plan = _currentPayPlan;
  const upi = getUpiConfig();

  if (_payStep === 1) {
    // Generate UPI deep link
    const upiLink = `upi://pay?pa=${encodeURIComponent(upi.upiId)}&pn=${encodeURIComponent(upi.name)}&am=${plan.price}&cu=INR&tn=${encodeURIComponent(upi.qrNote + ' ' + plan.name)}`;
    // QR via Google Charts API
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}&bgcolor=1a1040&color=c4b5fd&margin=10`;

    body.innerHTML = `
      <div style="text-align:center">
        <div style="display:inline-flex;align-items:center;gap:10px;background:${plan.gradient};border-radius:12px;padding:10px 20px;margin-bottom:20px">
          <span style="font-size:1.4rem">${plan.badge}</span>
          <span style="font-weight:800;color:#fff">${plan.name} — ₹${plan.price}</span>
        </div>

        <!-- QR Code -->
        <div style="background:rgba(255,255,255,.05);border:2px solid rgba(124,58,237,.3);border-radius:18px;padding:20px;display:inline-block;margin-bottom:16px">
          <img src="${qrUrl}" width="180" height="180" alt="UPI QR Code" style="border-radius:10px;display:block">
          <div style="font-size:.75rem;color:#94a3b8;margin-top:8px">Scan with any UPI app</div>
        </div>

        <!-- UPI ID manual -->
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px;margin-bottom:16px">
          <div style="font-size:.75rem;color:#64748b;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Or pay directly to UPI ID</div>
          <div style="font-size:1.05rem;font-weight:700;color:#8b5cf6;letter-spacing:.3px;cursor:pointer" onclick="copyUpiId()" title="Click to copy">
            ${upi.upiId} <span style="font-size:.7rem;color:#64748b">📋</span>
          </div>
          <div style="font-size:.72rem;color:#64748b;margin-top:4px">Name: ${upi.name} · Amount: ₹${plan.price}</div>
        </div>

        <!-- UPI apps -->
        <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:18px">
          ${[['GPay','https://pay.google.com/intl/en_in/about/'],['PhonePe','https://www.phonepe.com'],['Paytm','https://paytm.com'],['BHIM','https://www.bhimupi.org.in']].map(([name]) => `
            <a href="${upiLink}" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.78rem;color:#e2e8f0;text-decoration:none;font-weight:600">${name}</a>
          `).join('')}
        </div>

        <button onclick="goToVerifyStep()" style="width:100%;padding:13px;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;border-radius:12px;color:#fff;font-size:.95rem;font-weight:700;cursor:pointer">
          ✅ I've Paid — Verify Payment →
        </button>
        <div style="font-size:.75rem;color:#64748b;margin-top:10px">After paying, click above to enter your UTR/transaction ID</div>
      </div>
    `;
  }

  if (_payStep === 2) {
    body.innerHTML = `
      <div style="text-align:center">
        <div style="font-size:2.5rem;margin-bottom:12px">🔍</div>
        <h3 style="font-weight:800;font-size:1.1rem;margin-bottom:6px">Verify Your Payment</h3>
        <p style="color:#64748b;font-size:.85rem;margin-bottom:20px">Enter the UTR / Transaction ID from your UPI app to auto-activate your plan.</p>

        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:18px;margin-bottom:16px;text-align:left">
          <div style="font-size:.73rem;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">📱 Where to find UTR:</div>
          <div style="font-size:.83rem;color:#94a3b8;line-height:1.7">
            • <strong style="color:#e2e8f0">GPay:</strong> Tap transaction → "Transaction ID"<br>
            • <strong style="color:#e2e8f0">PhonePe:</strong> History → tap payment → UTR No.<br>
            • <strong style="color:#e2e8f0">Paytm:</strong> Passbook → transaction details<br>
            • <strong style="color:#e2e8f0">Bank SMS:</strong> Look for 12-digit UTR number
          </div>
        </div>

        <input id="utrInput" type="text" placeholder="Enter UTR / Transaction ID (min 8 chars)"
          style="width:100%;box-sizing:border-box;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:10px;color:#e2e8f0;padding:12px 14px;font-size:.9rem;margin-bottom:8px;font-family:monospace;letter-spacing:.5px"
          oninput="this.value=this.value.toUpperCase()">
        <div id="utrError" style="color:#ef4444;font-size:.8rem;min-height:18px;margin-bottom:10px;text-align:left"></div>

        <button onclick="submitPaymentVerification()" id="verifyBtn"
          style="width:100%;padding:13px;background:linear-gradient(135deg,#22c55e,#16a34a);border:none;border-radius:12px;color:#fff;font-size:.95rem;font-weight:700;cursor:pointer;margin-bottom:10px">
          🚀 Verify & Activate Plan
        </button>
        <button onclick="_payStep=1;renderPaymentStep()" style="background:none;border:none;color:#64748b;font-size:.82rem;cursor:pointer;text-decoration:underline">← Back to QR code</button>
      </div>
    `;
  }

  if (_payStep === 3) {
    body.innerHTML = `
      <div style="text-align:center;padding:20px 0">
        <div style="font-size:4rem;margin-bottom:16px;animation:bounceIn .5s ease">${plan.badge}</div>
        <h2 style="font-size:1.5rem;font-weight:900;color:#e2e8f0;margin-bottom:8px">🎉 Congratulations!</h2>
        <p style="color:#94a3b8;font-size:.9rem;margin-bottom:20px"><strong style="color:${plan.color}">${plan.name}</strong> has been activated on your account.</p>

        <div style="background:${plan.gradient};border-radius:16px;padding:16px;margin-bottom:20px">
          <div style="color:#fff;font-weight:700;font-size:1.1rem">+${plan.xpBonus.toLocaleString()} XP Added!</div>
          <div style="color:rgba(255,255,255,.8);font-size:.83rem;margin-top:3px">Check your profile to see your new rank</div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px">
          ${plan.perks.map(p => `
            <div style="background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.15);border-radius:9px;padding:8px 14px;font-size:.83rem;color:#86efac;text-align:left">✅ ${p}</div>
          `).join('')}
        </div>

        <button onclick="closePaymentModal();showPage('premium')" style="width:100%;padding:12px;background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;border-radius:12px;color:#fff;font-weight:700;cursor:pointer">
          View My Premium Profile →
        </button>
      </div>
    `;
  }
}

function goToVerifyStep() {
  _payStep = 2;
  renderPaymentStep();
}

function submitPaymentVerification() {
  const utrEl = document.getElementById('utrInput');
  const errEl = document.getElementById('utrError');
  const btn   = document.getElementById('verifyBtn');
  if (!utrEl || !_currentPayPlan) return;

  const utr = utrEl.value.trim();
  if (!utr || utr.length < 8) {
    if (errEl) errEl.textContent = '⚠️ Please enter a valid UTR / transaction ID (minimum 8 characters).';
    return;
  }
  if (errEl) errEl.textContent = '';

  // Save pending record
  const user = LS.get('current_user_profile', {});
  savePendingPayment({
    id: Date.now(),
    utr,
    planId: _currentPayPlan.id,
    planName: _currentPayPlan.name,
    amount: _currentPayPlan.price,
    user: user.name || user.username || 'Unknown',
    timestamp: new Date().toISOString(),
    status: 'pending',
  });

  // Show loading state
  if (btn) { btn.textContent = '⏳ Verifying…'; btn.disabled = true; }

  simulateWebhookVerification(
    utr,
    _currentPayPlan.id,
    () => {
      // Success
      applyPremiumBenefits(_currentPayPlan.id);
      _payStep = 3;
      renderPaymentStep();
      // Update pending record status
      const list = getPendingPayments();
      const rec = list.find(r => r.utr === utr);
      if (rec) { rec.status = 'approved'; LS.set('pending_payments', list); }
    },
    (msg) => {
      if (errEl) errEl.textContent = '❌ ' + msg;
      if (btn) { btn.textContent = '🚀 Verify & Activate Plan'; btn.disabled = false; }
    }
  );
}

function copyUpiId() {
  const upi = getUpiConfig();
  navigator.clipboard.writeText(upi.upiId).then(() => {
    if (window.showToast) showToast('UPI ID copied!', 'success');
  }).catch(() => {});
}

// ═══════════════════ ADMIN — PAYMENT MANAGEMENT ═══════════════════════
function renderAdminPayments() {
  const wrap = document.getElementById('adm-payments');
  if (!wrap) return;
  const payments = getPendingPayments();
  const upi = getUpiConfig();

  wrap.innerHTML = `
    <!-- UPI Config -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px;margin-bottom:18px">
      <div style="font-weight:700;margin-bottom:14px">⚙️ Your UPI Settings</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div>
          <label style="font-size:.75rem;color:#64748b;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px">UPI ID</label>
          <input id="adminUpiId" value="${upi.upiId || '7848818648@fam'}" class="form-input" placeholder="yourname@upi" style="width:100%;box-sizing:border-box">
        </div>
        <div>
          <label style="font-size:.75rem;color:#64748b;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.4px">Display Name</label>
          <input id="adminUpiName" value="${upi.name || 'studyhub'}" class="form-input" placeholder="Your Name" style="width:100%;box-sizing:border-box">
        </div>
      </div>
      <button onclick="saveUpiConfig()" style="background:linear-gradient(135deg,#7c3aed,#06b6d4);border:none;color:#fff;border-radius:10px;padding:9px 20px;font-weight:700;cursor:pointer">💾 Save UPI Settings</button>
      <span id="upiSaveMsg" style="font-size:.8rem;color:#22c55e;margin-left:10px;display:none">✅ Saved!</span>
    </div>

    <!-- Payment stats -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px">
      ${[
        { label: 'Total Payments', val: payments.length, color: '#8b5cf6' },
        { label: 'Approved', val: payments.filter(p=>p.status==='approved').length, color: '#22c55e' },
        { label: 'Pending', val: payments.filter(p=>p.status==='pending').length, color: '#f59e0b' },
        { label: 'Revenue (₹)', val: payments.filter(p=>p.status==='approved').reduce((a,p)=>a+p.amount,0), color: '#06b6d4' },
      ].map(s => `
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px">
          <div style="font-size:1.6rem;font-weight:800;color:${s.color}">${s.val}</div>
          <div style="font-size:.73rem;color:#64748b;text-transform:uppercase;letter-spacing:.4px;margin-top:3px">${s.label}</div>
        </div>
      `).join('')}
    </div>

    <!-- Payment table -->
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden">
      <div style="padding:14px 18px;border-bottom:1px solid var(--border);font-weight:700">📋 Payment Records</div>
      ${payments.length === 0 ? '<div style="padding:30px;text-align:center;color:#64748b">No payments yet</div>' : `
        <div style="overflow-x:auto">
          <table style="width:100%;border-collapse:collapse">
            <thead>
              <tr style="background:rgba(255,255,255,.03)">
                ${['Student','Plan','Amount','UTR / Ref','Date','Status','Action'].map(h=>`<th style="padding:10px 14px;text-align:left;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#475569">${h}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${payments.map(p => `
                <tr style="border-top:1px solid rgba(255,255,255,.04)">
                  <td style="padding:11px 14px;font-size:.85rem;color:#e2e8f0">${p.user}</td>
                  <td style="padding:11px 14px">
                    <span style="font-size:.8rem;font-weight:700;color:${PREMIUM_PLANS.find(pl=>pl.id===p.planId)?.color||'#94a3b8'}">${p.planName}</span>
                  </td>
                  <td style="padding:11px 14px;font-weight:600;color:#22c55e">₹${p.amount}</td>
                  <td style="padding:11px 14px;font-size:.78rem;font-family:monospace;color:#94a3b8">${p.utr}</td>
                  <td style="padding:11px 14px;font-size:.78rem;color:#64748b">${new Date(p.timestamp).toLocaleDateString('en-IN')}</td>
                  <td style="padding:11px 14px">
                    <span style="font-size:.72rem;font-weight:700;padding:3px 9px;border-radius:99px;${p.status==='approved'?'background:rgba(34,197,94,.15);color:#86efac':'background:rgba(245,158,11,.15);color:#fcd34d'}">${p.status}</span>
                  </td>
                  <td style="padding:11px 14px">
                    ${p.status==='pending' ? `<button onclick="adminApprovePayment('${p.utr}')" style="background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);color:#86efac;border-radius:7px;padding:4px 10px;cursor:pointer;font-size:.75rem;font-weight:600">✅ Approve</button>` : ''}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;
}

function saveUpiConfig() {
  const id = (document.getElementById('adminUpiId') || {}).value?.trim();
  const name = (document.getElementById('adminUpiName') || {}).value?.trim();
  if (id) LS.set('admin_upi_id', id);
  if (name) LS.set('admin_upi_name', name);
  const msg = document.getElementById('upiSaveMsg');
  if (msg) { msg.style.display = 'inline'; setTimeout(() => msg.style.display = 'none', 2500); }
}

function adminApprovePayment(utr) {
  const list = getPendingPayments();
  const rec = list.find(r => r.utr === utr);
  if (!rec) return;
  rec.status = 'approved';
  LS.set('pending_payments', list);
  applyPremiumBenefits(rec.planId);
  renderAdminPayments();
  if (window.showToast) showToast('Payment approved & plan activated!', 'success');
}

// ═══════════════════ PREMIUM BADGE ON PROFILE / LEADERBOARD ══════════
function updatePremiumBadgeUI() {
  if (typeof LS === 'undefined') return;
  let plan; try { plan = getCurrentPlan(); } catch { return; }
  if (!plan) return;

  // Inject badge into nav user card
  const navName = document.getElementById('navName');
  if (navName && !navName.querySelector('.premium-nav-badge')) {
    const span = document.createElement('span');
    span.className = 'premium-nav-badge';
    span.textContent = plan.badge;
    span.title = plan.name;
    span.style.cssText = 'margin-left:5px;font-size:.9rem';
    navName.appendChild(span);
  }

  // Inject into profile
  const profileName = document.getElementById('profileName');
  if (profileName && !profileName.querySelector('.premium-profile-badge')) {
    const span = document.createElement('span');
    span.className = 'premium-profile-badge';
    span.innerHTML = ` <span style="display:inline-flex;align-items:center;gap:4px;background:${plan.gradient};color:#fff;font-size:.7rem;font-weight:700;padding:2px 10px;border-radius:99px;vertical-align:middle">${plan.badge} ${plan.name}</span>`;
    profileName.appendChild(span);
  }
}

// ═══════════════════ PREMIUM CONTENT GATE ════════════════════════════
// Wrap any content that requires premium
function requiresPremium(action) {
  if (isPremium()) {
    action();
    return;
  }
  // Show upgrade nudge
  const modal = document.getElementById('premiumNudgeModal');
  if (modal) modal.classList.add('open');
}

// ═══════════════════ PATCH showPage ══════════════════════════════════
// Hook into showPage after all scripts load
window.addEventListener('load', function() {
  const orig = window.showPage;
  window.showPage = function(id) {
    if (orig) orig.call(this, id);
    if (id === 'premium') { setTimeout(renderPremiumPage, 50); }
    if (id === 'admin') {
      setTimeout(() => {
        const tabs = document.querySelector('.adm-tabs');
        if (tabs && !document.getElementById('adm-payments')) {
          const btn = document.createElement('button');
          btn.className = 'adm-tab';
          btn.innerHTML = '💳 Payments';
          btn.onclick = function() { admTab('payments', this); renderAdminPayments(); };
          tabs.appendChild(btn);
          const overview = document.getElementById('adm-overview');
          if (overview && overview.parentNode) {
            const div = document.createElement('div');
            div.className = 'adm-section';
            div.id = 'adm-payments';
            overview.parentNode.appendChild(div);
          }
        }
      }, 150);
    }
  };
});

// ═══════════════════ INIT ════════════════════════════════════════════
(function initPremium() {
  function setup() {
    // Create premium page
    if (!document.getElementById('premium')) {
      const content = document.querySelector('.content');
      if (content) {
        const div = document.createElement('div');
        div.className = 'page';
        div.id = 'premium';
        content.appendChild(div);
      }
    }

    // Add Premium to sidebar nav
    const navList = document.getElementById('sidebarNav');
    if (navList && !document.querySelector('[data-nav="premium"]')) {
      const navSep = navList.querySelector('.nav-sep');
      const btn = document.createElement('button');
      btn.className = 'nav-item';
      btn.dataset.nav = 'premium';
      btn.innerHTML = `💎 Premium <span class="nav-badge" style="background:linear-gradient(135deg,#f59e0b,#ec4899);color:#fff">PRO</span>`;
      btn.onclick = () => showPage('premium');
      if (navSep) navList.insertBefore(btn, navSep);
      else navList.appendChild(btn);
    }

    // Inject payment modal
    if (!document.getElementById('paymentModal')) {
      const modal = document.createElement('div');
      modal.id = 'paymentModal';
      modal.className = 'modal-overlay';
      modal.innerHTML = `
        <div class="modal" style="max-width:480px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
            <h2 style="margin:0;font-size:1.15rem">💳 Complete Payment</h2>
            <button onclick="closePaymentModal()" style="background:rgba(255,255,255,.08);border:none;color:#e2e8f0;border-radius:6px;padding:4px 10px;cursor:pointer">✕</button>
          </div>
          <div id="paymentModalBody"></div>
        </div>
      `;
      document.body.appendChild(modal);
    }

    // Inject premium nudge modal
    if (!document.getElementById('premiumNudgeModal')) {
      const modal = document.createElement('div');
      modal.id = 'premiumNudgeModal';
      modal.className = 'modal-overlay';
      modal.innerHTML = `
        <div class="modal" style="max-width:400px;text-align:center">
          <div style="font-size:3rem;margin-bottom:12px">🔒</div>
          <h2 style="margin-bottom:8px">Premium Feature</h2>
          <p style="color:#64748b;font-size:.9rem;margin-bottom:20px">This content is available for Premium members only. Upgrade your rank to unlock access!</p>
          <button onclick="document.getElementById('premiumNudgeModal').classList.remove('open');showPage('premium')"
            style="width:100%;padding:12px;background:linear-gradient(135deg,#f59e0b,#ec4899);border:none;border-radius:12px;color:#fff;font-weight:700;cursor:pointer;margin-bottom:8px">
            💎 View Premium Plans
          </button>
          <button onclick="document.getElementById('premiumNudgeModal').classList.remove('open')"
            style="background:none;border:none;color:#64748b;cursor:pointer;font-size:.85rem">Maybe later</button>
        </div>
      `;
      document.body.appendChild(modal);
    }

    // Apply badge if already premium (delay to ensure LS is ready)
    setTimeout(updatePremiumBadgeUI, 500);
  }

  if (document.readyState !== 'loading') setTimeout(setup, 600);
  else document.addEventListener('DOMContentLoaded', () => setTimeout(setup, 600));
})();

// Expose globals
window.openPaymentModal = openPaymentModal;
window.closePaymentModal = closePaymentModal;
window.goToVerifyStep = goToVerifyStep;
window.submitPaymentVerification = submitPaymentVerification;
window.copyUpiId = copyUpiId;
window.saveUpiConfig = saveUpiConfig;
window.adminApprovePayment = adminApprovePayment;
window.renderAdminPayments = renderAdminPayments;
window.isPremium = isPremium;
window.requiresPremium = requiresPremium;
window.selectPlan = (id) => openPaymentModal(id);
